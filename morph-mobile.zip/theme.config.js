/** @type {const} */
const themeColors = {
  primary: { light: '#D7F36B', dark: '#D7F36B' },
  background: { light: '#0B0B10', dark: '#0B0B10' },
  surface: { light: '#151521', dark: '#151521' },
  foreground: { light: '#F7F4EF', dark: '#F7F4EF' },
  muted: { light: '#A9A6B2', dark: '#A9A6B2' },
  border: { light: '#2B2A3A', dark: '#2B2A3A' },
  success: { light: '#6EE7B7', dark: '#6EE7B7' },
  warning: { light: '#F7C66B', dark: '#F7C66B' },
  error: { light: '#FF8A8A', dark: '#FF8A8A' },
  coral: { light: '#FF7B68', dark: '#FF7B68' },
  violet: { light: '#8B7CFF', dark: '#8B7CFF' },
  raised: { light: '#202032', dark: '#202032' },
};

module.exports = { themeColors };
