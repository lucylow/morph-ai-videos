# Project TODO

- [x] Review MORPH product requirements and implementation references
- [x] Initialize Expo React Native mobile project
- [x] Create mobile interface design plan
- [x] Replace starter theme with MORPH cinematic design tokens
- [x] Generate and install unique MORPH app icon assets
- [x] Configure MORPH app name and branding metadata
- [x] Build five-tab navigation for Create, Worlds, Stories, Characters, and Profile
- [x] Implement Home discovery experience with characters, worlds, and story concepts
- [x] Implement local character data model and character carousel
- [x] Implement character creation entry flow with photo/style/personality choices
- [x] Implement worlds discovery and world detail entry flow
- [x] Implement stories list and episode continuation entry flow
- [x] Implement generation progress state with mock asynchronous stages
- [x] Implement Episode Ready actions for play, remix, continue, share, and make another
- [x] Add typed client/service interfaces for future API and AI orchestration integration
- [x] Add deterministic tests for core local state and generation flow
- [x] Run typecheck, lint, and app verification
- [x] Add typed AI intelligence contracts for multimodal input, intent routing, AI responses, memory retrieval, and evaluation stages
- [x] Add client-safe AI orchestration service boundaries without provider secrets in the mobile bundle
- [x] Add AI memory and character-consistency concepts to the local demo domain model
- [x] Improve local persistence for characters, worlds, and unfinished creation state
- [x] Add reusable typed domain models and a small local repository layer
- [x] Improve creation flow feedback with explicit generation stages and retry handling
- [x] Add richer stories and character detail interactions
- [x] Re-run tests, lint, typecheck, and save an improved checkpoint
- [x] Add real photo-library and camera entry points to character creation with graceful permission handling
- [x] Add a richer generation-progress stage component with cancel and retry states
- [ ] Add persisted generated-character creation results to the local repository
- [ ] Add tests for media-selection fallback and generation-stage transitions
- [x] Re-run validation and save the next improvement checkpoint
- [x] Align mobile AI contracts with the latest multimodal understanding, memory, routing, evaluation, repair, and personalization pipeline
- [x] Add deterministic memory utilities for deduplication, decay, retrieval limits, and context construction
- [x] Add a typed client-side generation pipeline state for AI stages and retry-safe recovery
- [x] Add tests for the expanded AI intelligence utilities
- [x] Re-run validation and save the next MORPH checkpoint
- [x] Persist completed generated episodes and character results locally
- [x] Surface saved episodes in Stories with episode counts and continuation actions
- [x] Add explicit generation cancel and retry recovery controls
- [x] Add tests for completed-creation persistence and recovery transitions
- [x] Re-run validation and save the next improvement checkpoint
- [x] Persist generated Character DNA alongside completed episode records
- [x] Add a deterministic local repository test suite with mocked storage behavior
- [x] Add simulated failed-generation recovery and a visible Retry action
- [x] Improve story continuity by carrying the selected world and character into saved episode records
- [x] Re-run validation and save the next improvement checkpoint
- [x] Add a character detail route with saved DNA, traits, and story entry points
- [ ] Add deterministic repository helpers and mocked storage tests
- [x] Make the development server recover cleanly after dependency or watcher errors
- [x] Re-run validation and save the next improvement checkpoint
- [ ] Add typed character route parameters for selecting a specific persisted character
- [ ] Add editable character name, style, and personality controls
- [ ] Persist character edits and reflect them across Home and detail views
- [ ] Add tests for character edit normalization and persistence-safe updates
- [ ] Re-run validation and save the next improvement checkpoint
- [x] Add typed storytelling engine contracts for premises, arcs, threads, lore, and creative ideas
- [x] Add deterministic creativity helpers for hook scoring, seed randomization, and choice minimization
- [x] Add typed monetization catalog, plan entitlements, credit pricing, and cost calculation boundaries
- [x] Add local UX session and smart-default utilities without putting billing or store secrets in the mobile bundle
- [x] Add deterministic tests for storytelling, UX, and monetization helpers
- [x] Re-run validation and save the next improvement checkpoint
- [x] Add interactive genre and tone planning controls to the creation flow
- [x] Add a creative-seed action that fills a coherent idea prompt
- [x] Persist selected genre, tone, and creative seed in the creation draft
- [x] Add tests for story-planning defaults and seed application
- [x] Re-run validation and save the next improvement checkpoint
- [x] Add a visual premise review card before generation
- [x] Add lightweight branching choices to Episode Ready
- [x] Persist the selected branch decision with the episode record
- [x] Add tests for premise summaries and branch-choice normalization
- [x] Re-run validation and save the next improvement checkpoint
- [x] Load the latest selected branch into the creation draft as a continuation prompt
- [x] Show visible story-thread progress on Episode Ready
- [x] Add a continuation summary and branch-aware episode metadata
- [x] Add tests for branch-to-draft continuity formatting
- [x] Re-run validation and save the next improvement checkpoint
- [x] Add typed story-graph and branch-node contracts for multi-episode continuity
- [x] Show branch-aware episode metadata in Stories
- [x] Add an interrupted-generation recovery card that resumes or discards a draft
- [x] Add tests for story-graph traversal and interrupted-flow decisions
- [x] Re-run validation and save the next improvement checkpoint
- [x] Add a visual story-map route for episode branches and current path
- [x] Add persisted recovery-card dismissal state
- [x] Add a Stories entry point into the story map
- [x] Add tests for story-map path and recovery-state helpers
- [x] Re-run validation and save the next improvement checkpoint
- [x] Inspect recent dev-server errors and identify actionable runtime issues
- [x] Add safe async error boundaries for persistence and navigation loaders
- [x] Add image-picker cancellation and permission error handling with user feedback
- [ ] Add generation timeout, cleanup, and retry-safe error states
- [x] Add deterministic tests for error normalization and fallback behavior
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Inspect latest runtime logs for remaining actionable warnings and errors
- [x] Add a dedicated generation timeout with timer cleanup and retry-safe state
- [x] Add a reusable navigation fallback screen for route-level failures
- [x] Add tests for timeout transitions and safe error messages
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Inspect latest runtime logs for actionable errors and warnings
- [x] Add a reusable global render-error fallback boundary
- [x] Add safe async loader wrappers with fallback data and retry messaging
- [x] Add offline/persistence recovery status to the creation experience
- [x] Add deterministic tests for fallback boundaries and async error mapping
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Inspect latest runtime logs for actionable persistence or loader failures
- [x] Add a bounded local write-retry helper with safe failure reporting
- [x] Add loading and retry states to persisted Stories and Characters screens
- [x] Add tests for retry backoff and fallback-loader behavior
- [x] Re-run validation and save the next error-handling checkpoint
- [ ] Inspect latest runtime logs and persisted-data failure signals
- [x] Add defensive validation and normalization for persisted characters and episodes
- [x] Add explicit loading, empty, and retry states to Characters and Story Map
- [x] Add tests for malformed local records and fallback normalization
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Add safe provider-agnostic generation request and state-machine contracts
- [x] Add client-safe creativity idea and seed contracts without direct provider calls
- [x] Add monetization profile and paywall recommendation helpers with bounded scores
- [x] Add malformed-data guards for newly introduced domain records
- [x] Add deterministic tests for transition rejection, score clamping, and safe fallbacks
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Add safe provider-agnostic generation request and state-machine contracts
- [x] Add client-safe creativity idea and seed contracts without direct provider calls
- [x] Add monetization profile and paywall recommendation helpers with bounded scores
- [x] Add malformed-data guards for newly introduced domain records
- [x] Add deterministic tests for transition rejection, score clamping, and safe fallbacks
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Add typed mobile device state model for network, lifecycle, permissions, and pending work
- [x] Add safe camera and photo-library service wrappers with normalized permission and cancellation errors
- [x] Add offline-aware fallback messaging for drafts and saved stories
- [x] Add upload-task and generation-job contracts with bounded progress values
- [x] Add deterministic tests for permission outcomes, progress clamping, and state normalization
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Add structured AppError categories, severities, codes, and safe user messages
- [x] Replace generic error normalization with typed AppError normalization
- [x] Add safe error logging boundaries that never transmit raw sensitive details
- [x] Map media, storage, generation, timeout, permission, and network failures to recoveries
- [x] Add deterministic tests for error classification and redacted logging
- [x] Re-run validation and save the next error-handling checkpoint
- [x] Add a reusable global offline banner using the mobile network state model
- [x] Add explicit loading, empty, and retry states to Characters and Story Map
- [x] Add safe retry actions that preserve the current route and draft context
- [ ] Add deterministic tests for offline-banner visibility and loader-state mapping
- [x] Re-run validation and save the next React Native checkpoint
- [ ] Add deterministic offline-banner and loader-state tests
- [ ] Persist and surface completed episode nodes in Story Map
- [ ] Add typed route parameters for character detail navigation
- [x] Re-run validation and save the next React Native checkpoint
- [x] Add typed Creator Studio project and UI state contracts
- [x] Add a mobile-first Creator Studio route with navigator, canvas mode switcher, and copilot entry point
- [x] Add local studio-state persistence with safe normalization
- [x] Add deterministic tests for studio mode and state transitions
- [x] Validate and save the next Creator Studio checkpoint
- [x] Add typed intelligence task, context, response, and reasoning-mode helpers
- [x] Add a client-safe copilot intent composer for Creator Studio
- [x] Fix AsyncStorage mocking in the deterministic studio test
- [x] Validate AI and Creator Studio changes and save a checkpoint
- [x] Add persisted completed-episode branch nodes to Story Map
- [x] Add typed character-detail route parameter parsing
- [x] Add character detail fallback for missing or malformed ids
- [x] Add deterministic tests for story-node merging and route parsing
- [x] Re-run validation and save the next React Native checkpoint
- [x] Add AI V3 kernel request and response contracts
- [x] Add validated task-graph construction and topological ordering helpers
- [x] Add safe creative-plan normalization and bounded adaptive planning helpers
- [x] Add deterministic AI V3 tests and save a checkpoint
- [x] Add normalized Character V2 model contracts for identity, motivation, traits, memory, visual DNA, and state
- [x] Add safe Character V2 normalization and continuity-evolution helpers
- [x] Add deterministic tests for Character V2 normalization and bounded evolution
- [x] Validate and save the next Character V2 checkpoint
- [x] Add typed Video Studio project, clip, track, overlay, and editor-mode contracts
- [x] Add bounded clip, playhead, transition, and zoom utilities
- [x] Add a mobile-first Video Studio route with timeline preview and edit modes
- [x] Add deterministic video-editor tests and save a checkpoint
- [x] Add typed AI video-editing tasks and media-intelligence document contracts
- [x] Add normalized scene, shot, transcript, subject, object, emotion, and quality helpers
- [x] Add safe media-ingest fallback behavior for unavailable analysis results
- [x] Add deterministic media-intelligence tests and save a checkpoint
- [x] Read Expo ImagePicker SDK 54 documentation for video selection
- [x] Add a safe video-picker service with cancellation and permission normalization
- [x] Connect video selection to Video Studio import state and preview metadata
- [x] Add deterministic media-picker tests and validate the app
- [x] Read Expo Video SDK 54 documentation for native playback
- [x] Add selected-video playback preview with safe load and error states
- [x] Add persistence-safe timeline snapshot normalization
- [x] Add deterministic preview and timeline tests and save a checkpoint
- [x] Add client-safe monetization plan and entitlement normalization helpers
- [x] Add bounded credit wallet and purchase-state calculation contracts
- [x] Add safe upgrade and entitlement messaging without client-side payment trust
- [x] Add deterministic monetization V3 tests and save a checkpoint
- [x] Add supported language registry with RTL and capability metadata
- [x] Add device-language resolution and locale formatting helpers
- [x] Add canonical content localization and translation fallback contracts
- [x] Add deterministic localization tests and validate the app
- [x] Add advanced language capability and script metadata
- [x] Add global locale context with direction, timezone, currency, and measurement helpers
- [x] Add ICU variable extraction, validation, and safe message formatting
- [x] Add deterministic multilingual V2 tests and save a checkpoint
- [x] Add persistence-safe language preference normalization and storage helpers
- [x] Add localized shell labels with RTL direction metadata
- [x] Add deterministic language-preference tests and validate the app
- [x] Save the next React Native checkpoint
- [x] Add an accessible Profile language picker using persisted preferences
- [x] Apply localized labels to the mobile tab shell
- [x] Add deterministic picker and localized-label tests
- [x] Validate and save the next React Native checkpoint
- [x] Apply persisted localized labels to Home headings and creation actions
- [x] Add localized Home content hints with safe English fallback
- [x] Add deterministic Home localization tests
- [x] Validate and save the next React Native checkpoint
- [x] Add shared language preference subscription with safe listener cleanup
- [x] Connect Profile, Home, and tab shell to immediate preference updates
- [x] Add deterministic subscription and update tests
- [x] Validate and save the next React Native checkpoint
- [x] Add reusable use-language-preference hook with cleanup-safe subscription
- [x] Add RTL-aware direction and row-layout helpers
- [x] Replace repeated screen subscription code with the shared hook
- [x] Add deterministic hook-helper tests and validate the app
- [x] Save the next React Native checkpoint
- [x] Apply RTL-aware text alignment to Profile content and language controls
- [x] Apply RTL-aware row direction to visible Home and Profile actions
- [x] Add deterministic screen-alignment helper tests
- [x] Validate and save the next React Native checkpoint
- [x] Apply shared localization hook to creation and story screens
- [x] Add RTL-aware action rows and localized recovery messaging
- [x] Add deterministic creation/story localization coverage
- [x] Validate and save the next React Native checkpoint
- [x] Apply shared localization hook to Worlds and Video Studio screens
- [x] Add RTL-aware media controls and world-detail actions
- [x] Add deterministic Worlds and Video Studio localization coverage
- [x] Validate and save the next React Native checkpoint
- [x] Localize Video Studio edit-mode chips and timeline metadata
- [x] Apply RTL-safe ordering to the horizontal editor-mode controls
- [x] Add deterministic editor-label coverage
- [x] Validate and save the next React Native checkpoint
- [x] Localize Video Studio preview state and clip labels
- [x] Apply RTL-aware alignment to preview metadata and clip text
- [x] Add deterministic preview-label coverage
- [x] Validate and save the next React Native checkpoint
- [x] Localize Video Studio transport labels and playback status copy
- [x] Add accessibility roles, labels, and states to transport and timeline controls
- [x] Add deterministic transport accessibility coverage
- [x] Validate and save the next React Native checkpoint
- [x] Add accessible labels and selected states to timeline clip buttons
- [x] Localize creation library, camera, and reference-photo actions
- [x] Add deterministic clip and media-label coverage
- [x] Validate and save the next React Native checkpoint

- [x] Add localized accessibility hints for Creation media actions
- [x] Add accessible labels and selected states to Video Studio editor-mode chips
- [x] Localize remaining Video Studio action labels and AI entry copy
- [x] Add deterministic accessibility-copy coverage for editor modes and media actions
- [x] Re-run validation and save the next React Native checkpoint

- [ ] Add bounded AI video-generation V4 intent, job, candidate, quality, and directive contracts
- [ ] Add safe V4 normalization and validation helpers for duration, progress, scores, and statuses
- [ ] Connect V4 stages to the existing provider-agnostic AI task graph without client-side provider calls
- [ ] Add deterministic V4 contract and normalization tests
- [ ] Re-run validation and save the next React Native checkpoint

- [ ] Add bounded V5 generation graph, node, edge, and execution-status contracts
- [ ] Add V5 scene-importance and candidate-quality helper contracts
- [ ] Add safe graph construction and dependency-order validation
- [ ] Add deterministic V5 graph, prioritization, and selection tests
- [ ] Re-run validation and save the next React Native checkpoint

- [x] Add shared MORPH visual tokens for spacing, radius, typography, motion, and shadows
- [x] Add reusable accessible primary, secondary, icon, AI button, badge, and surface primitives
- [x] Apply shared visual polish to key mobile creative surfaces without breaking cinematic dark mode
- [x] Add deterministic visual-token and interaction-helper coverage
- [x] Re-run validation and save the next React Native checkpoint

- [x] Apply shared MORPH tokens to Create surface spacing, radii, and primary actions
- [x] Apply shared MORPH tokens to Video Studio controls, timeline, and AI entry surface
- [x] Preserve localized labels, RTL ordering, and accessibility states during visual polish
- [x] Add deterministic surface-token coverage and run validation
- [x] Save the next React Native checkpoint

- [x] Apply shared MORPH tokens to Worlds discovery cards and section layout
- [x] Apply shared MORPH tokens to Stories episode cards and continuation actions
- [x] Apply shared MORPH tokens to Profile settings and language controls
- [x] Preserve localized labels, RTL ordering, and accessibility states across discovery surfaces
- [x] Add deterministic discovery-surface helper coverage and save a checkpoint

- [x] Apply shared MORPH tokens to Characters vault cards and primary actions
- [x] Apply shared MORPH tokens to Story Map branch and saved-episode cards
- [x] Add accessible labels and hints to character, branch, retry, and continuation controls
- [x] Preserve loading, empty, retry, localization, and RTL behavior
- [x] Re-run validation and save the next React Native checkpoint

- [x] Localize Characters headings, loading, empty, error, retry, and creation copy
- [x] Localize Story Map headings, loading, retry, path, saved episode, and open-thread copy
- [x] Add localized accessibility labels and hints for Characters and Story Map controls
- [x] Add deterministic localization-copy coverage and save the next checkpoint

- [x] Add reusable Characters localization catalog with English fallback
- [x] Add reusable Story Map localization catalog with English fallback
- [x] Integrate both screens with the shared catalog and preserve RTL/accessibility behavior
- [x] Add deterministic catalog fallback coverage and save the next checkpoint

- [x] Add reusable Profile localization catalog with English fallback
- [x] Add reusable Worlds localization catalog with English fallback
- [x] Integrate Profile and Worlds with shared catalog and preserve RTL/accessibility behavior
- [x] Add deterministic catalog fallback coverage and save the next checkpoint

- [x] Add reusable Create localization catalog with English fallback
- [x] Add reusable Video Studio localization catalog with English fallback
- [x] Integrate both screens with shared catalog and preserve media, RTL, and accessibility behavior
- [x] Add deterministic catalog fallback coverage and save the next checkpoint

- [x] Add Arabic entries to Characters, Story Map, Profile, Worlds, Create, and Video Studio catalogs
- [x] Preserve RTL-safe labels, row ordering, text alignment, and selected states
- [x] Add deterministic Arabic catalog and RTL coverage
- [x] Re-run validation and save the next checkpoint

- [x] Audit current runtime, persistence, media, and generation error paths
- [x] Add defensive recovery for async loading, storage, media, and generation failures
- [x] Add deterministic error-normalization and recovery coverage
- [x] Re-run validation and save the next checkpoint

- [x] Audit generation, media import, and async screen-loading failure paths
- [x] Add defensive recovery for generation completion, media selection, and async loading
- [x] Add deterministic failure-path coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current MORPH logs and recently changed error-recovery paths
- [x] Fix the next concrete development or runtime error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current diagnostics, runtime logs, and async failure paths
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current runtime warnings and unhandled async paths
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current diagnostics and fallible UI operations
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current diagnostics and remaining fallible operations
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current diagnostics and remaining fallible operations
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect post-repair diagnostics and MORPH-owned failure paths
- [x] Fix the next MORPH-owned runtime or development issue
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Inspect current diagnostics and project-owned failure paths
- [x] Fix the next MORPH-owned runtime or development error
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [x] Audit current app-owned failure paths and diagnostics
- [x] Implement the next MORPH-owned defensive error fix
- [x] Add deterministic regression coverage
- [x] Re-run validation and save the next checkpoint

- [ ] Inspect current runtime diagnostics and async failure paths
- [ ] Implement the next MORPH-owned defensive error fix
- [x] Add deterministic regression coverage
- [ ] Re-run validation and save the next checkpoint

- [x] Audit monetization contracts and current user-facing purchase states
- [x] Harden entitlement normalization and credit reservation/settlement edge cases
- [x] Improve monetization error and upgrade messaging with localized-safe fallbacks
- [x] Add deterministic monetization regression coverage and run validation
- [x] Save the next monetization checkpoint

- [x] Audit billing contracts and monetization UI state boundaries
- [x] Add idempotent credit reservation safeguards
- [x] Improve purchase, restore, and entitlement-refresh state handling
- [x] Add deterministic monetization regression coverage and run validation
- [x] Save the next monetization checkpoint

- [x] Add a localized monetization catalog for plans, benefits, credits, and billing errors
- [x] Add a deterministic plan-comparison and billing-action state helper
- [x] Add explicit restore and entitlement-refresh state transitions
- [x] Add regression tests for monetization copy and billing-action state behavior
- [x] Re-run validation and save the next monetization checkpoint

- [x] Audit the next React Native interaction, accessibility, and async-safety opportunity
- [x] Implement the selected mobile code improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining mobile quality gaps for localization, accessibility, and persistence safety
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining mobile quality gaps for localization, accessibility, persistence, and navigation safety
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining runtime warnings and mobile accessibility gaps
- [x] Implement the next focused React Native fix
- [x] Add deterministic regression coverage for the fix
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Episode Ready for remaining hardcoded copy and persistence feedback gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining Creator Studio and recovery-boundary copy and persistence gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining Creator Studio controls and save-recovery gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining Creator Studio canvas copy and recovery feedback gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit dynamic Creator Studio status and interaction-test gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining Creator Studio reasoning labels and interaction semantics
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio dynamic reasoning labels and accessible media controls
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio import and playback failure recovery paths
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio playback retry and recovery behavior
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio recovery logic for deterministic state transitions
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit playback-error normalization and user-facing surfaces
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining video-player error surfaces and recovery feedback
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining Video Studio transport controls and localized accessibility copy
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit remaining pointerEvents warnings and project-owned mobile quality gaps
- [x] Implement the next focused React Native fix
- [x] Add deterministic regression coverage for the fix
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio import-state feedback and one-handed interaction gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit the next mobile interaction-quality gap
- [x] Implement the focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio accessibility coverage gaps
- [x] Implement the next focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit media-picker cancellation and recovery behavior
- [x] Implement the focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit media-picker result normalization gaps
- [x] Implement the focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit media metadata presentation and accessibility gaps
- [x] Implement the focused React Native improvement
- [x] Add deterministic regression coverage for the improvement
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Video Studio transport boundary feedback
- [x] Implement boundary-aware rewind and forward accessibility states
- [x] Add deterministic regression coverage for transport boundaries
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit transport boundary feedback after the latest disabled-state improvement
- [x] Add localized boundary announcements for rewind and forward controls
- [x] Add deterministic regression coverage for boundary feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit transport position feedback after boundary announcements
- [x] Add localized current-position accessibility feedback for timeline seeking
- [x] Add deterministic regression coverage for position feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit timeline clip-selection and zoom feedback
- [x] Add localized accessibility announcements for clip selection and zoom changes
- [x] Add deterministic regression coverage for timeline feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit editor-mode selection feedback after timeline announcements
- [x] Add localized accessibility announcements for editor-mode changes
- [x] Add deterministic regression coverage for mode feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit AI-copilot navigation feedback after editor-mode announcements
- [x] Add localized accessibility announcement for opening AI copilot
- [x] Add deterministic regression coverage for copilot feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio save feedback and accessibility state
- [x] Add localized save progress and completion announcements
- [x] Add deterministic regression coverage for save feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio workspace and edit-mode feedback after save announcements
- [x] Add localized accessibility announcements for panel and mode changes
- [x] Add deterministic regression coverage for workspace feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio entity-selection feedback after workspace announcements
- [x] Add localized accessibility announcements for character, world, and asset selections
- [x] Add deterministic regression coverage for entity feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit restored entity IDs used in Creator Studio announcements
- [x] Add localized human-readable entity names for restored character, world, and asset context
- [x] Add deterministic regression coverage for localized entity naming
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio copilot navigation feedback after entity restoration
- [x] Add localized accessibility announcement when opening the copilot from Creator Studio
- [x] Add deterministic regression coverage for copilot transition feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio save affordance feedback after copilot navigation
- [x] Add localized accessibility hint for the Save action
- [x] Add deterministic regression coverage for save affordance feedback
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio workspace-panel persistence behavior
- [x] Make panel changes participate in the existing dirty/save flow
- [x] Add deterministic regression coverage for panel persistence semantics
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio selected-entity and right-panel persistence behavior
- [x] Make selected entity and right-panel context participate in the existing dirty/save flow
- [x] Add deterministic regression coverage for context persistence semantics
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio context-card presentation and selection flow
- [x] Add selectable character and world cards connected to persisted studio context
- [x] Add deterministic regression coverage for context-card selection
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio asset context presentation and selection flow
- [x] Add selectable asset cards connected to persisted studio context
- [x] Add deterministic regression coverage for asset-card selection
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit selected-context feedback after adding asset cards
- [x] Add a functional inspector summary for the selected character, world, or asset
- [x] Add deterministic regression coverage for inspector summary behavior
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit Creator Studio context clearing behavior after inspector summary
- [x] Add a clear-context action with localized labels and safe state transition
- [x] Add deterministic regression coverage for clearing selected context
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit neutral Creator Studio state after clearing context
- [x] Add localized neutral workspace summary when no entity is selected
- [x] Add deterministic regression coverage for the neutral state copy
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit selected-context inspector actions after neutral-state feedback
- [x] Add a focus-selected action that switches to the matching workspace panel
- [x] Add deterministic regression coverage for inspector focus behavior
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit selected context cards for descriptive metadata
- [x] Add localized descriptions for character, world, and asset cards
- [x] Add deterministic regression coverage for context descriptions
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit selected-asset inspector actions after context descriptions
- [x] Add a safe preview action for the selected story asset
- [x] Add deterministic regression coverage for asset preview eligibility
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit existing asset-preview state, media contracts, and Expo video guidance
- [x] Add localized asset metadata for format, duration, and source
- [x] Connect Preview asset to a functional media preview surface
- [x] Add smooth loading animation and resilient preview error handling
- [x] Add deterministic regression and localization coverage for preview behavior
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit current MORPH motion patterns and accessibility constraints
- [x] Add reduced-motion-aware cinematic entrance and press feedback
- [x] Animate context-card selection and media-preview state transitions
- [x] Add deterministic motion/accessibility regression coverage
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit current context-card and preview-state motion behavior
- [x] Add reduced-motion-aware staggered context-card entrances
- [x] Animate preview loading, ready, and error transitions smoothly
- [x] Add deterministic motion/accessibility regression coverage
- [x] Re-run validation and save the next React Native checkpoint

- [x] Audit inspector, edit-mode, and preview metadata transition states
- [x] Add reduced-motion-aware inspector and edit-mode transitions
- [x] Animate preview-ready metadata and close-state transitions
- [x] Add deterministic motion/accessibility regression coverage
- [x] Re-run validation and save the next React Native checkpoint

- [ ] Audit home character/world cards and async progress surfaces
- [ ] Add reduced-motion-aware entrance and press animations to home cards
- [ ] Add subtle progress motion for save and AI-copilot operations
- [ ] Add deterministic motion/accessibility regression coverage
- [ ] Re-run validation and save the next React Native checkpoint

- [x] Inspect current onboarding and first-run state
- [x] Implement a clearer localized onboarding flow with persistence
- [x] Add reduced-motion-safe transitions and accessibility announcements to onboarding
- [x] Add deterministic onboarding state and localization coverage
- [x] Validate onboarding and save a checkpoint

- [x] Inspect existing motion system and async progress states
- [x] Add animated progress feedback for save and AI-copilot operations
- [x] Refine home and onboarding motion language
- [x] Add motion and accessibility regression coverage
- [x] Validate and save the next dynamic-motion checkpoint

- [x] Audit current code, runtime logs, and pending tracker items
- [x] Fix the highest-impact runtime or code-quality issues
- [x] Strengthen deterministic regression coverage
- [x] Run validation and save the next code-quality checkpoint

- [x] Audit the remaining backlog and select a contained improvement
- [x] Implement persistent character editing
- [x] Add resilience and deterministic regression coverage
- [x] Run validation and save the next code-quality checkpoint

- [x] Audit character editor localization and async behavior
- [x] Localize character editor copy and persistence feedback
- [x] Add deterministic editor and localization regression coverage
- [x] Run validation and save the next character-editor checkpoint

- [x] Audit the latest character-detail flow and pending resilience items
- [x] Add localized save success feedback and loader recovery
- [x] Add deterministic resilience and accessibility coverage
- [x] Run validation and save the next character-detail checkpoint

- [x] Audit character-detail edit lifecycle and offline signals
- [x] Protect unsaved edits and preserve draft fields across retries
- [x] Add deterministic lifecycle and accessibility coverage
- [x] Run validation and save the next character-detail checkpoint
- [x] Audit the remaining resilience backlog and select the next contained fix
- [x] Implement the next resilience improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next resilience checkpoint

- [x] Audit the remaining character and story resilience gaps
- [x] Implement the next contained resilience improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next resilience checkpoint

- [x] Audit the latest Story Map state and localized copy
- [x] Add localized completion status and progress summary
- [x] Add deterministic Story Map localization coverage
- [x] Run validation and save the next Story Map checkpoint

- [x] Audit the current story-flow interactions and pending items
- [x] Implement the next story-flow improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next story-flow checkpoint

- [x] Audit Stories and persistence quality gaps
- [x] Implement the next Stories or persistence improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next maintenance checkpoint

- [x] Audit the next high-value user flow and pending items
- [x] Implement the next contained product improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next product checkpoint

- [x] Audit Create completion persistence and navigation ordering
- [x] Make async completion persistence safe before navigation
- [x] Add deterministic async and recovery coverage
- [x] Run validation and save the next Create reliability checkpoint

- [ ] Audit Create async completion lifecycle
- [ ] Add mounted-state guards and safe recovery
- [x] Add deterministic lifecycle regression coverage
- [ ] Run validation and save the next Create lifecycle checkpoint

- [x] Audit current mounted-state changes
- [x] Complete mounted-state guard integration
- [x] Add deterministic lifecycle coverage
- [x] Run validation and save the next Create lifecycle checkpoint

- [x] Audit Create retry and generation-run lifecycle
- [x] Add generation-run identity and stale-result protection
- [x] Add deterministic retry and lifecycle coverage
- [x] Run validation and save the next generation-retry checkpoint

- [x] Audit Create completion feedback and localized copy
- [x] Add persistence-progress feedback
- [x] Add deterministic accessibility and state coverage
- [x] Run validation and save the next Create feedback checkpoint

- [x] Audit Create persistence failure and draft recovery paths
- [x] Preserve generated work through partial persistence failures
- [x] Add retryable recovery and localized coverage
- [x] Run validation and save the next persistence-recovery checkpoint

- [x] Audit persisted recovery data and Create failure state
- [x] Implement retry-save without regenerating the story
- [x] Add deterministic recovery and localization coverage
- [x] Run validation and save the next retry-save checkpoint

- [x] Audit partial persistence outcomes and localized error copy
- [x] Add specific persistence-failure reporting
- [x] Add deterministic failure-mapping and localization coverage
- [x] Run validation and save the next persistence-reporting checkpoint

- [x] Audit Create persistence outcome state and recovery copy
- [x] Add saved-versus-pending recovery summary
- [x] Add deterministic persistence-outcome and localization coverage
- [x] Run validation and save the next persistence-summary checkpoint

- [x] Audit the current persistence summary and retry states
- [x] Add per-record retry progress and success feedback
- [x] Add deterministic persistence-state and localization coverage
- [x] Run validation and save the next persistence-feedback checkpoint

- [x] Audit the next creation and story-flow opportunity
- [x] Implement the next user-facing improvement
- [x] Add deterministic regression coverage
- [x] Run validation and save the next product checkpoint

- [x] Audit remaining Episode Ready accessibility localization gaps
- [x] Localize Episode Ready back-navigation hint across EN, FR, ES, and AR
- [x] Add deterministic localization regression coverage
- [x] Run validation and prepare the next MORPH checkpoint

- [x] Audit remaining Stories accessibility and localization gaps
- [x] Localize Stories interaction hints and offline retry feedback
- [x] Add deterministic Stories accessibility/localization regression coverage
- [x] Run validation and save the next Stories quality checkpoint

- [x] Audit Story Map continuation and localization gaps
- [x] Localize Story Map continuation hints and branch metadata feedback
- [x] Add deterministic Story Map accessibility/localization regression coverage
- [x] Run validation and save the next Story Map quality checkpoint

- [x] Audit the remaining pointerEvents deprecation
- [x] Verify the warning is dependency-level with no project-owned pointerEvents usage
- [x] Confirm TypeScript, tests, and lint remain clean
- [x] Document the warning as a dependency follow-up rather than an app-code defect

- [x] Audit Home character/world cards and async progress surfaces
- [x] Add reduced-motion-safe entrance and press feedback to Home cards
- [x] Add deterministic Home motion/accessibility regression coverage
- [x] Run validation and save the next Home quality checkpoint

- [x] Audit Create character-only and episode-only persistence failure boundaries
- [x] Add deterministic recovery coverage for partial persistence outcomes
- [x] Verify localized persistence summaries remain accurate for each failure mode
- [x] Run validation and save the next Create resilience checkpoint

- [x] Audit the live Create persistence path against the staged outcome model
- [x] Wire staged persistence outcomes into Create recovery UI
- [x] Add deterministic integration regression coverage for live persistence mapping
- [x] Run validation and save the next Create resilience checkpoint

- [x] Audit Create recovery-state presentation logic
- [x] Extract a typed helper for active, saved, and pending persistence labels
- [x] Add deterministic UI-state mapping regression coverage
- [x] Run validation and save the next Create recovery checkpoint

- [x] Audit saved-story routes and continuation contracts
- [x] Implement a resilient saved-episode detail flow
- [x] Add deterministic saved-story detail regression coverage
- [x] Run validation and save the next story-flow checkpoint

- [x] Audit episode-detail to Create continuation parameter contracts
- [x] Implement branch-aware continuation context for saved episodes
- [x] Add deterministic continuation-context regression coverage
- [x] Run validation and save the next story-flow checkpoint

- [x] Audit saved-episode route resilience and accessibility gaps
- [x] Implement localized route-state recovery feedback
- [x] Add deterministic saved-episode route-state regression coverage
- [x] Run validation and save the next story-flow checkpoint

- [x] Audit remaining Create accessibility strings
- [x] Extract and localize Create interaction hints
- [x] Add deterministic Create accessibility-localization regression coverage
- [x] Run validation and save the next Create quality checkpoint

- [x] Audit remaining visible Create recovery and permission feedback strings
- [x] Localize Create recovery text and camera permission alert copy
- [x] Add deterministic visible-feedback localization coverage
- [x] Run validation and save the next Create quality checkpoint

- [x] Audit saved-episode media and playback contracts
- [x] Implement resilient saved-episode playback preview
- [x] Add deterministic media-state regression coverage
- [x] Run validation and save the next playback quality checkpoint

- [x] Audit Expo Video integration and episode media contracts
- [x] Implement playable media preview with localized loading and error recovery
- [x] Add deterministic video-preview regression coverage
- [x] Run validation and save the next playback quality checkpoint

- [x] Audit failed-player recovery behavior
- [x] Implement localized retry playback action
- [x] Add deterministic retry-playback regression coverage
- [x] Run validation and save the next playback recovery checkpoint

- [x] Audit episode playback-position persistence contracts
- [x] Implement safe resume-position storage and localized resume feedback
- [x] Add deterministic playback-position regression coverage
- [x] Run validation and save the next playback continuity checkpoint

- [x] Audit playback completion and resume presentation behavior
- [x] Implement localized resume-position affordance and completion handling
- [x] Add deterministic resume/completion regression coverage
- [x] Run validation and save the next playback continuity checkpoint

- [x] Audit Stories card progress contracts
- [x] Implement localized playback-progress presentation
- [x] Add deterministic Stories progress regression coverage
- [x] Run validation and save the next Stories continuity checkpoint

- [x] Audit resume and restart playback contracts
- [x] Implement localized Resume and Start over controls
- [x] Add deterministic Resume/Start over regression coverage
- [x] Run validation and save the next playback continuity checkpoint

- [x] Audit Stories progress-bar presentation contracts
- [x] Implement bounded localized progress-bar feedback
- [x] Add deterministic Stories progress-bar regression coverage
- [x] Run validation and save the next Stories continuity checkpoint

- [x] Audit live playback status and progress contracts
- [x] Implement lifecycle-safe live progress updates
- [x] Add deterministic live-progress regression coverage
- [x] Run validation and save the next playback continuity checkpoint

- [x] Audit Episode Detail state and recovery contracts
- [x] Implement testable recovery-state helpers
- [x] Add regression coverage and validate
- [x] Save the next Episode Detail resilience checkpoint

- [x] Audit localized playback metadata contracts
- [x] Implement localized progress metadata
- [x] Add regression coverage and validate
- [x] Save the next playback metadata checkpoint

- [x] Audit Stories playback metadata contracts
- [x] Implement clearer localized Stories progress metadata
- [x] Add regression coverage and validate
- [x] Save the next Stories metadata checkpoint

- [x] Audit scrubber and seek contracts
- [x] Implement bounded localized scrubber behavior
- [x] Add deterministic coverage and validate
- [x] Save the next Episode Detail playback checkpoint

- [x] Audit scrubber gesture and boundary contracts
- [x] Implement resilient drag scrubbing
- [x] Add deterministic coverage and validate
- [x] Save the next Episode Detail scrubber checkpoint

- [x] Audit scrubber write-frequency and lifecycle contracts
- [x] Implement gesture-end persistence safely
- [x] Add deterministic coverage and validate
- [x] Save the next playback persistence checkpoint

- [x] Audit scrubber accessibility and time metadata contracts
- [x] Implement localized remaining-time feedback
- [x] Add deterministic coverage and validate
- [x] Save the next scrubber accessibility checkpoint

- [x] Audit Stories remaining-time metadata contracts
- [x] Implement localized Stories remaining-time metadata
- [x] Add deterministic coverage and validate
- [x] Save the next Stories playback metadata checkpoint

- [x] Audit Stories resume-action contracts
- [x] Implement localized resume affordance
- [x] Add deterministic coverage and validate
- [x] Save the next Stories resume checkpoint

- [x] Audit Stories reset-action and repository contracts
- [x] Implement localized Stories Start over action
- [x] Add deterministic coverage and validate
- [x] Save the next Stories reset checkpoint

- [x] Audit reset and undo persistence contracts
- [x] Implement localized Stories reset undo
- [x] Add deterministic coverage and validate
- [x] Save the next Stories undo checkpoint

- [x] Audit reset and undo failure contracts
- [x] Implement localized persistence failure feedback
- [x] Add deterministic coverage and validate
- [x] Save the next Stories persistence recovery checkpoint

- [x] Audit persistence retry and snapshot contracts
- [x] Implement localized Stories persistence retry
- [x] Add deterministic coverage and validate
- [x] Save the next Stories retry checkpoint

- [x] Audit retry concurrency and backoff contracts
- [x] Implement guarded retry persistence
- [x] Add deterministic coverage and validate
- [x] Save the next guarded retry checkpoint

- [x] Audit connectivity and persistence retry contracts
- [x] Implement offline-aware playback persistence
- [x] Add deterministic coverage and validate
- [x] Save the next offline persistence checkpoint

- [x] Audit connectivity listener and pending-save contracts
- [x] Implement reconnect-aware persistence recovery
- [x] Add deterministic coverage and validate
- [x] Save the next reconnect recovery checkpoint

- [x] Audit reconnect lifecycle and stale-retry contracts
- [x] Implement lifecycle-safe reconnect feedback
- [x] Add deterministic coverage and validate
- [x] Save the next reconnect lifecycle checkpoint

- [x] Audit retry status and timer lifecycle contracts
- [x] Implement visible cancellable retry progress
- [x] Add deterministic coverage and validate
- [x] Save the next retry status checkpoint

- [x] Audit retry cancellation and snapshot contracts
- [x] Implement localized retry cancellation
- [x] Add deterministic coverage and validate
- [x] Save the next retry cancellation checkpoint

- [x] Audit pending-save status and cancellation contracts
- [x] Implement localized pending-save status
- [x] Add deterministic coverage and validate
- [x] Save the next pending-save status checkpoint

- [x] Audit cancelled-save recovery contracts
- [x] Implement localized manual retry resume
- [x] Add deterministic coverage and validate
- [x] Save the next manual resume checkpoint

- [x] Audit cancelled-retry expiry contracts
- [x] Implement bounded cancelled-retry expiry
- [x] Add deterministic coverage and validate
- [x] Save the next cancelled-retry expiry checkpoint

- [x] Audit persisted recovery and restart contracts
- [x] Implement restart-safe recovery handling
- [x] Add deterministic coverage and validate
- [x] Save the next restart-safe recovery checkpoint

- [x] Audit persisted recovery repository contracts
- [x] Add deterministic repository recovery tests
- [x] Run validation and fix regressions
- [x] Save the next repository recovery checkpoint

- [x] Audit restored-recovery notice contracts
- [x] Implement localized restored-recovery notice
- [x] Add deterministic coverage and validate
- [x] Save the next restored-recovery notice checkpoint

- [x] Audit restored recovery context contracts
- [x] Implement localized affected-episode recovery context
- [x] Add deterministic coverage and validate
- [x] Save the next actionable recovery checkpoint

- [x] Audit restored notice action contracts
- [x] Implement localized one-tap recovery resume
- [x] Add deterministic coverage and validate
- [x] Save the next one-tap recovery checkpoint

- [x] Audit restored notice visual and progress contracts
- [x] Implement localized recovery context card
- [x] Add deterministic coverage and validate
- [x] Save the next recovery context checkpoint

- [x] Audit current Stories recovery flow and test seams
- [x] Implement a centralized recovery-notice state model
- [x] Add deterministic UI-facing regression coverage and validate
- [x] Checkpoint and report the improvement

- [x] Audit recovery success and notice cleanup contracts
- [x] Implement localized recovery save confirmation
- [x] Add deterministic coverage and validate
- [x] Save the next recovery confirmation checkpoint

- [x] Audit restored-recovery manual dismissal cleanup
- [x] Clear dismissed recovery snapshots from state and AsyncStorage
- [x] Add deterministic dismissal cleanup regression coverage
- [x] Validate and save the next resilience checkpoint

- [x] Audit recovery dismissal cleanup across unmount boundaries
- [x] Guard asynchronous dismissal cleanup against stale screen updates
- [x] Add deterministic lifecycle regression coverage
- [x] Validate and save the next lifecycle-safe recovery checkpoint

- [x] Audit Stories history loader across unmount boundaries
- [x] Guard async episode loading against stale state updates
- [x] Add deterministic loader lifecycle regression coverage
- [x] Validate and save the next Stories loader checkpoint

- [x] Audit Stories manual refresh feedback
- [x] Add loading and duplicate-tap protection to the refresh action
- [x] Add deterministic refresh-state regression coverage
- [x] Validate and save the next Stories refresh checkpoint

- [x] Audit Stories refresh accessibility feedback
- [x] Add localized refresh-in-progress labels and announcements
- [x] Add deterministic localization regression coverage
- [x] Validate and save the next Stories refresh accessibility checkpoint

- [x] Audit Stories refresh completion feedback
- [x] Add localized success announcement for manual refresh completion
- [x] Add deterministic refresh-completion localization coverage
- [x] Validate and save the next Stories refresh-completion checkpoint

- [x] Audit Stories refresh success message lifetime
- [x] Add lifecycle-safe auto-dismissal for refresh completion feedback
- [x] Add deterministic timer and lifecycle regression coverage
- [x] Validate and save the next Stories success-feedback checkpoint

- [x] Audit Stories refresh feedback motion
- [x] Add reduced-motion-safe enter and exit transitions
- [x] Add deterministic motion regression coverage
- [x] Validate and save the next Stories motion checkpoint

- [x] Audit Stories refresh completion test seams
- [x] Centralize initial-versus-manual refresh completion message selection
- [x] Add deterministic refresh completion state coverage
- [x] Validate and save the next Stories test-seam checkpoint

- [x] Audit Stories refresh control accessibility state
- [x] Add explicit busy and disabled semantics during refresh
- [x] Add deterministic refresh accessibility-state coverage
- [x] Validate and save the next Stories accessibility checkpoint

- [x] Audit Stories initial-load versus manual-refresh error feedback
- [x] Add distinct localized manual-refresh failure copy
- [x] Add deterministic error-selection and localization coverage
- [x] Validate and save the next Stories error-feedback checkpoint

- [x] Audit Stories retry success feedback
- [x] Add distinct localized confirmation after a recovered playback save succeeds
- [x] Add deterministic retry-success localization coverage
- [x] Validate and save the next Stories retry-success checkpoint

- [x] Audit recovered playback-save success message lifetime
- [x] Auto-dismiss playback-save success feedback safely
- [x] Add deterministic timer and lifecycle regression coverage
- [x] Validate and save the next recovery-feedback checkpoint

- [x] Audit transient Stories success announcements
- [x] Add explicit accessibility labels for success feedback
- [x] Add deterministic announcement-label regression coverage
- [x] Validate and save the next Stories accessibility checkpoint

- [x] Audit Create completion feedback lifecycle after generation retries
- [x] Guard completion feedback against stale generation runs and unmounted screens
- [x] Add deterministic completion-feedback lifecycle coverage
- [x] Validate and save the next Create lifecycle checkpoint

- [x] Audit Create generation-run identity updates across cancel and retry paths
- [x] Centralize safe generation-run increments to prevent stale async completion
- [x] Add deterministic generation-run identity regression coverage
- [x] Validate and save the next Create lifecycle checkpoint

- [x] Audit Create generation timer reference cleanup
- [x] Reset generation and timeout refs after cancellation, timeout, and unmount
- [x] Add deterministic timer-reference cleanup coverage
- [x] Validate and save the next Create lifecycle checkpoint

- [x] Audit Create persistence progress accessibility semantics
- [x] Add reusable busy-state mapping for character and episode saves
- [x] Add deterministic persistence accessibility-state coverage
- [x] Validate and save the next Create accessibility checkpoint

- [x] Audit Create retry-save duplicate-tap behavior
- [x] Add a pure guard for overlapping persistence retries
- [x] Add deterministic retry-start regression coverage
- [x] Validate and save the next Create retry checkpoint

- [x] Audit Create retry-save accessibility state
- [x] Add reusable busy and disabled mapping for retry-save controls
- [x] Add deterministic retry accessibility-state coverage
- [x] Validate and save the next Create accessibility checkpoint

- [x] Audit Create generation-start duplicate-tap behavior
- [x] Add a pure guard for overlapping generation starts
- [x] Add deterministic generation-start regression coverage
- [x] Validate and save the next Create generation checkpoint

- [x] Audit Create generation-retry accessibility state during persistence
- [x] Add reusable busy and disabled mapping for generation retries
- [x] Add deterministic generation-retry accessibility-state coverage
- [x] Validate and save the next Create retry accessibility checkpoint

- [x] Guard asynchronous Create draft hydration after unmount
- [x] Guard asynchronous continuation hydration after unmount
- [x] Add deterministic coverage for mounted async state application
- [x] Validate and save the next Create lifecycle checkpoint

- [x] Guard Create autosave error feedback after unmount
- [x] Reuse a pure mounted feedback-state guard for async storage errors
- [x] Add deterministic coverage for mounted feedback application
- [x] Validate and save the next Create feedback checkpoint

- [x] Clear consumed generation and timeout refs when generation completes
- [x] Preserve safe cleanup for simulated generation failures
- [x] Add deterministic timer-consumption regression coverage
- [x] Validate and save the next Create cleanup checkpoint

- [x] Remove project-owned debug logging that pollutes runtime diagnostics
- [x] Stop logging sensitive authentication token prefixes
- [x] Add deterministic coverage for safe runtime logging boundaries
- [x] Validate and save the next diagnostics cleanup checkpoint

- [x] Remove verbose client API request and response logging
- [x] Avoid logging response headers and cookie values
- [x] Preserve concise error diagnostics without sensitive payloads
- [x] Validate and save the next API diagnostics checkpoint

- [x] Preserve successful plain-text API responses without JSON parsing
- [x] Add a pure response-body normalization helper
- [x] Add deterministic coverage for empty and plain-text success bodies
- [x] Validate and save the next API response checkpoint

- [x] Bound shared client API requests with a timeout
- [x] Propagate caller cancellation into API fetches
- [x] Clean up timeout and abort listeners after completion
- [x] Add deterministic timeout and cancellation helper coverage
- [x] Validate and save the next API request lifecycle checkpoint

- [x] Distinguish API timeout failures from caller cancellation
- [x] Preserve the classification through shared API error handling
- [x] Add deterministic classification coverage for timeout and cancellation
- [x] Validate and save the next API error-semantics checkpoint

- [x] Guard Stories retry persistence failures after unmount or retry invalidation
- [x] Guard retry completion cleanup against stale retry generations
- [x] Add deterministic retry lifecycle coverage for stale async callbacks
- [x] Validate and save the next Stories retry checkpoint

- [x] Invalidate prior playback mutations when reset or undo starts
- [x] Guard reset and undo success and failure callbacks
- [x] Add deterministic reset and undo stale-callback coverage
- [x] Validate and save the next Stories mutation checkpoint

- [x] Add one shared playback mutation state guard
- [x] Route reset, undo, and retry through the shared guard
- [x] Add deterministic shared-guard coverage
- [x] Validate and save the next Stories guard checkpoint

- [x] Replace non-cancellable Stories retry backoff with a cancellable delay
- [x] Cancel pending backoff work on retry cancellation and unmount
- [x] Add deterministic cancellable-delay coverage
- [x] Validate and save the next Stories backoff checkpoint

- [x] Preserve the reset snapshot after a successful reset for undo
- [x] Track active playback mutations separately from available undo state
- [x] Add busy and disabled semantics to reset and undo controls
- [x] Add deterministic accessibility-state coverage
- [x] Validate and save the next Stories controls checkpoint

- [x] Add localized timeout and cancellation copy for Stories playback persistence
- [x] Map reset, undo, and retry persistence failures to specific feedback
- [x] Add deterministic Stories playback error-feedback coverage
- [x] Validate and save the next Stories feedback checkpoint

- [x] Resolve the Stories retry callback dependency warning introduced by localized feedback mapping
