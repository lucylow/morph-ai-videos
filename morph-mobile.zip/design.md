# MORPH Mobile Interface Design

## Product direction

MORPH is an iOS-first creative storytelling app where a person becomes the recurring character in an AI-generated universe. The interface should feel like a premium creative social product rather than a video editor: visual, playful, fast to understand, and optimized for one-handed portrait use.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Home | Greeting, primary “Create character” CTA, continue-story card, trending worlds, story concepts, and horizontal character carousel. |
| Create | Short creation flow: pick character, choose world, choose what happens next, optionally enter a director prompt, then generate. |
| Character Builder | Photo selection, style chips, personality chips, character name, review, and save/regenerate actions. |
| Character Detail | Character portrait, DNA summary, wardrobe/personality traits, story history, and “Create episode” action. |
| Worlds | Discoverable world cards with genre, visual style, and templates; filter by mood or genre. |
| World Detail | Hero artwork, world rules, popular templates, and “Put my character here” action. |
| Stories | Episode list grouped by story thread, progress states, and continue-story actions. |
| Story Detail | Vertical episode timeline, playable episode cards, unresolved story threads, and continue/remix/duel actions. |
| Generation Progress | Stage-based progress for preparing, building, animating, and finishing; cancel and retry states. |
| Episode Ready | Large media preview with Play, Remix, Continue, Share, and Make another actions. |
| Profile | Creator identity, published creations, remixes, saved worlds, and settings entry point. |
| Remix | Source template preview, character selector, optional prompt, and generate remix action. |
| Character Battle | Two character slots, battle prompt/action, generation state, and A/B voting outcome. |
| Share sheet | Native share entry point plus caption, visibility, and export options. |

## Key user flows

### First creation

1. User opens Home and sees “What should your character become today?”.
2. User taps “Create character”.
3. User selects a photo from the camera or photo library.
4. User selects a visual style and two or three personality traits.
5. User names the character and taps “Create my character”.
6. MORPH shows stage-based progress and then the generated character review.
7. User taps “Put them in a story”, selects a world, and chooses what happens next.
8. User taps “Generate episode”.
9. User sees Generation Progress followed by Episode Ready.

### Continue a story

1. User opens Home or Stories and taps a story card.
2. User reviews the latest episode and unresolved thread.
3. User taps “Continue”.
4. User selects a lightweight story direction such as Adventure, Chaos, Friendship, or Mission.
5. MORPH generates the next episode using the same character DNA and story state.

### Remix a creation

1. User taps Remix on an episode or discovery card.
2. User chooses an existing character or creates one.
3. User reviews the source world and action, with the ability to tweak the prompt.
4. User taps “Make my version”.
5. MORPH returns the remix as a new episode with attribution to the source template.

### Explore a world

1. User opens Worlds and browses visual world cards.
2. User taps a world to inspect its cover, description, and popular templates.
3. User taps “Put my character here”.
4. User chooses an action and generates an episode.

## Layout and interaction rules

The app uses portrait 9:16 layouts with generous horizontal padding, thumb-friendly controls, and bottom-tab navigation. Primary actions sit within the lower half of the screen or in a sticky bottom action area. Cards use large media previews and short labels; long explanations are progressively disclosed in sheets or detail screens. All primary buttons use press feedback and haptics where supported. Lists use performant FlatList-based rendering.

The main navigation is a five-tab bar: Create, Worlds, Stories, Characters, and Profile. Home is the default landing view, with Create remaining one tap away. Modal flows use bottom sheets or full-screen stack routes for creation, generation progress, remix, and share actions.

## Color choices

MORPH uses a dark cinematic base with a warm electric accent. The palette is intentionally distinctive and high-contrast for media-first screens.

| Token | Color | Use |
|---|---|---|
| Ink | `#0B0B10` | Main background and full-bleed media framing |
| Surface | `#151521` | Cards, sheets, and elevated controls |
| Surface raised | `#202032` | Selected states and nested panels |
| Text | `#F7F4EF` | Primary text |
| Muted text | `#A9A6B2` | Secondary text and metadata |
| Lime | `#D7F36B` | Primary CTA, active tab, progress accents |
| Coral | `#FF7B68` | Social/remix actions and expressive highlights |
| Violet | `#8B7CFF` | World/story metadata and gradients |
| Line | `#2B2A3A` | Borders and dividers |
| Success | `#6EE7B7` | Completion states |
| Error | `#FF8A8A` | Failure states |

Typography should use a bold display face for MORPH and screen headlines, a clean system sans for body copy, and tabular numerals only for meaningful progress or credits. Avoid dense dashboard styling and avoid exposing AI-provider terminology in user-facing screens.

## MVP implementation boundary

The first coded slice should prioritize a polished Home experience, working tab navigation, local demo data for characters/worlds/stories, the character creation entry point, a simple generation-progress simulation, and an Episode Ready surface. Backend orchestration and real media generation should remain behind typed service interfaces so the local experience can be replaced without rewriting the UI.
