from pathlib import Path
from PIL import Image

source = Path('/home/ubuntu/webdev-static-assets/morph-icon.png')
targets = [
    Path('/home/ubuntu/morph-mobile/assets/images/icon.png'),
    Path('/home/ubuntu/morph-mobile/assets/images/splash-icon.png'),
    Path('/home/ubuntu/morph-mobile/assets/images/favicon.png'),
    Path('/home/ubuntu/morph-mobile/assets/images/android-icon-foreground.png'),
]

with Image.open(source) as image:
    image = image.convert('RGB')
    for target in targets:
        size = 512 if target.name != 'favicon.png' else 256
        image.resize((size, size), Image.Resampling.LANCZOS).save(target, format='PNG', optimize=True)
