import { useEffect, useState } from "react";
import { AccessibilityInfo, Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import Animated, { FadeIn, FadeInRight, FadeOutLeft, useReducedMotion } from "react-native-reanimated";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { saveLanguagePreference } from "@/src/localization/language-preferences";
import { completeOnboarding } from "@/src/onboarding/onboarding-state";
import { rowDirection, textDirection } from "@/src/localization/layout";
import { useColors } from "@/hooks/use-colors";
import type { LanguageCode } from "@/src/localization/i18n";

const COPY = {
  en: {
    eyebrow: "A NEW WAY TO CREATE",
    slides: [
      { kicker: "01 / IMAGINE", title: "Your stories start with a spark.", body: "Shape a character with a point of view, then watch their world respond.", cta: "Meet your characters", icon: "✦", colors: ["#8B7CFF", "#241F4A"] },
      { kicker: "02 / EXPLORE", title: "Every world remembers.", body: "Discover places with their own mood, history, and endless directions to follow.", cta: "Find a world", icon: "◌", colors: ["#5CA8FF", "#142B48"] },
      { kicker: "03 / MORPH", title: "Make the next scene yours.", body: "Remix the moment, change the path, and keep your story moving at your pace.", cta: "Start creating", icon: "↗", colors: ["#FF7B68", "#42232C"] },
    ],
    skip: "Skip",
    next: "Continue",
    finish: "Enter MORPH",
    language: "Choose your language",
    languageHint: "You can change this later in Profile.",
    step: (current: number) => `Onboarding step ${current} of 3`,
  },
  fr: {
    eyebrow: "UNE NOUVELLE FAÇON DE CRÉER",
    slides: [
      { kicker: "01 / IMAGINER", title: "Vos histoires commencent par une étincelle.", body: "Donnez une voix à un personnage, puis regardez son monde réagir.", cta: "Rencontrer vos personnages", icon: "✦", colors: ["#8B7CFF", "#241F4A"] },
      { kicker: "02 / EXPLORER", title: "Chaque monde se souvient.", body: "Découvrez des lieux avec leur humeur, leur histoire et mille chemins à suivre.", cta: "Trouver un monde", icon: "◌", colors: ["#5CA8FF", "#142B48"] },
      { kicker: "03 / MORPH", title: "Faites vôtre la scène suivante.", body: "Remixez le moment, changez la voie et avancez à votre rythme.", cta: "Commencer à créer", icon: "↗", colors: ["#FF7B68", "#42232C"] },
    ],
    skip: "Passer", next: "Continuer", finish: "Entrer dans MORPH", language: "Choisissez votre langue", languageHint: "Vous pourrez la modifier dans Profil.", step: (current: number) => `Étape ${current} sur 3`,
  },
  es: {
    eyebrow: "UNA NUEVA FORMA DE CREAR",
    slides: [
      { kicker: "01 / IMAGINA", title: "Tus historias comienzan con una chispa.", body: "Dale una perspectiva a un personaje y observa cómo responde su mundo.", cta: "Conoce tus personajes", icon: "✦", colors: ["#8B7CFF", "#241F4A"] },
      { kicker: "02 / EXPLORA", title: "Cada mundo recuerda.", body: "Descubre lugares con su propio ambiente, historia y caminos por seguir.", cta: "Encuentra un mundo", icon: "◌", colors: ["#5CA8FF", "#142B48"] },
      { kicker: "03 / MORPH", title: "Haz tuya la próxima escena.", body: "Reinterpreta el momento, cambia el rumbo y avanza a tu ritmo.", cta: "Empieza a crear", icon: "↗", colors: ["#FF7B68", "#42232C"] },
    ],
    skip: "Omitir", next: "Continuar", finish: "Entrar en MORPH", language: "Elige tu idioma", languageHint: "Puedes cambiarlo después en Perfil.", step: (current: number) => `Paso ${current} de 3`,
  },
  ar: {
    eyebrow: "طريقة جديدة للإبداع",
    slides: [
      { kicker: "01 / تخيّل", title: "تبدأ قصصك بشرارة.", body: "امنح شخصيتك صوتاً، ثم شاهد عالمها يتفاعل.", cta: "تعرّف على شخصياتك", icon: "✦", colors: ["#8B7CFF", "#241F4A"] },
      { kicker: "02 / استكشف", title: "كل عالم يحتفظ بذكرياته.", body: "اكتشف أماكن لها مزاجها وتاريخها وطرق لا تنتهي لاستكمال القصة.", cta: "اعثر على عالم", icon: "◌", colors: ["#5CA8FF", "#142B48"] },
      { kicker: "03 / MORPH", title: "اجعل المشهد التالي لك.", body: "أعد مزج اللحظة، غيّر المسار، وواصل قصتك بالسرعة التي تناسبك.", cta: "ابدأ الإنشاء", icon: "↗", colors: ["#FF7B68", "#42232C"] },
    ],
    skip: "تخطّ", next: "متابعة", finish: "الدخول إلى MORPH", language: "اختر لغتك", languageHint: "يمكنك تغييرها لاحقاً من الملف الشخصي.", step: (current: number) => `الخطوة ${current} من 3`,
  },
} as const;

const LANGUAGE_OPTIONS: { code: LanguageCode; label: string }[] = [
  { code: "en", label: "English" },
  { code: "fr", label: "Français" },
  { code: "es", label: "Español" },
  { code: "ar", label: "العربية" },
];

export default function OnboardingScreen() {
  const router = useRouter();
  const colors = useColors();
  const { language, presentation } = useLanguagePreference();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const reduceMotion = useReducedMotion();
  const copy = COPY[language as keyof typeof COPY] ?? COPY.en;
  const direction = textDirection(presentation.direction);
  const row = rowDirection(presentation.direction);
  const slide = copy.slides[step];

  useEffect(() => {
    AccessibilityInfo.announceForAccessibility(copy.step(step + 1));
  }, [copy, step]);

  const finish = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await completeOnboarding();
      router.replace("/");
    } finally {
      setSaving(false);
    }
  };

  const advance = () => {
    if (step < copy.slides.length - 1) setStep((current) => current + 1);
    else void finish();
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}>
      <View style={styles.container}>
        <View style={[styles.topBar, row]}>
          <Text style={styles.wordmark}>MORPH</Text>
          <Pressable accessibilityRole="button" accessibilityLabel={copy.skip} accessibilityHint="Skip onboarding and open Home" onPress={finish} disabled={saving} style={({ pressed }) => [styles.skip, pressed && styles.pressed]}>
            <Text style={[styles.skipText, { color: colors.muted }]}>{copy.skip}</Text>
          </Pressable>
        </View>

        <View style={styles.progressTrack} accessibilityLabel={copy.step(step + 1)} accessibilityRole="progressbar" accessibilityValue={{ min: 1, max: 3, now: step + 1 }}>
          <Animated.View style={[styles.progressFill, { transform: [{ scaleX: (step + 1) / copy.slides.length }] }]} />
        </View>

        <Animated.View key={`${language}-${step}`} entering={reduceMotion ? undefined : FadeInRight.duration(320)} exiting={reduceMotion ? undefined : FadeOutLeft.duration(180)} style={styles.content}>
          <Text style={[styles.eyebrow, direction]}>{copy.eyebrow}</Text>
          <LinearGradient colors={slide.colors} style={styles.artCard}>
            <Animated.View entering={reduceMotion ? undefined : FadeIn.duration(420)} style={styles.artGlow} />
            <Text style={styles.artIcon}>{slide.icon}</Text>
            <Text style={styles.artNumber}>0{step + 1}</Text>
          </LinearGradient>
          <Text style={[styles.kicker, direction]}>{slide.kicker}</Text>
          <Text style={[styles.title, direction]}>{slide.title}</Text>
          <Text style={[styles.body, { color: colors.muted }, direction]}>{slide.body}</Text>
        </Animated.View>

        <View style={styles.bottom}>
          <Text style={[styles.languageTitle, direction]}>{copy.language}</Text>
          <Text style={[styles.languageHint, { color: colors.muted }, direction]}>{copy.languageHint}</Text>
          <View style={[styles.languageRow, row]}>
            {LANGUAGE_OPTIONS.map((option) => (
              <Pressable
                key={option.code}
                accessibilityRole="button"
                accessibilityLabel={option.label}
                accessibilityState={{ selected: language === option.code }}
                onPress={() => void saveLanguagePreference({ interfaceLanguage: option.code, contentLanguage: option.code })}
                style={({ pressed }) => [styles.languageChip, language === option.code && styles.languageChipSelected, pressed && styles.pressed]}
              >
                <Text style={[styles.languageText, language === option.code && styles.languageTextSelected]}>{option.label}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel={step === copy.slides.length - 1 ? copy.finish : copy.next} accessibilityHint={step === copy.slides.length - 1 ? "Completes onboarding and opens Home" : slide.cta} onPress={advance} disabled={saving} style={({ pressed }) => [styles.primaryButton, pressed && styles.primaryPressed, saving && styles.disabled]}>
            <Text style={styles.primaryText}>{saving ? "…" : step === copy.slides.length - 1 ? copy.finish : copy.next}</Text>
            <Text style={styles.primaryArrow}>{presentation.direction === "rtl" ? "↙" : "↗"}</Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 22, paddingTop: 8, paddingBottom: 18 },
  topBar: { alignItems: "center", justifyContent: "space-between", marginBottom: 20 },
  wordmark: { color: "#F7F4EF", fontSize: 22, fontWeight: "900", letterSpacing: 4 },
  skip: { padding: 8 },
  skipText: { fontSize: 13, fontWeight: "700" },
  pressed: { opacity: 0.62 },
  progressTrack: { height: 4, backgroundColor: "#252432", borderRadius: 4, overflow: "hidden" },
  progressFill: { height: 4, backgroundColor: "#D7F36B", borderRadius: 4 },
  content: { flex: 1, justifyContent: "center", paddingVertical: 28 },
  eyebrow: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.8, marginBottom: 18 },
  artCard: { height: 260, borderRadius: 28, overflow: "hidden", alignItems: "center", justifyContent: "center", marginBottom: 26 },
  artGlow: { width: 170, height: 170, borderRadius: 85, backgroundColor: "rgba(255,255,255,0.16)" },
  artIcon: { position: "absolute", color: "#F7F4EF", fontSize: 74, fontWeight: "300" },
  artNumber: { position: "absolute", left: 18, bottom: 16, color: "rgba(255,255,255,0.72)", fontSize: 12, fontWeight: "800", letterSpacing: 2 },
  kicker: { color: "#FF7B68", fontSize: 10, fontWeight: "800", letterSpacing: 1.6, marginBottom: 10 },
  title: { color: "#F7F4EF", fontSize: 31, lineHeight: 36, fontWeight: "800", letterSpacing: -0.6, marginBottom: 12 },
  body: { fontSize: 15, lineHeight: 23, maxWidth: 340 },
  bottom: { paddingTop: 12 },
  languageTitle: { color: "#F7F4EF", fontSize: 13, fontWeight: "800" },
  languageHint: { fontSize: 11, marginTop: 3, marginBottom: 10 },
  languageRow: { gap: 7, marginBottom: 16 },
  languageChip: { borderWidth: 1, borderColor: "#353447", borderRadius: 14, paddingHorizontal: 10, paddingVertical: 8 },
  languageChipSelected: { backgroundColor: "#D7F36B", borderColor: "#D7F36B" },
  languageText: { color: "#A9A6B2", fontSize: 11, fontWeight: "700" },
  languageTextSelected: { color: "#0B0B10" },
  primaryButton: { height: 54, borderRadius: 17, backgroundColor: "#D7F36B", paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  primaryPressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  disabled: { opacity: 0.68 },
  primaryText: { color: "#0B0B10", fontSize: 15, fontWeight: "800" },
  primaryArrow: { color: "#0B0B10", fontSize: 22, fontWeight: "700" },
});
