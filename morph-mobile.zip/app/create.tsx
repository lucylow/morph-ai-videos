import { useEffect, useRef, useState } from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import Animated, { FadeIn, FadeOut, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from "react-native-reanimated";
import * as ImagePicker from "expo-image-picker";
import { ScreenContainer } from "@/components/screen-container";
import { clearCreationDraft, loadCreationDraft, loadEpisodes, saveCreationDraft, saveEpisode, upsertCharacter } from "@/src/storage/morph-repository";
import { buildPremiseSummary, formatBranchContinuation, randomizeSeed, type StoryGenre, type StoryTone } from "@/src/story/story-engine";
import { normalizeMorphError } from "@/src/core/errors";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { rowDirection, textDirection } from "@/src/localization/layout";
import { morphTokens } from "@/src/ui/morph-tokens";
import { getCreateCopy } from "@/src/localization/screen-copy";
import { getCreateInteractionCopy } from "@/src/localization/create-interaction-copy";
import { canApplyCreateFeedbackState, canApplyCreateHydrationState, canApplyGenerationResult, canApplyGenerationState, canStartGeneration, canStartPersistenceRetry, getGenerationRetryAccessibilityState, getRetrySaveAccessibilityState, nextGenerationRunId, resetGenerationTimers } from "@/src/creation/generation-lifecycle";
import { persistCreationRecords } from "@/src/creation/persistence-outcome";
import { getPersistenceAccessibilityState, getPersistenceUiLabels } from "@/src/creation/recovery-copy";
import { buildEpisodeContinuationPrompt } from "@/src/story/episode-continuation";
import { getCreateRequestFeedback } from "@/src/creation/create-error-feedback";

const styleOptions = ["Cinematic", "Anime", "Clay", "Pixel", "Graphic novel"];
const nextOptions = ["Normal day", "Adventure", "Chaos", "Friendship", "Mission"];
const worldOptions = ["Anime Academy", "Orbit 09", "Pixel City"];
const genreOptions: StoryGenre[] = ["adventure", "mystery", "comedy", "fantasy"];
const toneOptions: StoryTone[] = ["cinematic", "playful", "mysterious", "hopeful"];
const generationStages = ["Understanding your character", "Retrieving story memory", "Directing the scene", "Animating the episode", "Checking consistency"];

export default function CreateScreen() {
  const router = useRouter();
  const { episodeId, remix } = useLocalSearchParams<{ episodeId?: string | string[]; remix?: string | string[] }>();
  const continuationEpisodeId = Array.isArray(episodeId) ? episodeId[0] : episodeId;
  const isRemix = (Array.isArray(remix) ? remix[0] : remix) === "1";
  const { language, presentation } = useLanguagePreference();
  const direction = textDirection(presentation.direction);
  const row = rowDirection(presentation.direction);
  const copy = getCreateCopy(language);
  const interactionCopy = getCreateInteractionCopy(language);
  const reduceMotion = useReducedMotion();
  const generationProgress = useSharedValue(0);
  const [selectedStyle, setSelectedStyle] = useState("Cinematic");
  const [selectedNext, setSelectedNext] = useState("Adventure");
  const [selectedWorld, setSelectedWorld] = useState("Anime Academy");
  const [genre, setGenre] = useState<StoryGenre>("adventure");
  const [tone, setTone] = useState<StoryTone>("cinematic");
  const [prompt, setPrompt] = useState("");
  const [hasDraft, setHasDraft] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPersisting, setIsPersisting] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [generationStage, setGenerationStage] = useState(0);
  const [generationFailed, setGenerationFailed] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [persistenceStatus, setPersistenceStatus] = useState({ character: false, episode: false });
  const [activePersistenceStage, setActivePersistenceStage] = useState<"character" | "episode" | null>(null);
  const generationTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const generationTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isMounted = useRef(true);
  const generationRun = useRef(0);
  const pendingEpisodeId = useRef<string | null>(null);

  useEffect(() => () => { isMounted.current = false; const emptyTimers = resetGenerationTimers({ generation: generationTimer.current, timeout: generationTimeout.current }); generationTimer.current = emptyTimers.generation; generationTimeout.current = emptyTimers.timeout; }, []);

  useEffect(() => {
    loadCreationDraft().then((draft) => {
      if (!canApplyCreateHydrationState(isMounted.current) || !draft) return;
      setHasDraft(true);
      setSelectedStyle(draft.selectedStyle);
      setSelectedNext(draft.selectedNext);
      setSelectedWorld(draft.selectedWorld);
      if (draft.genre) setGenre(draft.genre as StoryGenre);
      if (draft.tone) setTone(draft.tone as StoryTone);
      setPrompt(draft.prompt);
    }).catch((error) => {
      if (canApplyCreateFeedbackState(isMounted.current)) setErrorMessage(normalizeMorphError(error, "storage").message);
    });
  }, []);

  useEffect(() => {
    saveCreationDraft({ selectedCharacterId: "nova", selectedStyle, selectedNext, selectedWorld, genre, tone, prompt, updatedAt: new Date().toISOString() }).catch((error) => { if (canApplyCreateFeedbackState(isMounted.current)) setErrorMessage(normalizeMorphError(error, "storage").message); });
  }, [genre, prompt, selectedNext, selectedStyle, selectedWorld, tone]);

  useEffect(() => {
    if (!continuationEpisodeId) return;
    loadEpisodes().then((episodes) => {
      if (!canApplyCreateHydrationState(isMounted.current)) return;
      const episode = episodes.find((item) => item.id === continuationEpisodeId);
      if (!episode) return;
      setSelectedWorld(episode.world);
      setPrompt((current) => current || buildEpisodeContinuationPrompt(episode, isRemix));
    }).catch(() => undefined);
  }, [continuationEpisodeId, isRemix]);

  const pickFromLibrary = async () => { try { const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 3], quality: 0.85 }); if (!result.canceled && result.assets[0]) setReferenceImage(result.assets[0].uri); } catch (error) { setErrorMessage(normalizeMorphError(error, "media").message); } };

  const takePhoto = async () => { try {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (permission.status !== ImagePicker.PermissionStatus.GRANTED) {
      Alert.alert(interactionCopy.cameraPermissionTitle, interactionCopy.cameraPermissionBody);
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [4, 3], quality: 0.85 });
    if (!result.canceled && result.assets[0]) setReferenceImage(result.assets[0].uri);
    } catch (error) { setErrorMessage(normalizeMorphError(error, "media").message); }
  };

  useEffect(() => {
    generationProgress.value = withTiming(isGenerating ? (generationStage + 1) / generationStages.length : 0, { duration: reduceMotion ? 0 : 260 });
  }, [generationProgress, generationStage, isGenerating, reduceMotion]);

  const generationProgressStyle = useAnimatedStyle(() => ({ transform: [{ scaleX: generationProgress.value }] }));

  useEffect(() => {
    if (!isGenerating) return;
    const timer = setInterval(() => setGenerationStage((current) => Math.min(current + 1, generationStages.length - 1)), 480);
    return () => clearInterval(timer);
  }, [isGenerating]);

  useEffect(() => { loadEpisodes().then((episodes) => { const latest = episodes.find((episode) => episode.branchChoiceId); if (latest && !prompt) setPrompt(formatBranchContinuation({ id: latest.branchChoiceId ?? "branch", label: "Continue the chosen path", consequence: latest.synopsis }, latest.title)); }); }, [prompt]);

  const generate = () => {
    if (!canStartGeneration(isGenerating, isPersisting)) return;
    const runId = nextGenerationRunId(generationRun.current);
    generationRun.current = runId;
    setGenerationStage(0);
    setGenerationFailed(false);
    setErrorMessage(null);
    setPersistenceStatus({ character: false, episode: false });
    setActivePersistenceStage(null);
    setIsPersisting(false);
    setIsGenerating(true);
    if (generationTimeout.current) clearTimeout(generationTimeout.current);
    generationTimeout.current = setTimeout(() => { if (!canApplyGenerationResult(isMounted.current, generationRun.current === runId)) return; const emptyTimers = resetGenerationTimers({ generation: generationTimer.current, timeout: generationTimeout.current }); generationTimer.current = emptyTimers.generation; generationTimeout.current = emptyTimers.timeout; setIsGenerating(false); setGenerationFailed(true); setErrorMessage(normalizeMorphError(new Error("generation timeout"), "generation").message); }, 6500);
    generationTimer.current = setTimeout(() => {
      if (!canApplyGenerationResult(isMounted.current, generationRun.current === runId)) return;
      const emptyTimers = resetGenerationTimers({ generation: generationTimer.current, timeout: generationTimeout.current });
      generationTimer.current = emptyTimers.generation;
      generationTimeout.current = emptyTimers.timeout;
      if (prompt.toLowerCase().includes("fail")) { setIsGenerating(false); setGenerationFailed(true); return; }
      setIsGenerating(false);
      setIsPersisting(true);
      void (async () => {
        const createdAt = new Date().toISOString();
        const episodeId = pendingEpisodeId.current ?? `episode-${Date.now()}`;
        pendingEpisodeId.current = episodeId;
        const outcome = await persistCreationRecords({
          saveCharacter: async () => {
            if (!canApplyGenerationState(isMounted.current, generationRun.current === runId)) return;
            setActivePersistenceStage("character");
            await upsertCharacter({ id: "nova", name: "Nova", style: selectedStyle, personality: [selectedNext], color: "#8B7CFF", status: "ready", updatedAt: createdAt, dna: { identityDescription: "A persistent MORPH protagonist shaped by the creator’s reference photo.", visualStyle: selectedStyle, personality: [selectedNext], referenceImageUri: referenceImage ?? undefined, version: 1 } });
            if (canApplyGenerationState(isMounted.current, generationRun.current === runId)) setPersistenceStatus((current) => ({ ...current, character: true }));
          },
          saveEpisode: async () => {
            if (!canApplyGenerationState(isMounted.current, generationRun.current === runId)) return;
            setActivePersistenceStage("episode");
            await saveEpisode({ id: episodeId, title: "The hidden club", world: selectedWorld, characterName: "Nova", synopsis: "Nova finds a door that only appears when the last bell rings.", status: "completed", createdAt });
            if (canApplyGenerationState(isMounted.current, generationRun.current === runId)) setPersistenceStatus((current) => ({ ...current, episode: true }));
          },
          clearDraft: clearCreationDraft,
        });
        if (!canApplyGenerationResult(isMounted.current, generationRun.current === runId)) return;
        if (outcome.error) {
          setIsPersisting(false);
          setGenerationFailed(true);
          setHasDraft(true);
          const failedStage = outcome.failedStage ?? "episode";
          const requestFeedback = getCreateRequestFeedback(outcome.error, copy);
          setErrorMessage(requestFeedback ?? `${failedStage === "character" ? copy.characterSaveFailed : copy.episodeSaveFailed} ${normalizeMorphError(outcome.error, "storage").message}`);
          void saveCreationDraft({ selectedCharacterId: "nova", selectedStyle, selectedNext, selectedWorld, genre, tone, prompt, updatedAt: new Date().toISOString() }).catch(() => undefined);
          return;
        }
        setPersistenceStatus({ character: true, episode: true });
        setIsPersisting(false);
        setActivePersistenceStage(null);
        pendingEpisodeId.current = null;
        router.push("/episode-ready");
      })();
    }, 2500);
  };

  const cancelGeneration = () => {
    generationRun.current = nextGenerationRunId(generationRun.current);
    const emptyTimers = resetGenerationTimers({ generation: generationTimer.current, timeout: generationTimeout.current });
    generationTimer.current = emptyTimers.generation;
    generationTimeout.current = emptyTimers.timeout;
    setIsGenerating(false);
    setIsPersisting(false);
    setGenerationStage(0);
  };

  const retrySave = () => {
    if (!canStartPersistenceRetry(isPersisting)) return;
    const episodeId = pendingEpisodeId.current;
    if (!episodeId) { generate(); return; }
    const runId = nextGenerationRunId(generationRun.current);
    generationRun.current = runId;
    setGenerationFailed(false);
    setErrorMessage(null);
    setIsPersisting(true);
    void (async () => {
      const createdAt = new Date().toISOString();
      const outcome = await persistCreationRecords({
        saveCharacter: async () => {
          if (!canApplyGenerationState(isMounted.current, generationRun.current === runId)) return;
          setActivePersistenceStage("character");
          await upsertCharacter({ id: "nova", name: "Nova", style: selectedStyle, personality: [selectedNext], color: "#8B7CFF", status: "ready", updatedAt: createdAt, dna: { identityDescription: "A persistent MORPH protagonist shaped by the creator’s reference photo.", visualStyle: selectedStyle, personality: [selectedNext], referenceImageUri: referenceImage ?? undefined, version: 1 } });
          if (canApplyGenerationState(isMounted.current, generationRun.current === runId)) setPersistenceStatus((current) => ({ ...current, character: true }));
        },
        saveEpisode: async () => {
          if (!canApplyGenerationState(isMounted.current, generationRun.current === runId)) return;
          setActivePersistenceStage("episode");
          await saveEpisode({ id: episodeId, title: "The hidden club", world: selectedWorld, characterName: "Nova", synopsis: "Nova finds a door that only appears when the last bell rings.", status: "completed", createdAt });
          if (canApplyGenerationState(isMounted.current, generationRun.current === runId)) setPersistenceStatus((current) => ({ ...current, episode: true }));
        },
        clearDraft: clearCreationDraft,
      });
      if (!canApplyGenerationResult(isMounted.current, generationRun.current === runId)) return;
      if (outcome.error) {
        setIsPersisting(false);
        setGenerationFailed(true);
        setHasDraft(true);
        const failedStage = outcome.failedStage ?? "episode";
        setErrorMessage(`${failedStage === "character" ? copy.characterSaveFailed : copy.episodeSaveFailed} ${normalizeMorphError(outcome.error, "storage").message}`);
        return;
      }
      setPersistenceStatus({ character: true, episode: true });
      setIsPersisting(false);
      setActivePersistenceStage(null);
      pendingEpisodeId.current = null;
      router.push("/episode-ready");
    })();
  };

  const retryGeneration = () => {
    if (!canStartGeneration(isGenerating, isPersisting)) return;
    pendingEpisodeId.current = null;
    setGenerationFailed(false);
    generate();
  };

  const persistenceLabels = getPersistenceUiLabels({ activeStage: activePersistenceStage, characterSaved: persistenceStatus.character, episodeSaved: persistenceStatus.episode }, copy);
  const persistenceAccessibilityState = getPersistenceAccessibilityState({ activeStage: activePersistenceStage });
  const retrySaveAccessibilityState = getRetrySaveAccessibilityState(isPersisting);
  const retryGenerationAccessibilityState = getGenerationRetryAccessibilityState(isGenerating, isPersisting);

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styleSheet.content}>
        <View style={[styleSheet.topRow, row]}><Pressable accessibilityRole="button" accessibilityLabel={copy.back} accessibilityHint={interactionCopy.backHint} onPress={() => router.back()}><Text style={styleSheet.back}>‹</Text></Pressable><Text style={styleSheet.step}>CREATE / 01</Text><View style={{ width: 28 }} /></View>
        <Text style={[styleSheet.title, direction]}>{copy.title}</Text>
        <Text style={[styleSheet.subtitle, direction]}>{copy.subtitle}</Text>
        {errorMessage && <View style={styleSheet.errorBanner}><Text style={styleSheet.errorText}>{errorMessage}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.dismiss} onPress={() => setErrorMessage(null)}><Text style={styleSheet.dismissText}>{interactionCopy.dismiss}</Text></Pressable></View>}
        {hasDraft && <View style={styleSheet.recovery}><Text style={[styleSheet.recoveryTitle, direction]}>{copy.recovered}</Text><Text style={styleSheet.recoveryCopy}>{interactionCopy.draftRecovery}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.discard} accessibilityHint={interactionCopy.discardHint} onPress={() => setHasDraft(false)}><Text style={styleSheet.discardText}>{copy.discard}</Text></Pressable></View>}
        <Text style={[styleSheet.label, direction]}>{copy.characterLabel}</Text>
        <View style={styleSheet.photoCard}>{referenceImage ? <Image source={{ uri: referenceImage }} style={styleSheet.referenceImage} /> : <View style={styleSheet.photoOrb} />}<View style={{ flex: 1 }}><Text style={styleSheet.photoTitle}>{referenceImage ? copy.reference : "Nova"}</Text><Text style={styleSheet.photoMeta}>{referenceImage ? copy.ready : copy.hero}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={copy.library} accessibilityHint={copy.libraryHint} accessibilityState={{ selected: Boolean(referenceImage) }} onPress={pickFromLibrary} style={styleSheet.photoAction}><Text style={styleSheet.photoActionText}>{copy.library}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={copy.camera} accessibilityHint={copy.cameraHint} onPress={takePhoto} style={styleSheet.photoAction}><Text style={styleSheet.photoActionText}>{copy.camera}</Text></Pressable></View>
        <Text style={[styleSheet.label, direction]}>{copy.styleLabel}</Text>
        <View style={styleSheet.chips}>{renderChips(styleOptions, selectedStyle, setSelectedStyle)}</View>
        <Text style={[styleSheet.label, direction]}>{copy.nextLabel}</Text>
        <View style={styleSheet.chips}>{renderChips(nextOptions, selectedNext, setSelectedNext)}</View>
        <Text style={[styleSheet.label, direction]}>{copy.genreLabel}</Text>
        <View style={styleSheet.chips}>{renderChips(genreOptions, genre, setGenre)}</View>
        <Text style={[styleSheet.label, direction]}>{copy.toneLabel}</Text>
        <View style={styleSheet.chips}>{renderChips(toneOptions, tone, setTone)}</View>
        <Text style={[styleSheet.label, direction]}>{copy.worldLabel}</Text>
        <View style={styleSheet.chips}>{renderChips(worldOptions, selectedWorld, setSelectedWorld)}</View>
        <Text style={[styleSheet.label, direction]}>{copy.note} <Text style={styleSheet.optional}>{copy.optional}</Text></Text>
        <View style={styleSheet.promptHeader}><Text style={[styleSheet.promptHint, direction]}>{copy.promptHint}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.surprise.replace(" ↗", "")} accessibilityHint={interactionCopy.creativeIdeaHint} onPress={() => { const seed = randomizeSeed(); setGenre(seed.genre); setTone(seed.mood); setPrompt(`A ${seed.object} appears in a ${seed.location}. ${seed.constraint}`); }}><Text style={styleSheet.seedText}>{copy.surprise}</Text></Pressable></View>
        <TextInput value={prompt} onChangeText={setPrompt} placeholder={copy.premisePlaceholder} placeholderTextColor="#6F6B7B" multiline style={styleSheet.input} />
        <View style={styleSheet.premiseCard}><Text style={styleSheet.premiseKicker}>{copy.premiseKicker}</Text><Text style={styleSheet.premiseText}>{buildPremiseSummary({ idea: prompt, genre, tone, world: selectedWorld, character: "Nova" })}</Text><Text style={styleSheet.premiseMeta}>{tone} · {genre} · {selectedWorld}</Text></View>
        {isPersisting && <Animated.View entering={reduceMotion ? undefined : FadeIn.duration(180)}><View accessibilityRole="progressbar" accessibilityLabel={persistenceLabels.active} accessibilityState={persistenceAccessibilityState} style={styleSheet.stageRow}><ActivityIndicator color="#D7F36B" /><Text style={styleSheet.stageText}>{persistenceLabels.active}</Text></View></Animated.View>}
        {isGenerating && <Animated.View entering={reduceMotion ? undefined : FadeIn.duration(220)} exiting={reduceMotion ? undefined : FadeOut.duration(160)}><View style={styleSheet.stageRow}><View style={styleSheet.stageDot} /><Text style={styleSheet.stageText}>{generationStages[generationStage]}</Text><Text style={styleSheet.stageCount}>{generationStage + 1}/{generationStages.length}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.cancel} accessibilityHint={interactionCopy.cancelHint} onPress={cancelGeneration}><Text style={styleSheet.cancelText}>{copy.cancel}</Text></Pressable></View><View accessibilityLabel={`${generationStage + 1} of ${generationStages.length} generation stages`} accessibilityRole="progressbar" style={styleSheet.stageTrack}><Animated.View style={[styleSheet.stageFill, generationProgressStyle]} /></View></Animated.View>}
        {generationFailed && <View style={styleSheet.failure}><Text style={[styleSheet.failureTitle, direction]}>{copy.failureTitle}</Text><Text style={[styleSheet.failureCopy, direction]}>{copy.failureCopy}</Text><View accessibilityLiveRegion="polite" style={styleSheet.persistenceSummary}><Text style={styleSheet.persistenceStatus}>{persistenceLabels.character}</Text><Text style={styleSheet.persistenceStatus}>{persistenceLabels.episode}</Text></View><View style={styleSheet.failureActions}><Pressable accessibilityRole="button" accessibilityLabel={copy.retrySave} accessibilityHint={interactionCopy.retrySaveHint} accessibilityState={retrySaveAccessibilityState} disabled={retrySaveAccessibilityState.disabled} onPress={retrySave}><Text style={styleSheet.retryText}>{copy.retrySave}</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={copy.retry.replace(" ↗", "")} accessibilityHint={interactionCopy.retryGenerationHint} accessibilityState={retryGenerationAccessibilityState} disabled={retryGenerationAccessibilityState.disabled} onPress={retryGeneration}><Text style={styleSheet.retryText}>{copy.retry}</Text></Pressable></View></View>}
        <Pressable accessibilityRole="button" accessibilityLabel={isPersisting ? copy.persisting : isGenerating ? copy.building : copy.generate} accessibilityState={{ disabled: isGenerating || isPersisting, busy: isGenerating || isPersisting }} onPress={generate} disabled={isGenerating || isPersisting} style={({ pressed }) => [styleSheet.generate, pressed && { opacity: 0.85 }, isGenerating && { backgroundColor: "#8B7CFF" }]}><Text style={styleSheet.generateText}>{isPersisting ? copy.persisting : isGenerating ? copy.building : copy.generate}</Text><Text style={styleSheet.generateArrow}>↗</Text></Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

function renderChips<T extends string>(items: T[], selected: T, setSelected: (value: T) => void) {
  return items.map((item) => <Pressable key={item} accessibilityRole="button" accessibilityLabel={item} accessibilityState={{ selected: item === selected }} onPress={() => setSelected(item)} style={[styleSheet.chip, item === selected && styleSheet.chipSelected]}><Text style={[styleSheet.chipText, item === selected && styleSheet.chipTextSelected]}>{item}</Text></Pressable>);
}

const styleSheet = StyleSheet.create({
  content: { paddingBottom: morphTokens.spacing.xxxl }, topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: morphTokens.spacing.sm, marginBottom: morphTokens.spacing.xxxl }, back: { color: "#F7F4EF", fontSize: 34, lineHeight: 30 }, step: { color: "#A9A6B2", fontSize: 10, letterSpacing: 1.8, fontWeight: "800" }, title: { color: "#F7F4EF", fontSize: morphTokens.typography.display.fontSize, lineHeight: morphTokens.typography.display.lineHeight, fontWeight: "800", letterSpacing: -0.8 }, subtitle: { color: "#A9A6B2", fontSize: 14, marginTop: 10, marginBottom: 30 }, label: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.5, marginBottom: 10, marginTop: 18 }, optional: { color: "#6F6B7B", fontSize: 9 }, photoCard: { height: 76, borderRadius: morphTokens.radius.xl, borderWidth: 1, borderColor: "#2B2A3A", backgroundColor: "#151521", flexDirection: "row", alignItems: "center", padding: 10 }, photoOrb: { width: 54, height: 54, borderRadius: 16, backgroundColor: "#8B7CFF", marginRight: 13 }, stageRow: { flexDirection: "row", alignItems: "center", marginTop: 18, paddingHorizontal: 2 }, stageTrack: { height: 4, borderRadius: 4, overflow: "hidden", backgroundColor: "#2B2A3A", marginTop: 10 }, stageFill: { width: "100%", height: "100%", borderRadius: 4, backgroundColor: "#D7F36B", transformOrigin: "left" }, stageDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: "#D7F36B", marginRight: 8 }, stageText: { flex: 1, color: "#A9A6B2", fontSize: 12 }, stageCount: { color: "#6F6B7B", fontSize: 11, fontWeight: "800" }, failure: { marginTop: 18, padding: 14, borderRadius: 15, borderWidth: 1, borderColor: "#5B3037", backgroundColor: "#24171F" }, failureTitle: { color: "#FF8A8A", fontWeight: "800", fontSize: 13 }, failureCopy: { color: "#A9A6B2", fontSize: 12, lineHeight: 17, marginTop: 5 }, persistenceSummary: { marginTop: 10, gap: 4 }, persistenceStatus: { color: "#D7F36B", fontSize: 11, fontWeight: "700" }, failureActions: { flexDirection: "row", flexWrap: "wrap", gap: 16 }, retryText: { color: "#D7F36B", fontSize: 12, fontWeight: "800", marginTop: 11 }, cancelText: { color: "#FF8A8A", fontSize: 11, fontWeight: "800", marginLeft: 10 }, referenceImage: { width: 54, height: 54, borderRadius: 16, marginRight: 13 }, photoAction: { borderWidth: 1, borderColor: "#353447", borderRadius: 10, paddingVertical: 8, paddingHorizontal: 8, marginLeft: 5 }, photoActionText: { color: "#D7F36B", fontSize: 10, fontWeight: "800" }, photoTitle: { color: "#F7F4EF", fontSize: 15, fontWeight: "800" }, photoMeta: { color: "#A9A6B2", fontSize: 11, marginTop: 3 }, chevron: { color: "#A9A6B2", fontSize: 28, marginLeft: "auto" }, chips: { flexDirection: "row", flexWrap: "wrap", gap: morphTokens.spacing.sm }, chip: { borderWidth: 1, borderColor: "#353447", borderRadius: 100, paddingVertical: 10, paddingHorizontal: 13 }, chipSelected: { backgroundColor: "#D7F36B", borderColor: "#D7F36B" }, chipText: { color: "#A9A6B2", fontSize: 12, fontWeight: "700" }, chipTextSelected: { color: "#0B0B10" }, errorBanner: { padding: 12, borderRadius: 14, backgroundColor: "#2A1B22", borderWidth: 1, borderColor: "#6A3542", marginBottom: 8, flexDirection: "row", alignItems: "center" }, errorText: { flex: 1, color: "#FFB3B3", fontSize: 11, lineHeight: 16 }, dismissText: { color: "#D7F36B", fontSize: 11, fontWeight: "800", marginLeft: 8 }, recovery: { padding: 14, borderRadius: 16, backgroundColor: "#1A1924", borderWidth: 1, borderColor: "#3B3854", marginBottom: 6 }, recoveryTitle: { color: "#F7F4EF", fontSize: 13, fontWeight: "800" }, recoveryCopy: { color: "#A9A6B2", fontSize: 11, lineHeight: 16, marginTop: 5 }, discardText: { color: "#FF8A8A", fontSize: 11, fontWeight: "800", marginTop: 9 }, premiseCard: { marginTop: 20, padding: 15, borderRadius: 17, backgroundColor: "#191925", borderWidth: 1, borderColor: "#34334A" }, premiseKicker: { color: "#D7F36B", fontSize: 9, fontWeight: "900", letterSpacing: 1.4 }, premiseText: { color: "#F7F4EF", fontSize: 14, lineHeight: 20, fontWeight: "700", marginTop: 8 }, premiseMeta: { color: "#A9A6B2", fontSize: 11, marginTop: 9, textTransform: "capitalize" }, promptHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }, promptHint: { color: "#A9A6B2", fontSize: 12 }, seedText: { color: "#D7F36B", fontSize: 12, fontWeight: "800" }, input: { minHeight: 74, borderRadius: 16, borderWidth: 1, borderColor: "#2B2A3A", backgroundColor: "#151521", padding: 14, color: "#F7F4EF", textAlignVertical: "top", fontSize: 14 }, generate: { marginTop: morphTokens.spacing.xxl, height: 56, borderRadius: morphTokens.radius.lg, backgroundColor: "#D7F36B", flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 18 }, generateText: { color: "#0B0B10", fontSize: 15, fontWeight: "800" }, generateArrow: { color: "#0B0B10", fontSize: 22, fontWeight: "700" },
});
