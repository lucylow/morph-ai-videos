import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { loadCharacters, type LocalCharacter } from "@/src/storage/morph-repository";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { textDirection } from "@/src/localization/layout";
import { getCharactersCopy } from "@/src/localization/screen-copy";
import { morphTokens } from "@/src/ui/morph-tokens";

export default function CharactersScreen() {
  const router = useRouter();
  const { language, presentation } = useLanguagePreference();
  const direction = textDirection(presentation.direction);
  const copy = getCharactersCopy(language);
  const [characters, setCharacters] = useState<LocalCharacter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setCharacters(await loadCharacters());
    } catch {
      setError(copy.error);
    } finally {
      setLoading(false);
    }
  }, [copy.error]);

  useEffect(() => { void refresh(); }, [refresh]);

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right"]}>
      <FlatList
        data={characters}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.content}
        refreshing={loading && characters.length > 0}
        onRefresh={() => void refresh()}
        ListHeaderComponent={
          <>
            <Text style={[styles.kicker, direction]}>{copy.kicker}</Text>
            <Text style={[styles.title, direction]}>{copy.title}</Text>
            <Text style={[styles.subtitle, direction]}>{copy.subtitle}</Text>
            <Pressable accessibilityRole="button" accessibilityLabel={copy.create} accessibilityHint="Opens character creation" onPress={() => router.push("/create")} style={({ pressed }) => [styles.add, pressed && styles.pressed]}>
              <Text style={styles.addText}>+  {copy.create}</Text><Text style={styles.addArrow}>↗</Text>
            </Pressable>
            {loading && characters.length === 0 ? <View style={styles.state}><ActivityIndicator color="#D7F36B" /><Text style={[styles.stateText, direction]}>{copy.loading}</Text></View> : null}
            {!loading && error ? <View style={styles.state}><Text style={[styles.stateText, direction]}>{error}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.retry} accessibilityHint="Reloads your character vault" onPress={() => void refresh()} style={styles.retry}><Text style={styles.retryText}>{copy.retry}</Text></Pressable></View> : null}
            {!loading && !error && characters.length === 0 ? <View style={styles.state}><Text style={[styles.stateText, direction]}>{copy.empty}</Text></View> : null}
          </>
        }
        renderItem={({ item }) => (
          <Pressable accessibilityRole="button" accessibilityLabel={`${item.name}, ${item.style}, ${item.personality[0] ?? copy.unwritten}`} accessibilityHint="Opens character details" onPress={() => router.push({ pathname: "/character-detail", params: { id: item.id } })} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
            <View style={[styles.avatar, { backgroundColor: item.color }]}><View style={styles.avatarGlow} /></View>
            <View style={styles.copy}><Text style={styles.name}>{item.name}</Text><Text style={styles.meta}>{item.style} · {item.personality[0] ?? copy.unwritten}</Text></View><Text style={styles.arrow}>›</Text>
          </Pressable>
        )}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: morphTokens.spacing.xxxl, paddingBottom: morphTokens.spacing.xxxl }, kicker: { color: "#FF7B68", fontSize: 10, fontWeight: "800", letterSpacing: 1.8, marginBottom: 12 }, title: { color: "#F7F4EF", fontSize: 32, lineHeight: 35, fontWeight: "800" }, subtitle: { color: "#A9A6B2", fontSize: 14, marginTop: 10, marginBottom: 26 }, add: { height: 55, borderRadius: morphTokens.radius.lg, backgroundColor: "#D7F36B", flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 17, marginBottom: 22 }, addText: { color: "#0B0B10", fontWeight: "800", fontSize: 14 }, addArrow: { color: "#0B0B10", fontSize: 21 }, card: { backgroundColor: morphTokens.colors.surface, borderRadius: morphTokens.radius.xl, borderWidth: 1, borderColor: "#2B2A3A", padding: 10, flexDirection: "row", alignItems: "center", marginBottom: 12 }, avatar: { width: 66, height: 66, borderRadius: 19, overflow: "hidden", justifyContent: "center", alignItems: "center" }, avatarGlow: { width: 44, height: 44, borderRadius: 22, backgroundColor: "rgba(255,255,255,0.2)" }, copy: { paddingLeft: 14, flex: 1 }, name: { color: "#F7F4EF", fontSize: 16, fontWeight: "800" }, meta: { color: "#A9A6B2", fontSize: 12, marginTop: 4 }, arrow: { color: "#A9A6B2", fontSize: 28, paddingRight: 8 }, state: { alignItems: "center", paddingVertical: 18, gap: 10 }, stateText: { color: "#A9A6B2", fontSize: 13, lineHeight: 19, textAlign: "center" }, retry: { backgroundColor: "#2B2A3A", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 }, retryText: { color: "#D7F36B", fontWeight: "800" }, pressed: { opacity: 0.78 },
});
