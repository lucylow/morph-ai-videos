import { useRouter } from "expo-router";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { ScreenContainer } from "@/components/screen-container";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { rowDirection, textDirection } from "@/src/localization/layout";
import { morphTokens } from "@/src/ui/morph-tokens";
import { getWorldsCopy } from "@/src/localization/screen-copy";

const worlds = [{ name: "Anime Academy", genre: "Coming of age", color: "#8B7CFF" }, { name: "Orbit 09", genre: "Sci-fi mystery", color: "#5CA8FF" }, { name: "Pixel City", genre: "Arcade adventure", color: "#FF7B68" }, { name: "Mosslight", genre: "Forest fantasy", color: "#D7F36B" }];

export default function WorldsScreen() {
  const router = useRouter();
  const { language, presentation } = useLanguagePreference();
  const direction = textDirection(presentation.direction);
  const row = rowDirection(presentation.direction);
  const copy = getWorldsCopy(language);
  return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right"]}><FlatList data={worlds} keyExtractor={(item) => item.name} contentContainerStyle={styles.content} ListHeaderComponent={<><View style={[styles.top, row]}><Pressable accessibilityRole="button" accessibilityLabel={copy.back} accessibilityHint="Returns to the previous screen" onPress={() => router.back()}><Text style={styles.back}>‹</Text></Pressable><Text style={[styles.kicker, direction]}>{copy.kicker}</Text><View style={{ width: 28 }} /></View><Text style={[styles.title, direction]}>{copy.title}</Text><Text style={[styles.subtitle, direction]}>{copy.subtitle}</Text></>} renderItem={({ item, index }) => <Pressable accessibilityRole="button" accessibilityLabel={`${item.name}, ${item.genre}`} accessibilityHint={copy.openWorld} onPress={() => router.push("/create")} style={({ pressed }) => [styles.card, row, pressed && { opacity: 0.78 }]}><LinearGradient colors={[item.color, "#151521"]} style={styles.art}><View style={styles.sun} /><Text style={styles.number}>0{index + 1}</Text></LinearGradient><View style={styles.copy}><Text style={styles.name}>{item.name}</Text><Text style={styles.genre}>{item.genre}</Text></View><Text style={styles.arrow}>↗</Text></Pressable>} /></ScreenContainer>;
}
const styles = StyleSheet.create({ content: { paddingBottom: morphTokens.spacing.xxxl }, top: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: morphTokens.spacing.sm, marginBottom: morphTokens.spacing.xxl }, back: { color: "#F7F4EF", fontSize: 34, lineHeight: 30 }, kicker: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.8 }, title: { color: "#F7F4EF", fontSize: 32, lineHeight: 35, fontWeight: "800" }, subtitle: { color: "#A9A6B2", fontSize: 14, lineHeight: 20, marginTop: 10, marginBottom: 26 }, card: { backgroundColor: morphTokens.colors.surface, borderRadius: morphTokens.radius.xl, marginBottom: morphTokens.spacing.md, overflow: "hidden", borderWidth: 1, borderColor: morphTokens.colors.border, flexDirection: "row", alignItems: "center" }, art: { width: 122, height: 104, justifyContent: "flex-end", padding: 11 }, sun: { width: 43, height: 43, borderRadius: 22, backgroundColor: "rgba(255,255,255,0.24)", position: "absolute", top: 15, right: 14 }, number: { color: "rgba(255,255,255,0.75)", fontSize: 11, fontWeight: "800" }, copy: { paddingHorizontal: 15, flex: 1 }, name: { color: "#F7F4EF", fontSize: 15, fontWeight: "800" }, genre: { color: "#A9A6B2", fontSize: 12, marginTop: 5 }, arrow: { color: "#D7F36B", fontSize: 21, fontWeight: "700", paddingRight: 15 } });
