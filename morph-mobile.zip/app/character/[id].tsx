import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { defaultCharacters, loadCharacters, saveCharacters, type LocalCharacter } from "@/src/storage/morph-repository";
import { normalizeMorphError } from "@/src/core/errors";

const styleOptions = ["Cinematic", "Anime", "Clay", "Pixel"];
const personalityOptions = ["Brave", "Curious", "Chaotic", "Funny", "Mysterious"];

export default function DynamicCharacterScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const [character, setCharacter] = useState<LocalCharacter>(defaultCharacters[0]);
  const [name, setName] = useState(defaultCharacters[0].name);
  const [style, setStyle] = useState(defaultCharacters[0].style);
  const [personality, setPersonality] = useState(defaultCharacters[0].personality[0]);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    void loadCharacters().then((items) => {
      if (!active) return;
      const found = items.find((item) => item.id === id) ?? items[0] ?? defaultCharacters[0];
      setCharacter(found); setName(found.name); setStyle(found.dna?.visualStyle ?? found.style); setPersonality(found.dna?.personality[0] ?? found.personality[0]);
    }).catch((error) => { if (active) setErrorMessage(normalizeMorphError(error, "storage").message); }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [id]);

  const saveEdits = async () => {
    const normalizedName = name.trim().replace(/\s+/g, " ");
    if (!normalizedName) { Alert.alert("Give your character a name", "A character needs a name before it can enter a story."); return; }
    const updated: LocalCharacter = { ...character, name: normalizedName, style, personality: [personality], updatedAt: new Date().toISOString(), dna: { identityDescription: character.dna?.identityDescription ?? "A persistent MORPH protagonist.", visualStyle: style, personality: [personality], referenceImageUri: character.dna?.referenceImageUri, version: (character.dna?.version ?? 0) + 1 } };
    setSaving(true); setErrorMessage(null);
    try {
      const all = await loadCharacters();
      await saveCharacters([updated, ...all.filter((item) => item.id !== updated.id)]);
      setCharacter(updated); setIsEditing(false); Alert.alert("Character updated", `${normalizedName} is ready for another story.`);
    } catch (error) { setErrorMessage(normalizeMorphError(error, "storage").message); } finally { setSaving(false); }
  };

  if (loading) return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><View style={styles.loading}><Text style={styles.subtitle}>Opening character…</Text></View></ScreenContainer>;

  return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>{errorMessage ? <View style={styles.errorBanner}><Text style={styles.errorText}>{errorMessage}</Text><Pressable accessibilityRole="button" accessibilityLabel="Dismiss error" onPress={() => setErrorMessage(null)}><Text style={styles.edit}>Dismiss</Text></Pressable></View> : null}<View style={styles.top}><Pressable onPress={() => router.back()}><Text style={styles.back}>‹</Text></Pressable><Text style={styles.kicker}>CHARACTER / V{character.dna?.version ?? 1}</Text><Pressable onPress={() => setIsEditing((value) => !value)}><Text style={styles.edit}>{isEditing ? "Done" : "Edit"}</Text></Pressable></View><View style={[styles.hero, { backgroundColor: character.color }]}><View style={styles.heroOrb} /><Text style={styles.heroIndex}>MORPH / {character.id.toUpperCase()}</Text></View>{isEditing ? <><Text style={styles.label}>NAME</Text><TextInput value={name} onChangeText={setName} style={styles.input} placeholderTextColor="#6F6B7B" /><Text style={styles.label}>VISUAL STYLE</Text><View style={styles.chips}>{styleOptions.map((item) => <Pressable key={item} onPress={() => setStyle(item)} style={[styles.chip, item === style && styles.selected]}><Text style={[styles.chipText, item === style && styles.selectedText]}>{item}</Text></Pressable>)}</View><Text style={styles.label}>PERSONALITY</Text><View style={styles.chips}>{personalityOptions.map((item) => <Pressable key={item} onPress={() => setPersonality(item)} style={[styles.chip, item === personality && styles.selected]}><Text style={[styles.chipText, item === personality && styles.selectedText]}>{item}</Text></Pressable>)}</View><Pressable onPress={() => void saveEdits()} disabled={saving} accessibilityRole="button" accessibilityLabel={saving ? "Saving character" : "Save character"} style={[styles.primary, saving && styles.disabled]}><Text style={styles.primaryText}>Save character</Text><Text style={styles.primaryArrow}>↗</Text></Pressable></> : <><Text style={styles.name}>{character.name}</Text><Text style={styles.subtitle}>{character.dna?.identityDescription ?? "A recurring protagonist ready for infinite stories."}</Text><Pressable onPress={() => router.push("/create")} style={styles.primary}><Text style={styles.primaryText}>Create an episode</Text><Text style={styles.primaryArrow}>↗</Text></Pressable><Text style={styles.section}>IDENTITY ANCHORS</Text><View style={styles.grid}><Info label="STYLE" value={character.dna?.visualStyle ?? character.style} /><Info label="TEMPERAMENT" value={character.dna?.personality[0] ?? character.personality[0]} /><Info label="STATUS" value={character.status === "ready" ? "Ready for stories" : character.status} /><Info label="MEMORY" value="Persistent" /></View></>}</ScrollView></ScreenContainer>;
}
function Info({ label, value }: { label: string; value: string }) { return <View style={styles.info}><Text style={styles.infoLabel}>{label}</Text><Text style={styles.infoValue}>{value}</Text></View>; }
const styles = StyleSheet.create({ content: { paddingBottom: 30 }, loading: { flex: 1, alignItems: "center", justifyContent: "center" }, errorBanner: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#3A2026", borderRadius: 14, borderWidth: 1, borderColor: "#8E3D4A", padding: 12, marginBottom: 14 }, errorText: { color: "#FFB5B5", fontSize: 12, lineHeight: 18, flex: 1 }, disabled: { opacity: 0.5 }, top: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 6, marginBottom: 24 }, back: { color: "#F7F4EF", fontSize: 34, lineHeight: 30 }, kicker: { color: "#A9A6B2", fontSize: 9, fontWeight: "800", letterSpacing: 1.5 }, edit: { color: "#D7F36B", fontSize: 12, fontWeight: "800" }, hero: { height: 220, borderRadius: 25, overflow: "hidden", justifyContent: "flex-end", padding: 16 }, heroOrb: { width: 150, height: 150, borderRadius: 75, backgroundColor: "rgba(255,255,255,0.22)", position: "absolute", top: 30, alignSelf: "center" }, heroIndex: { color: "rgba(255,255,255,0.8)", fontSize: 10, fontWeight: "900", letterSpacing: 1.4 }, name: { color: "#F7F4EF", fontSize: 29, fontWeight: "900", marginTop: 20 }, subtitle: { color: "#A9A6B2", fontSize: 13, lineHeight: 19, marginTop: 7 }, label: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.5, marginTop: 22, marginBottom: 9 }, input: { height: 50, borderRadius: 15, borderWidth: 1, borderColor: "#2B2A3A", backgroundColor: "#151521", paddingHorizontal: 14, color: "#F7F4EF", fontSize: 15 }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, chip: { borderWidth: 1, borderColor: "#353447", borderRadius: 100, paddingVertical: 10, paddingHorizontal: 13 }, selected: { backgroundColor: "#D7F36B", borderColor: "#D7F36B" }, chipText: { color: "#A9A6B2", fontSize: 12, fontWeight: "700" }, selectedText: { color: "#0B0B10" }, primary: { height: 54, borderRadius: 17, backgroundColor: "#D7F36B", flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 18, marginTop: 20 }, primaryText: { color: "#0B0B10", fontSize: 14, fontWeight: "800" }, primaryArrow: { color: "#0B0B10", fontSize: 21 }, section: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.6, marginTop: 30, marginBottom: 12 }, grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 }, info: { width: "48%", backgroundColor: "#151521", borderRadius: 15, padding: 13, borderWidth: 1, borderColor: "#2B2A3A" }, infoLabel: { color: "#6F6B7B", fontSize: 9, fontWeight: "800", letterSpacing: 1.2 }, infoValue: { color: "#F7F4EF", fontSize: 13, fontWeight: "700", marginTop: 7 } });
