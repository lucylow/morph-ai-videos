import { useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { loadEpisodes, type LocalEpisode } from "@/src/storage/morph-repository";
import { getStoryLeaves, getStoryPath, mergeCompletedStoryNodes, type StoryGraph } from "@/src/story/story-engine";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { textDirection } from "@/src/localization/layout";
import { getStoryMapCopy } from "@/src/localization/screen-copy";
import { morphTokens } from "@/src/ui/morph-tokens";

const graph: StoryGraph = { rootEpisodeId: "episode-01", nodes: [{ id: "root", episodeId: "episode-01", title: "The hidden club" }, { id: "door", episodeId: "episode-02a", choiceId: "follow-door", title: "Inside the impossible room", parentId: "root" }, { id: "milo", episodeId: "episode-02b", choiceId: "ask-milo", title: "A voice from the dark", parentId: "root" }, { id: "night", episodeId: "episode-02c", choiceId: "walk-away", title: "The mystery waits", parentId: "root" }] };

export default function StoryMapScreen() {
  const router = useRouter();
  const { language, presentation } = useLanguagePreference();
  const direction = textDirection(presentation.direction);
  const copy = getStoryMapCopy(language);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasEpisodes, setHasEpisodes] = useState(false);
  const [episodes, setEpisodes] = useState<LocalEpisode[]>([]);
  const storyGraph = mergeCompletedStoryNodes(graph, episodes);
  const path = getStoryPath(storyGraph, "root");
  const leaves = getStoryLeaves(storyGraph);
  const completedCount = storyGraph.nodes.filter((node) => node.completed).length;

  const refresh = useCallback(async () => {
    setLoading(true); setError(null);
    try { const saved = await loadEpisodes(); setEpisodes(saved); setHasEpisodes(saved.length > 0); } catch { setError(copy.error); }
    finally { setLoading(false); }
  }, [copy.error]);

  useEffect(() => { void refresh(); }, [refresh]);

  return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.top}><Pressable accessibilityRole="button" accessibilityLabel={copy.back} accessibilityHint={copy.backHint} onPress={() => router.back()}><Text style={styles.back}>‹</Text></Pressable><Text style={[styles.kicker, direction]}>{copy.kicker}</Text><View style={{ width: 28 }} /></View>
    <Text style={[styles.title, direction]}>{copy.title}</Text><Text style={[styles.subtitle, direction]}>{copy.subtitle}</Text>
    {loading ? <View style={styles.state}><ActivityIndicator color="#D7F36B" /><Text style={[styles.stateText, direction]}>{copy.loading}</Text></View> : error ? <View style={styles.state}><Text style={[styles.stateText, direction]}>{error}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.retry} accessibilityHint={copy.retryHint} onPress={() => void refresh()} style={styles.retry}><Text style={styles.retryText}>{copy.retry}</Text></Pressable></View> : null}
    <Text style={styles.section}>{copy.current}</Text><Text accessibilityLiveRegion="polite" style={[styles.progress, direction]}>{copy.progress(completedCount, storyGraph.nodes.length)}</Text>{path.map((node, index) => <View key={node.id} style={styles.pathRow}><View style={styles.pathRail}><View style={styles.pathDot} />{index < path.length - 1 && <View style={styles.pathLine} />}</View><View style={styles.card}><Text style={styles.episode}>{node.completed ? copy.completed : `EPISODE ${index + 1}`}</Text><Text style={styles.nodeTitle}>{node.title}</Text><Text style={styles.meta}>{node.episodeId}</Text></View></View>)}
    {episodes.length > 0 ? <><Text style={styles.section}>{copy.saved} · {episodes.length}</Text>{episodes.map((episode, index) => <View key={episode.id} style={styles.saved}><View style={[styles.savedDot, { backgroundColor: episode.color ?? "#8B7CFF" }]} /><View style={{ flex: 1 }}><Text style={styles.branchTitle}>{episode.title}</Text><Text style={styles.meta}>{episode.world} · {episode.characterName} · {episode.status}</Text></View><Text style={styles.savedIndex}>0{episodes.length - index}</Text></View>)}</> : null}
    <Text style={styles.section}>{copy.open} · {leaves.length}</Text>{leaves.map((node) => <Pressable key={node.id} accessibilityRole="button" accessibilityLabel={node.title} accessibilityHint={copy.continueHint} onPress={() => router.push("/create")} style={({ pressed }) => [styles.branch, pressed && { opacity: 0.78 }]}><View style={{ flex: 1 }}><Text style={styles.branchTitle}>{node.title}</Text><Text style={styles.meta}>{node.completed ? copy.saved : copy.ready} · {node.episodeId}</Text></View><Text style={styles.arrow}>↗</Text></Pressable>)}
    {!loading && !error && !hasEpisodes ? <Text style={[styles.note, direction]}>{copy.first}</Text> : null}
  </ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingBottom: morphTokens.spacing.xxxl }, top: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: morphTokens.spacing.sm, marginBottom: morphTokens.spacing.xxl }, back: { color: "#F7F4EF", fontSize: 34, lineHeight: 30 }, kicker: { color: "#D7F36B", fontSize: 10, fontWeight: "800", letterSpacing: 1.6 }, title: { color: "#F7F4EF", fontSize: 31, lineHeight: 35, fontWeight: "900" }, subtitle: { color: "#A9A6B2", fontSize: 13, lineHeight: 19, marginTop: 10 }, section: { color: "#A9A6B2", fontSize: 10, fontWeight: "800", letterSpacing: 1.5, marginTop: 28, marginBottom: 12 }, pathRow: { flexDirection: "row", minHeight: 82 }, pathRail: { width: 20, alignItems: "center" }, pathDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#D7F36B", marginTop: 17 }, pathLine: { width: 2, flex: 1, backgroundColor: "#353447", marginTop: 4 }, card: { flex: 1, backgroundColor: morphTokens.colors.surface, borderWidth: 1, borderColor: morphTokens.colors.border, borderRadius: morphTokens.radius.lg, padding: 13, marginLeft: 10, marginBottom: 9 }, episode: { color: "#D7F36B", fontSize: 9, fontWeight: "900", letterSpacing: 1.2 }, nodeTitle: { color: "#F7F4EF", fontSize: 14, fontWeight: "800", marginTop: 6 }, meta: { color: "#A9A6B2", fontSize: 11, marginTop: 4 }, branch: { flexDirection: "row", alignItems: "center", backgroundColor: morphTokens.colors.surface, borderWidth: 1, borderColor: morphTokens.colors.border, borderRadius: morphTokens.radius.lg, padding: 14, marginBottom: 9 }, branchTitle: { color: "#F7F4EF", fontSize: 13, fontWeight: "800" }, arrow: { color: "#D7F36B", fontSize: 20 }, state: { alignItems: "center", paddingVertical: 18, gap: 10 }, progress: { color: "#D7F36B", fontSize: 12, fontWeight: "800", marginTop: 7 }, stateText: { color: "#A9A6B2", fontSize: 13, lineHeight: 19, textAlign: "center" }, retry: { backgroundColor: "#2B2A3A", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 }, retryText: { color: "#D7F36B", fontWeight: "800" },   note: { color: "#6F6C7A", fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 18 }, saved: { flexDirection: "row", alignItems: "center", backgroundColor: morphTokens.colors.surface, borderWidth: 1, borderColor: morphTokens.colors.border, borderRadius: morphTokens.radius.lg, padding: 14, marginBottom: 9 }, savedDot: { width: 9, height: 9, borderRadius: 5, marginRight: 12 }, savedIndex: { color: "#777486", fontSize: 12, fontWeight: "900" },
});
