import { useRouter } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import Animated, { FadeInDown, useReducedMotion } from "react-native-reanimated";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { defaultCharacters, loadCharacters, type LocalCharacter } from "@/src/storage/morph-repository";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { rowDirection, textDirection } from "@/src/localization/layout";
import { morphTokens } from "@/src/ui/morph-tokens";
import { getHomeCopy } from "@/src/localization/home-copy";

const worlds = [
  { id: "academy", title: "Anime Academy", meta: "2.4k stories", colors: ["#8B7CFF", "#201E3E"] },
  { id: "orbit", title: "Orbit 09", meta: "1.8k stories", colors: ["#5CA8FF", "#152A4A"] },
  { id: "pixel", title: "Pixel City", meta: "980 stories", colors: ["#FF7B68", "#44252A"] },
];

const concepts = [
  { title: "You wake up with superpowers", tag: "ACTION", color: "#D7F36B" },
  { title: "Your future self leaves a note", tag: "MYSTERY", color: "#8B7CFF" },
  { title: "A pet becomes your teacher", tag: "CHAOS", color: "#FF7B68" },
];

function Icon({ label, color }: { label: string; color: string }) {
  return <Text style={[styles.icon, { color }]}>{label}</Text>;
}

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const [activeFilter, setActiveFilter] = useState("For you");
  const [savedCharacters, setSavedCharacters] = useState<LocalCharacter[]>(defaultCharacters);
  const { language, presentation } = useLanguagePreference();
  const direction = textDirection(presentation.direction);
  const row = rowDirection(presentation.direction);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let mounted = true;
    loadCharacters().then((items) => { if (mounted) setSavedCharacters(items); });
    return () => { mounted = false; };
  }, []);
  const localizedCopy = getHomeCopy(language);
  const filters = useMemo(() => localizedCopy.filters, [localizedCopy.filters]);

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <FlatList
        data={concepts}
        keyExtractor={(item) => item.title}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <>
            <View style={styles.header}>
              <View>
                <Text style={styles.wordmark}>MORPH</Text>
                <Text style={[styles.eyebrow, { color: colors.muted }]}>YOUR STORY, REIMAGINED</Text>
              </View>
              <Pressable accessibilityRole="button" accessibilityLabel="Open profile" accessibilityHint={localizedCopy.profileHint} style={styles.avatarButton} onPress={() => router.push("/profile")}>
                <Text style={styles.avatarText}>J</Text>
              </Pressable>
            </View>

            <View style={styles.hero}>
              <Text style={[styles.heroKicker, direction]}>{localizedCopy.greeting}</Text>
              <Text style={[styles.heroTitle, direction]}>{localizedCopy.hero}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={localizedCopy.create.replace("+  ", "")}
                accessibilityHint={localizedCopy.createHint}
                onPress={() => router.push("/create")}
                style={({ pressed }) => [styles.primaryButton, row, pressed && styles.pressed]}
              >
                <Text style={styles.primaryButtonText}>{localizedCopy.create}</Text>
                <Text style={styles.buttonArrow}>↗</Text>
              </Pressable>
              <Pressable accessibilityRole="button" accessibilityLabel={localizedCopy.studio} accessibilityHint={localizedCopy.studioHint} onPress={() => router.push("/studio")} style={({ pressed }) => [styles.studioButton, row, pressed && styles.cardPressed]}>
                <Text style={styles.studioButtonText}>{localizedCopy.studio}</Text><Text style={styles.studioArrow}>↗</Text>
              </Pressable>
            </View>

            <View style={[styles.sectionHeader, row]}>
              <Text style={styles.sectionTitle}>{localizedCopy.characters}</Text>
              <Pressable accessibilityRole="button" accessibilityLabel={localizedCopy.seeAll} onPress={() => router.push("/characters")}><Text style={styles.seeAll}>{localizedCopy.seeAll}</Text></Pressable>
            </View>
            <FlatList
              horizontal
              data={savedCharacters.map((item) => ({ id: item.id, name: item.name, style: item.style, colors: [item.color, "#151521"] }))}
              keyExtractor={(item) => item.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
              renderItem={({ item, index }) => (
                <Animated.View entering={reduceMotion ? undefined : FadeInDown.delay(index * 70).duration(280)}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={item.name}
                    onPress={() => router.push("/create")}
                    style={({ pressed }) => [styles.characterCard, pressed && styles.cardPressed]}
                  >
                  <LinearGradient colors={item.colors as [string, string]} style={styles.characterArt}>
                    <View style={styles.characterOrb} />
                    <Text style={styles.characterIndex}>0{index + 1}</Text>
                  </LinearGradient>
                  <Text style={styles.cardTitle}>{item.name}</Text>
                    <Text style={[styles.cardMeta, { color: colors.muted }]}>{item.style}</Text>
                  </Pressable>
                </Animated.View>
              )}
            />

            <View style={[styles.sectionHeader, row]}>
              <Text style={styles.sectionTitle}>{localizedCopy.worlds}</Text>
              <Pressable accessibilityRole="button" accessibilityLabel={localizedCopy.explore} onPress={() => router.push("/worlds")}><Text style={styles.seeAll}>{localizedCopy.explore}</Text></Pressable>
            </View>
            <FlatList
              horizontal
              data={worlds}
              keyExtractor={(item) => item.id}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalList}
              renderItem={({ item, index }) => (
                <Animated.View entering={reduceMotion ? undefined : FadeInDown.delay(index * 70).duration(280)}>
                  <Pressable accessibilityRole="button" accessibilityLabel={item.title} onPress={() => router.push("/worlds")} style={({ pressed }) => [styles.worldCard, pressed && styles.cardPressed]}>
                  <LinearGradient colors={item.colors as [string, string]} style={styles.worldArt}>
                    <View style={styles.worldSun} />
                    <View style={styles.worldHorizon} />
                  </LinearGradient>
                  <Text style={styles.cardTitle}>{item.title}</Text>
                    <Text style={[styles.cardMeta, { color: colors.muted }]}>{item.meta}</Text>
                  </Pressable>
                </Animated.View>
              )}
            />

            <View style={[styles.storyHeader, row, { borderTopColor: colors.border }]}>
              <View>
                <Text style={styles.sectionTitle}>{localizedCopy.next}</Text>
                <Text style={[styles.sectionSub, { color: colors.muted }]}>{localizedCopy.episode}</Text>
              </View>
              <Icon label="✦" color={colors.primary} />
            </View>
            <View style={[styles.filterRow, row]}>
              {filters.map((filter) => (
                <Pressable key={filter} accessibilityRole="button" accessibilityLabel={filter} accessibilityState={{ selected: activeFilter === filter }} onPress={() => setActiveFilter(filter)} style={[styles.filterChip, activeFilter === filter && { backgroundColor: colors.primary }]}>
                  <Text style={[styles.filterText, activeFilter === filter && { color: colors.background }]}>{filter}</Text>
                </Pressable>
              ))}
            </View>
          </>
        }
        renderItem={({ item }) => (
          <Animated.View entering={reduceMotion ? undefined : FadeInDown.delay(item.title.length * 2).duration(280)}>
            <Pressable accessibilityRole="button" accessibilityLabel={item.title} onPress={() => router.push("/create")} style={({ pressed }) => [styles.conceptCard, pressed && styles.cardPressed]}>
            <View style={[styles.conceptDot, { backgroundColor: item.color }]} />
            <View style={styles.conceptCopy}>
              <Text style={styles.conceptTag}>{item.tag}</Text>
              <Text style={styles.conceptTitle}>{item.title}</Text>
            </View>
              <Text style={styles.conceptArrow}>↗</Text>
            </Pressable>
          </Animated.View>
        )}
        ListFooterComponent={<View style={{ height: 20 }} />}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: morphTokens.spacing.xl, paddingBottom: morphTokens.spacing.xxxl },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 8, paddingBottom: 28 },
  wordmark: { color: "#F7F4EF", fontSize: 22, fontWeight: "900", letterSpacing: 4 },
  eyebrow: { fontSize: 9, fontWeight: "700", letterSpacing: 1.6, marginTop: 4 },
  avatarButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: "#202032", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#3A3850" },
  avatarText: { color: "#D7F36B", fontSize: 15, fontWeight: "800" },
  hero: { paddingBottom: 34 },
  heroKicker: { color: "#FF7B68", fontSize: 10, fontWeight: "800", letterSpacing: 1.7, marginBottom: 10 },
  heroTitle: { color: "#F7F4EF", fontSize: 32, lineHeight: 35, fontWeight: "800", letterSpacing: -0.8, marginBottom: 22 },
  primaryButton: { height: 54, borderRadius: morphTokens.radius.lg, backgroundColor: "#D7F36B", paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  pressed: { transform: [{ scale: 0.98 }], opacity: 0.9 },
  primaryButtonText: { color: "#0B0B10", fontSize: 15, fontWeight: "800" },
  studioButton: { height: 46, borderRadius: 14, borderWidth: 1, borderColor: "#353447", paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 },
  studioButtonText: { color: "#F7F4EF", fontSize: 13, fontWeight: "800" },
  studioArrow: { color: "#D7F36B", fontSize: 20, fontWeight: "700" },
  buttonArrow: { color: "#0B0B10", fontSize: 22, fontWeight: "700" },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 14 },
  sectionTitle: { color: "#F7F4EF", fontSize: 18, fontWeight: "800", letterSpacing: -0.2 },
  seeAll: { color: "#D7F36B", fontSize: 13, fontWeight: "700" },
  horizontalList: { gap: 12, paddingBottom: 30 },
  characterCard: { width: 132 },
  characterArt: { height: 154, borderRadius: 20, overflow: "hidden", justifyContent: "flex-end", padding: 12, marginBottom: 10 },
  characterOrb: { position: "absolute", width: 96, height: 96, borderRadius: 48, backgroundColor: "rgba(255,255,255,0.15)", top: 24, alignSelf: "center" },
  characterIndex: { color: "rgba(255,255,255,0.7)", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  cardTitle: { color: "#F7F4EF", fontSize: 14, fontWeight: "800" },
  cardMeta: { fontSize: 11, marginTop: 3 },
  cardPressed: { opacity: 0.75 },
  worldCard: { width: 178 },
  worldArt: { height: 118, borderRadius: 20, overflow: "hidden", marginBottom: 10 },
  worldSun: { width: 48, height: 48, borderRadius: 24, backgroundColor: "rgba(215,243,107,0.75)", position: "absolute", top: 18, right: 22 },
  worldHorizon: { height: 38, backgroundColor: "rgba(11,11,16,0.55)", position: "absolute", bottom: 0, left: 0, right: 0, transform: [{ skewY: "-10deg" }] },
  storyHeader: { borderTopWidth: 1, paddingTop: 24, marginTop: 2, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionSub: { fontSize: 12, marginTop: 4 },
  icon: { fontSize: 26 },
  filterRow: { flexDirection: "row", gap: 8, marginTop: 16, marginBottom: 14 },
  filterChip: { borderRadius: 100, borderWidth: 1, borderColor: "#353447", paddingHorizontal: 14, paddingVertical: 8 },
  filterText: { color: "#A9A6B2", fontSize: 12, fontWeight: "700" },
  conceptCard: { minHeight: 76, backgroundColor: "#151521", borderRadius: 18, marginBottom: 10, padding: 14, flexDirection: "row", alignItems: "center", borderWidth: 1, borderColor: "#242335" },
  conceptDot: { width: 10, height: 10, borderRadius: 5, marginRight: 14 },
  conceptCopy: { flex: 1 },
  conceptTag: { color: "#A9A6B2", fontSize: 9, fontWeight: "800", letterSpacing: 1.3, marginBottom: 5 },
  conceptTitle: { color: "#F7F4EF", fontSize: 14, fontWeight: "700" },
  conceptArrow: { color: "#D7F36B", fontSize: 20, fontWeight: "700", paddingLeft: 10 },
});
