
import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { textDirection } from "@/src/localization/layout";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { labels, presentation } = useLanguagePreference();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);

  return <Tabs screenOptions={{ tabBarActiveTintColor: colors.primary, tabBarLabelStyle: textDirection(presentation.direction), headerShown: false, tabBarButton: HapticTab, tabBarStyle: { paddingTop: 8, paddingBottom: bottomPadding, height: 56 + bottomPadding, backgroundColor: colors.background, borderTopColor: colors.border, borderTopWidth: 0.5 } }}>
    <Tabs.Screen name="index" options={{ title: labels.home, tabBarIcon: ({ color }) => <IconSymbol size={23} name="house.fill" color={color} /> }} />
    <Tabs.Screen name="create" options={{ title: labels.create, tabBarIcon: ({ color }) => <IconSymbol size={23} name="plus.circle.fill" color={color} /> }} />
    <Tabs.Screen name="worlds" options={{ title: labels.worlds, tabBarIcon: ({ color }) => <IconSymbol size={23} name="sparkles" color={color} /> }} />
    <Tabs.Screen name="stories" options={{ title: labels.stories, tabBarIcon: ({ color }) => <IconSymbol size={23} name="book.fill" color={color} /> }} />
    <Tabs.Screen name="profile" options={{ title: labels.profile, tabBarIcon: ({ color }) => <IconSymbol size={23} name="person.crop.circle.fill" color={color} /> }} />
  </Tabs>;
}
