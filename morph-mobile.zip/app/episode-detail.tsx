import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { VideoView, useVideoPlayer } from "expo-video";
import { ScreenContainer } from "@/components/screen-container";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { getEpisodeDetailCopy } from "@/src/localization/episode-detail-copy";
import { rowDirection, textDirection } from "@/src/localization/layout";
import { loadEpisodes, updateEpisodePlaybackPosition, type LocalEpisode } from "@/src/storage/morph-repository";
import { formatEpisodeLabel, episodeColor } from "@/src/story/story-list";
import { morphTokens } from "@/src/ui/morph-tokens";
import { formatPlaybackPosition, getEpisodePlaybackUiState, getEpisodePreviewUri, getPlaybackProgressPercent, getPlaybackRemainingTime, getPlaybackSeekTime } from "@/src/story/episode-preview";

export default function EpisodeDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string | string[] }>();
  const episodeId = Array.isArray(id) ? id[0] : id;
  const { language, presentation } = useLanguagePreference();
  const copy = getEpisodeDetailCopy(language);
  const direction = textDirection(presentation.direction);
  const row = rowDirection(presentation.direction);
  const [episode, setEpisode] = useState<LocalEpisode | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const previewUri = getEpisodePreviewUri(episode);
  const player = useVideoPlayer(previewUri, (videoPlayer) => {
    videoPlayer.loop = false;
    videoPlayer.timeUpdateEventInterval = 1;
  });
  const [previewStatus, setPreviewStatus] = useState(player.status);
  const [previewError, setPreviewError] = useState<unknown>(null);
  const [livePosition, setLivePosition] = useState<number | null>(null);
  const lastPersistedPosition = useRef(0);
  const [progressWidth, setProgressWidth] = useState(0);
  const scrubbedPosition = useRef<number | null>(null);

  useEffect(() => {
    const subscription = player.addListener("statusChange", ({ status, error: nextError }) => {
      setPreviewStatus(status);
      setPreviewError(nextError);
    });
    const endSubscription = player.addListener("playToEnd", () => {
      if (episode) {
        lastPersistedPosition.current = 0;
        setLivePosition(0);
        void updateEpisodePlaybackPosition(episode.id, 0, player.duration);
      }
    });
    const timeSubscription = player.addListener("timeUpdate", ({ currentTime }) => {
      if (!Number.isFinite(currentTime) || currentTime < 0) return;
      setLivePosition(currentTime);
      if (episode && Math.abs(currentTime - lastPersistedPosition.current) >= 5) {
        lastPersistedPosition.current = currentTime;
        void updateEpisodePlaybackPosition(episode.id, currentTime, player.duration);
      }
    });
    return () => {
      subscription.remove();
      endSubscription.remove();
      timeSubscription.remove();
    };
  }, [episode, player]);

  useEffect(() => {
    if (!episode || !previewUri) return;
    const initialPosition = episode.playbackPositionSec ?? 0;
    lastPersistedPosition.current = initialPosition;
    setLivePosition(initialPosition);
    player.currentTime = initialPosition;
    return () => {
      lastPersistedPosition.current = player.currentTime;
      void updateEpisodePlaybackPosition(episode.id, player.currentTime, player.duration);
    };
  }, [episode, player, previewUri]);

  const loadEpisode = useCallback(() => {
    setLoading(true);
    setError(false);
    loadEpisodes()
      .then((episodes) => setEpisode(episodes.find((item) => item.id === episodeId) ?? null))
      .catch(() => { setError(true); setEpisode(null); })
      .finally(() => setLoading(false));
  }, [episodeId]);

  useEffect(() => { loadEpisode(); }, [loadEpisode]);

  const seekToLocation = (locationX: number) => {
    if (!episode) return;
    const seekTime = getPlaybackSeekTime(locationX, progressWidth, player.duration);
    if (seekTime === null) return;
    player.currentTime = seekTime;
    setLivePosition(seekTime);
    scrubbedPosition.current = seekTime;
  };
  const finishSeek = () => {
    if (!episode || scrubbedPosition.current === null) return;
    const seekTime = scrubbedPosition.current;
    scrubbedPosition.current = null;
    lastPersistedPosition.current = seekTime;
    void updateEpisodePlaybackPosition(episode.id, seekTime, player.duration);
  };

  if (loading) return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><View accessibilityRole="progressbar" style={styles.center}><ActivityIndicator color="#D7F36B" /><Text style={styles.muted}>{copy.loading}</Text></View></ScreenContainer>;

  if (error) return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><View style={styles.center}><Text style={[styles.missingTitle, direction]}>{copy.loadError}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.retry} onPress={loadEpisode} style={styles.secondary}><Text style={styles.secondaryText}>{copy.retry}</Text></Pressable></View></ScreenContainer>;

  if (!episode) return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><View style={styles.center}><Text style={[styles.missingTitle, direction]}>{copy.missingTitle}</Text><Text style={[styles.missingBody, direction]}>{copy.missingBody}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.back} accessibilityHint={copy.backHint} onPress={() => router.back()} style={styles.secondary}><Text style={styles.secondaryText}>{copy.back}</Text></Pressable></View></ScreenContainer>;

  const playbackUiState = getEpisodePlaybackUiState(episode, previewStatus, previewError);
  const currentPosition = livePosition ?? (episode.playbackPositionSec ?? 0);
  const resumePosition = formatPlaybackPosition(currentPosition);
  const progressPercent = getPlaybackProgressPercent(currentPosition, player.duration);
  const remainingTime = getPlaybackRemainingTime(currentPosition, player.duration);
  const retryPreview = () => {
    if (!previewUri) return;
    setPreviewError(null);
    player.replace(previewUri);
    player.play();
  };
  const startOver = () => {
    if (!previewUri || !episode) return;
    player.currentTime = 0;
    setLivePosition(0);
    lastPersistedPosition.current = 0;
    setPreviewError(null);
    void updateEpisodePlaybackPosition(episode.id, 0, player.duration);
    player.play();
  };
  const continueToCreate = () => router.push({ pathname: "/create", params: { episodeId: episode.id } });
  const remix = () => router.push({ pathname: "/create", params: { episodeId: episode.id, remix: "1" } });

  return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}><Pressable accessibilityRole="button" accessibilityLabel={copy.back} accessibilityHint={copy.backHint} onPress={() => router.back()}><Text style={styles.back}>‹</Text></Pressable><View style={[styles.hero, { backgroundColor: episodeColor(episode, 0) }]}><Text style={styles.heroKicker}>{formatEpisodeLabel(episode, 0)}</Text><View style={styles.heroCircle} /></View><View accessibilityRole="text" style={styles.preview}><Text style={[styles.label, direction]}>{copy.preview}</Text>{playbackUiState === "unavailable" ? <Text style={[styles.previewText, direction]}>{copy.previewUnavailable}</Text> : playbackUiState === "error" ? <><Text style={[styles.previewText, direction]}>{copy.previewError}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.retryPreview} onPress={retryPreview} style={styles.previewRetry}><Text style={styles.secondaryText}>{copy.retryPreview}</Text></Pressable></> : <><VideoView style={styles.video} player={player} allowsFullscreen allowsPictureInPicture contentFit="cover" />{progressPercent !== null ? <><Pressable accessibilityRole="adjustable" accessibilityLabel={copy.progressLabel(progressPercent)} accessibilityValue={{ min: 0, max: 100, now: progressPercent }} onLayout={(event) => setProgressWidth(event.nativeEvent.layout.width)} onStartShouldSetResponder={() => true} onResponderMove={(event) => seekToLocation(event.nativeEvent.locationX)} onResponderRelease={finishSeek} onResponderTerminate={finishSeek} onPressIn={(event) => seekToLocation(event.nativeEvent.locationX)} style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progressPercent}%` }]} /></Pressable><Text style={[styles.progressMeta, direction]}>{copy.progressLabel(progressPercent)}{remainingTime ? ` · ${copy.remainingLabel(remainingTime)}` : ""}</Text></> : null}{resumePosition ? <View style={styles.resumeRow}><Text style={[styles.resumeText, direction]}>{copy.resumeFrom(resumePosition)}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.startOver} accessibilityHint={copy.startOverHint} onPress={startOver} style={styles.startOver}><Text style={styles.startOverText}>{copy.startOver}</Text></Pressable></View> : null}{playbackUiState === "loading" ? <View accessibilityRole="progressbar" style={styles.previewLoading}><ActivityIndicator color="#D7F36B" /><Text style={styles.previewText}>{copy.previewLoading}</Text></View> : null}</>}</View><Text style={[styles.title, direction]}>{episode.title}</Text><View style={[styles.metaRow, row]}><Text style={styles.meta}>{copy.worldLabel} · {episode.world}</Text><Text style={styles.meta}>{copy.characterLabel} · {episode.characterName}</Text></View><Text style={[styles.label, direction]}>{copy.synopsisLabel}</Text><Text style={[styles.synopsis, direction]}>{episode.synopsis}</Text><Pressable accessibilityRole="button" accessibilityLabel={copy.continue} accessibilityHint={copy.continueHint} onPress={continueToCreate} style={styles.primary}><Text style={styles.primaryText}>{copy.continue}</Text><Text style={styles.primaryArrow}>↗</Text></Pressable><Pressable accessibilityRole="button" accessibilityLabel={copy.remix} accessibilityHint={copy.remixHint} onPress={remix} style={styles.secondary}><Text style={styles.secondaryText}>{copy.remix}</Text></Pressable></ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingTop: morphTokens.spacing.lg, paddingBottom: morphTokens.spacing.xxxl }, center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 20 }, muted: { color: "#A9A6B2", textAlign: "center" }, back: { color: "#F7F4EF", fontSize: 34, lineHeight: 34, marginBottom: 18 }, hero: { height: 220, borderRadius: 25, overflow: "hidden", justifyContent: "flex-end", padding: 16 }, heroKicker: { color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "900", letterSpacing: 1.2 }, heroCircle: { position: "absolute", width: 160, height: 160, borderRadius: 80, backgroundColor: "rgba(255,255,255,0.18)", top: 28, right: -14 }, title: { color: "#F7F4EF", fontSize: 30, lineHeight: 35, fontWeight: "900", marginTop: 22 }, metaRow: { gap: 8, flexWrap: "wrap", marginTop: 10 }, meta: { color: "#A9A6B2", fontSize: 11, lineHeight: 16 }, label: { color: "#D7F36B", fontSize: 10, fontWeight: "900", letterSpacing: 1.5, marginTop: 30 }, synopsis: { color: "#F7F4EF", fontSize: 17, lineHeight: 25, marginTop: 9 }, primary: { height: 54, borderRadius: 17, backgroundColor: "#D7F36B", flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 18, marginTop: 30 }, primaryText: { color: "#0B0B10", fontSize: 14, fontWeight: "800" }, primaryArrow: { color: "#0B0B10", fontSize: 21 }, secondary: { borderWidth: 1, borderColor: "#353447", borderRadius: 17, alignItems: "center", paddingVertical: 15, paddingHorizontal: 18, marginTop: 12 }, secondaryText: { color: "#D7F36B", fontSize: 13, fontWeight: "800" }, preview: { marginTop: 18, padding: 14, borderRadius: 16, backgroundColor: "#151521", borderWidth: 1, borderColor: "#2B2A3A" }, previewText: { color: "#A9A6B2", fontSize: 13, lineHeight: 19, marginTop: 6 }, video: { width: "100%", height: 190, borderRadius: 12, marginTop: 10, backgroundColor: "#0B0B10" }, previewLoading: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 8 }, progressTrack: { height: 18, justifyContent: "center", borderRadius: 9, backgroundColor: "#353447", overflow: "hidden", marginTop: 10 }, progressFill: { height: 4, borderRadius: 2, backgroundColor: "#D7F36B" }, progressMeta: { color: "#A9A6B2", fontSize: 11, lineHeight: 16, marginTop: 5 }, previewRetry: { alignSelf: "flex-start", borderWidth: 1, borderColor: "#353447", borderRadius: 12, paddingVertical: 9, paddingHorizontal: 12, marginTop: 10 }, resumeRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10, marginTop: 8 }, resumeText: { flex: 1, color: "#D7F36B", fontSize: 12, lineHeight: 17 }, startOver: { borderWidth: 1, borderColor: "#353447", borderRadius: 10, paddingVertical: 7, paddingHorizontal: 10 }, startOverText: { color: "#D7F36B", fontSize: 11, fontWeight: "800" }, missingTitle: { color: "#F7F4EF", fontSize: 23, fontWeight: "900", textAlign: "center" }, missingBody: { color: "#A9A6B2", fontSize: 14, lineHeight: 20, textAlign: "center", marginTop: 10 }, });
