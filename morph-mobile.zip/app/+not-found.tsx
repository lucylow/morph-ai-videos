import { useRouter } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";

export default function NotFoundScreen() {
  const router = useRouter();
  return <ScreenContainer className="px-5" containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}><View style={styles.content}><Text style={styles.kicker}>MORPH / 404</Text><Text style={styles.title}>This story{`\n`}took a wrong turn.</Text><Text style={styles.copy}>The page is unavailable, but your characters and drafts are safe.</Text><Pressable onPress={() => router.replace("/")} style={({ pressed }) => [styles.button, pressed && { opacity: 0.8 }]}><Text style={styles.buttonText}>Return home ↗</Text></Pressable></View></ScreenContainer>;
}
const styles = StyleSheet.create({ content: { flex: 1, justifyContent: "center" }, kicker: { color: "#D7F36B", fontSize: 10, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#F7F4EF", fontSize: 34, lineHeight: 37, fontWeight: "900", marginTop: 12 }, copy: { color: "#A9A6B2", fontSize: 14, lineHeight: 20, marginTop: 14, maxWidth: 300 }, button: { marginTop: 28, height: 54, borderRadius: 16, backgroundColor: "#D7F36B", justifyContent: "center", alignItems: "center" }, buttonText: { color: "#0B0B10", fontSize: 14, fontWeight: "800" } });
