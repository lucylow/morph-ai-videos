import { useEffect, useState } from "react";
import type { LanguageCode } from "@/src/localization/i18n";
import { defaultLanguagePreference, getLanguagePresentation, loadLanguagePreference, localizedShellLabels, subscribeLanguagePreference, type LanguagePreference } from "@/src/localization/language-preferences";

export function useLanguagePreference() {
  const [preference, setPreference] = useState<LanguagePreference>(defaultLanguagePreference);
  useEffect(() => { let active = true; void loadLanguagePreference().then((next) => { if (active) setPreference(next); }).catch(() => { /* The default preference keeps the shell usable when storage is unavailable. */ }); const unsubscribe = subscribeLanguagePreference((next) => { if (active) setPreference(next); }); return () => { active = false; unsubscribe(); }; }, []);
  const language: LanguageCode = preference.interfaceLanguage;
  return { preference, language, labels: localizedShellLabels(language), presentation: getLanguagePresentation(language) };
}
