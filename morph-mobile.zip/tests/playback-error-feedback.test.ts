import { describe, expect, it } from "vitest";

import { getStoriesCopy } from "../src/localization/screen-copy";
import { getPlaybackPersistenceFeedback } from "../src/story/playback-error-feedback";

describe("Stories playback persistence feedback", () => {
  it("maps timeout and cancellation to localized copy", () => {
    const copy = getStoriesCopy("fr");

    expect(getPlaybackPersistenceFeedback(new Error("API request timed out"), copy)).toBe(copy.persistenceTimedOut);
    expect(getPlaybackPersistenceFeedback(new Error("API request cancelled"), copy)).toBe(copy.persistenceCancelled);
  });

  it("returns null for unrelated or malformed failures", () => {
    const copy = getStoriesCopy("en");

    expect(getPlaybackPersistenceFeedback(new Error("network unavailable"), copy)).toBeNull();
    expect(getPlaybackPersistenceFeedback(null, copy)).toBeNull();
  });
});
