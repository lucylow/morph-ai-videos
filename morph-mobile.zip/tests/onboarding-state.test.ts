import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = new Map<string, string>();
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(async (key: string) => storage.get(key) ?? null),
    setItem: vi.fn(async (key: string, value: string) => { storage.set(key, value); }),
    removeItem: vi.fn(async (key: string) => { storage.delete(key); }),
  },
}));

import { completeOnboarding, loadOnboardingState, normalizeOnboardingState, resetOnboarding } from "../src/onboarding/onboarding-state";

describe("onboarding state", () => {
  beforeEach(() => storage.clear());

  it("defaults to an incomplete first-run state for missing or malformed values", () => {
    expect(normalizeOnboardingState(null)).toEqual({ completed: false });
    expect(normalizeOnboardingState("not-json")).toEqual({ completed: false });
    expect(normalizeOnboardingState({ completed: "true" })).toEqual({ completed: false });
  });

  it("persists completion and loads it on the next launch", async () => {
    await expect(loadOnboardingState()).resolves.toEqual({ completed: false });
    await completeOnboarding();
    await expect(loadOnboardingState()).resolves.toEqual({ completed: true });
  });

  it("supports an explicit reset for local QA and future settings controls", async () => {
    await completeOnboarding();
    await resetOnboarding();
    await expect(loadOnboardingState()).resolves.toEqual({ completed: false });
  });
});
