import { describe, expect, it } from "vitest";
import { canSeekBackward, canSeekForward, clampClip, clampPlayhead, clipContains, setTimelineZoom, timelineLabel, type EditorClip } from "../src/video/video-editor";

const clip: EditorClip = { id: "c", type: "video", sourceAssetId: "a", startMs: 9000, durationMs: 5000, sourceStartMs: 0, sourceEndMs: 5000, speed: 1, volume: 1, opacity: 1, transform: { x: 0, y: 0, scaleX: 1, scaleY: 1, rotation: 0, anchorX: 0.5, anchorY: 0.5 } };

describe("video editor utilities", () => {
  it("clamps clips and playback values to the timeline", () => { expect(clampClip({ ...clip, startMs: 9000, durationMs: 5000, speed: 99 }, 10000).durationMs).toBe(1000); expect(clampClip({ ...clip, startMs: -4 }, 10000).startMs).toBe(0); expect(clampPlayhead(15000, 10000)).toBe(10000); });
  it("detects clip containment and formats time labels", () => { expect(clipContains(clip, 10000)).toBe(true); expect(clipContains(clip, 2000)).toBe(false); expect(timelineLabel(65000)).toBe("01:05"); });
  it("bounds editor zoom for mobile controls", () => { expect(setTimelineZoom(-1)).toBe(0.5); expect(setTimelineZoom(99)).toBe(3); expect(setTimelineZoom(Number.NaN)).toBe(1); });
  it("reports seek availability without allowing no-op boundary actions", () => { expect(canSeekBackward(0)).toBe(false); expect(canSeekBackward(1000)).toBe(true); expect(canSeekForward(0, 12000)).toBe(true); expect(canSeekForward(12000, 12000)).toBe(false); expect(canSeekForward(Number.NaN, 0)).toBe(false); });
});
