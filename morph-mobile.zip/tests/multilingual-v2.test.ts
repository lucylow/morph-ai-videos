import { describe, expect, it } from "vitest";
import { buildLocaleContext, convertDistance, extractICUVariables, formatGenderedMessage, formatLocalizedMessage, LANGUAGE_CAPABILITIES, validateICUMessage } from "../src/localization/multilingual-v2";

describe("multilingual v2", () => {
  it("exposes RTL and capability metadata", () => { expect(LANGUAGE_CAPABILITIES.ar.rtl).toBe(true); expect(LANGUAGE_CAPABILITIES.en.ui).toBe(true); });
  it("builds a locale context with script and measurement system", () => { const context = buildLocaleContext("ar"); expect(context.direction).toBe("rtl"); expect(context.script).toBe("Arab"); expect(context.timezone.length).toBeGreaterThan(0); });
  it("extracts and validates ICU variables", () => { expect(extractICUVariables("{name} has {count, plural}")).toEqual(["name", "count"]); expect(validateICUMessage("Hello {name}", "Bonjour {name}")).toBe(true); expect(validateICUMessage("Hello {name}", "Bonjour {person}")).toBe(false); });
  it("formats variables and gender variants with safe fallback", () => { expect(formatLocalizedMessage("{count} stories", { count: 3 })).toBe("3 stories"); expect(formatGenderedMessage({ key: "x", variants: { neutral: "They arrive" } }, "feminine")).toBe("They arrive"); });
  it("converts distance with bounded non-negative output", () => { expect(convertDistance(-4, "metric")).toEqual({ value: 0, unit: "meter" }); expect(convertDistance(1, "imperial").unit).toBe("foot"); });
});
