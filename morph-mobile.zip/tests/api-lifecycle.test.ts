import { afterEach, describe, expect, it, vi } from "vitest";

import {
  createApiAbortController,
  DEFAULT_API_TIMEOUT_MS,
} from "../src/network/api-lifecycle";

describe("API lifecycle", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("aborts after the configured timeout", () => {
    vi.useFakeTimers();
    const handle = createApiAbortController(undefined, 250);

    expect(handle.signal.aborted).toBe(false);
    vi.advanceTimersByTime(249);
    expect(handle.signal.aborted).toBe(false);
    vi.advanceTimersByTime(1);
    expect(handle.signal.aborted).toBe(true);
    expect(handle.getReason()).toBe("timeout");
    handle.dispose();
  });

  it("forwards external cancellation", () => {
    const external = new AbortController();
    const handle = createApiAbortController(external.signal);

    external.abort();
    expect(handle.signal.aborted).toBe(true);
    expect(handle.getReason()).toBe("cancelled");
    handle.dispose();
  });

  it("uses the default timeout for invalid durations and cleans up idempotently", () => {
    vi.useFakeTimers();
    const handle = createApiAbortController(undefined, 0);

    expect(handle.getReason()).toBe(null);
    handle.dispose();
    handle.dispose();
    vi.advanceTimersByTime(DEFAULT_API_TIMEOUT_MS);
    expect(handle.signal.aborted).toBe(false);
    expect(handle.getReason()).toBe(null);
  });
});
