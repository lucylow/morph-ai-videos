import { describe, expect, it } from "vitest";
import { getEpisodeDetailCopy } from "../src/localization/episode-detail-copy";

describe("saved episode detail copy", () => {
  it("keeps continuation and remix actions localized", () => {
    expect(getEpisodeDetailCopy("fr").continue).toContain("Continuer");
    expect(getEpisodeDetailCopy("es").remix).toContain("Remezclar");
    expect(getEpisodeDetailCopy("ar").continueHint).toContain("يتابع");
  });

  it("formats localized watched-percentage metadata", () => {
    expect(getEpisodeDetailCopy("en").progressLabel(42)).toBe("42% watched");
    expect(getEpisodeDetailCopy("fr").progressLabel(42)).toContain("42 %");
    expect(getEpisodeDetailCopy("es").progressLabel(42)).toBe("42% visto");
    expect(getEpisodeDetailCopy("ar").progressLabel(42)).toContain("42٪");
  });

  it("provides localized missing-record recovery copy", () => {
    expect(getEpisodeDetailCopy("fr").loading).toContain("Ouverture");
    expect(getEpisodeDetailCopy("es").loading).toContain("Abriendo");
    expect(getEpisodeDetailCopy("fr").missingBody).toContain("épisode");
    expect(getEpisodeDetailCopy("ar").missingTitle).toContain("الحلقة");
    expect(getEpisodeDetailCopy("ja").retry).toBe("Try again");
    expect(getEpisodeDetailCopy("fr").retryPreview).toContain("aperçu");
    expect(getEpisodeDetailCopy("es").retryPreview).toContain("vista previa");
    expect(getEpisodeDetailCopy("ar").retryPreview).toContain("المعاينة");
  });
});
