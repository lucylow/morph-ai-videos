import { describe, expect, it } from "vitest";
import { normalizeNetworkState, shouldShowOfflineBanner } from "../src/mobile/mobile-state";

describe("mobile network resilience", () => {
  it("shows the offline banner only for explicit offline signals", () => {
    expect(shouldShowOfflineBanner({ isInternetReachable: false, isConnected: true })).toBe(true);
    expect(shouldShowOfflineBanner({ isInternetReachable: true, isConnected: false })).toBe(false);
    expect(shouldShowOfflineBanner({ isInternetReachable: null, isConnected: false })).toBe(true);
    expect(shouldShowOfflineBanner({ isInternetReachable: null, isConnected: null })).toBe(false);
  });

  it("normalizes known network types without treating unknown as offline", () => {
    expect(normalizeNetworkState({ isInternetReachable: true, type: "WIFI" })).toEqual({ online: true, network: "wifi" });
    expect(normalizeNetworkState({ isInternetReachable: false, type: "CELLULAR" })).toEqual({ online: false, network: "offline" });
    expect(normalizeNetworkState({ isInternetReachable: true, type: "UNKNOWN" })).toEqual({ online: true, network: "unknown" });
  });
});
