import { describe, expect, it } from "vitest";
import { evolveCharacterState, normalizeCharacterV2 } from "../src/characters/character-v2";

const base = normalizeCharacterV2({ id: "nova", userId: "local", name: " Nova ", motivations: { desireIntensity: 4 } } as never);

describe("Character V2", () => {
  it("normalizes sparse character records safely", () => { expect(base.name).toBe("Nova"); expect(base.motivations.desireIntensity).toBe(1); expect(base.currentState.emotionalState).toBe("neutral"); expect(base.personality.traits).toEqual([]); });
  it("preserves existing facts while adding bounded state changes", () => { const next = evolveCharacterState(base, "Nova finds a silver key", { emotionalState: "alert", knowledge: ["The key opens the archive"], possessions: ["silver key"] }); expect(next.currentState.emotionalState).toBe("alert"); expect(next.currentState.knowledge).toContain("The key opens the archive"); expect(next.currentState.possessions).toContain("silver key"); expect(next.memories).toHaveLength(1); });
});
