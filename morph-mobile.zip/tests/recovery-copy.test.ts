import { describe, expect, it } from "vitest";
import { getPersistenceAccessibilityState, getPersistenceUiLabels, type PersistenceCopyLabels } from "../src/creation/recovery-copy";

const copy: PersistenceCopyLabels = {
  persisting: "Persisting",
  savingCharacter: "Saving character",
  savingEpisode: "Saving episode",
  savedCharacter: "Character saved",
  pendingCharacter: "Character pending",
  savedEpisode: "Episode saved",
  pendingEpisode: "Episode pending",
};

describe("Create persistence UI labels", () => {
  it("prioritizes the active character stage", () => {
    expect(getPersistenceUiLabels({ activeStage: "character", characterSaved: false, episodeSaved: false }, copy)).toEqual({ active: "Saving character", character: "Saving character", episode: "Episode pending" });
  });

  it("prioritizes the active episode stage while retaining character progress", () => {
    expect(getPersistenceUiLabels({ activeStage: "episode", characterSaved: true, episodeSaved: false }, copy)).toEqual({ active: "Saving episode", character: "Character saved", episode: "Saving episode" });
  });

  it("shows saved records and pending records after a failed retry", () => {
    expect(getPersistenceUiLabels({ activeStage: null, characterSaved: true, episodeSaved: false }, copy)).toEqual({ active: "Persisting", character: "Character saved", episode: "Episode pending" });
  });

  it("marks persistence as busy only while a save stage is active", () => {
    expect(getPersistenceAccessibilityState({ activeStage: null })).toEqual({ busy: false });
    expect(getPersistenceAccessibilityState({ activeStage: "character" })).toEqual({ busy: true });
    expect(getPersistenceAccessibilityState({ activeStage: "episode" })).toEqual({ busy: true });
  });
});
