import { describe, expect, it } from "vitest";
import { parseCharacterId, parseCharacterRouteParams } from "../src/navigation/route-params";

describe("character route params", () => {
  it("normalizes a single id", () => { expect(parseCharacterId(" Nova ")).toBe("nova"); });
  it("uses the first value from an array param", () => { expect(parseCharacterId(["milo", "ignored"])).toBe("milo"); });
  it("returns null for missing or blank params", () => { expect(parseCharacterId(undefined)).toBeNull(); expect(parseCharacterId("  ")).toBeNull(); });
  it("normalizes a typed route object and safely handles malformed values", () => { expect(parseCharacterRouteParams({ id: " SAGE " })).toEqual({ id: "sage" }); expect(parseCharacterRouteParams({ id: [] })).toEqual({ id: null }); expect(parseCharacterRouteParams(null)).toEqual({ id: null }); });
});
