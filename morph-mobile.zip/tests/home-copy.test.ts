import { describe, expect, it } from "vitest";
import { getHomeCopy } from "../src/localization/home-copy";

describe("Home copy catalog", () => {
  it("localizes action hints across supported languages", () => {
    expect(getHomeCopy("fr").createHint).toContain("création");
    expect(getHomeCopy("es").profileHint).toContain("perfil");
    expect(getHomeCopy("ar").studioHint).toContain("استوديو");
  });

  it("keeps filter copy and English fallback deterministic", () => {
    expect(getHomeCopy("fr").filters).toEqual(["Pour vous", "Tendances", "Continuer"]);
    expect(getHomeCopy("ja").createHint).toBe("Opens character creation");
  });
});
