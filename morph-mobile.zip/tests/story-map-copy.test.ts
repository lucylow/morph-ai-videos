import { describe, expect, it } from "vitest";
import { getStoryMapCopy } from "../src/localization/screen-copy";

describe("Story Map localization", () => {
  it("provides completion and progress copy for every supported language", () => {
    for (const language of ["en", "fr", "es", "ar"] as const) {
      const copy = getStoryMapCopy(language);
      expect(copy.completed.length).toBeGreaterThan(0);
      expect(copy.progress(2, 4)).toContain("2");
      expect(copy.progress(2, 4)).toContain("4");
    }
  });

  it("falls back to English for unsupported language codes", () => {
    expect(getStoryMapCopy("de" as never).completed).toBe("Completed");
  });
});
