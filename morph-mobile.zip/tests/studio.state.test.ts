import { describe, expect, it, vi } from "vitest";

const { setItem } = vi.hoisted(() => ({ setItem: vi.fn().mockResolvedValue(undefined) }));
vi.mock("@react-native-async-storage/async-storage", () => ({ default: { setItem, getItem: vi.fn() } }));

import { canSaveStudioState, clearStudioEntity, defaultStudioState, focusStudioEntityPanel, normalizeStudioState, selectStudioEntity, setStudioMode, setStudioPanel, saveStudioState, withStudioStorageRetry } from "../src/studio/studio-state";

describe("studio state", () => {
  it("normalizes malformed persisted values to safe defaults", () => {
    const state = normalizeStudioState({ mode: "unknown", leftPanel: "invalid", timelineZoom: 99, saving: true });
    expect(state.mode).toBe("timeline"); expect(state.leftPanel).toBe("navigator"); expect(state.timelineZoom).toBe(3); expect(state.saving).toBe(false);
  });
  it("marks mode changes dirty and routes selection to the inspector", () => {
    const selected = selectStudioEntity(setStudioMode(defaultStudioState, "scene"), { type: "episode", id: "episode-01" });
    expect(selected.mode).toBe("scene"); expect(selected.dirty).toBe(true); expect(selected.rightPanel).toBe("inspector"); expect(canSaveStudioState(selected)).toBe(true);
  });
  it("marks asset context selection dirty and routes to the inspector", () => {
    const selected = selectStudioEntity(defaultStudioState, { type: "asset", id: "asset-01" });
    expect(selected.selectedEntity).toEqual({ type: "asset", id: "asset-01" });
    expect(selected.rightPanel).toBe("inspector");
    expect(selected.dirty).toBe(true);
  });

  it("focuses each selected context in its matching workspace panel", () => {
    expect(focusStudioEntityPanel(selectStudioEntity(defaultStudioState, { type: "character", id: "nova" })).leftPanel).toBe("characters");
    expect(focusStudioEntityPanel(selectStudioEntity(defaultStudioState, { type: "world", id: "orbit-09" })).leftPanel).toBe("worlds");
    expect(focusStudioEntityPanel(selectStudioEntity(defaultStudioState, { type: "asset", id: "asset-01" })).leftPanel).toBe("assets");
  });

  it("clears selected context and returns to the copilot panel", () => {
    const selected = selectStudioEntity(defaultStudioState, { type: "asset", id: "asset-01" });
    const cleared = clearStudioEntity({ ...selected, dirty: false });
    expect(cleared.selectedEntity).toBeUndefined();
    expect(cleared.rightPanel).toBe("copilot");
    expect(cleared.dirty).toBe(true);
  });

  it("keeps repeated entity selection clean after it is persisted", () => {
    const selected = selectStudioEntity(defaultStudioState, { type: "character", id: "nova" });
    const repeated = selectStudioEntity({ ...selected, dirty: false }, { type: "character", id: "nova" });
    expect(repeated.dirty).toBe(false);
    expect(repeated.rightPanel).toBe("inspector");
  });

  it("changes navigator panels without losing the active mode", () => {
    const state = setStudioPanel(setStudioMode(defaultStudioState, "characters"), "assets");
    expect(state.mode).toBe("characters"); expect(state.leftPanel).toBe("assets"); expect(state.dirty).toBe(true); expect(canSaveStudioState(state)).toBe(true);
  });
  it("retries transient Creator Studio storage failures", async () => {
    const operation = vi.fn().mockRejectedValueOnce(new Error("temporary storage failure")).mockResolvedValue("ok");
    await expect(withStudioStorageRetry(operation)).resolves.toBe("ok");
    expect(operation).toHaveBeenCalledTimes(2);
  });

  it("keeps same-panel selection clean when no other edits exist", () => {
    expect(setStudioPanel(defaultStudioState, "navigator").dirty).toBe(false);
  });

  it("blocks clean, active, and already-saving states", () => {
    const dirty = setStudioMode(defaultStudioState, "story");
    expect(canSaveStudioState(defaultStudioState)).toBe(false);
    expect(canSaveStudioState(dirty)).toBe(true);
    expect(canSaveStudioState(dirty, true)).toBe(false);
    expect(canSaveStudioState({ ...dirty, saving: true })).toBe(false);
  });

  it("saves a clean state with a timestamp", async () => {
    const saved = await saveStudioState(setStudioMode(defaultStudioState, "story"));
    expect(saved.dirty).toBe(false); expect(saved.lastSavedAt).toEqual(expect.any(String)); expect(setItem).toHaveBeenCalledOnce();
  });
});
