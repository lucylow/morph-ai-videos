import { afterEach, describe, expect, it, vi } from "vitest";
import { formatPlaybackPosition, getEpisodePlaybackUiState, getEpisodePreviewState, getEpisodePreviewUri, getPersistenceRetryDelay, getPlaybackProgressPercent, getPendingPlaybackRecoveryNoticeState, isRetrySnapshotFresh, getPlaybackRemainingTime, getPlaybackSeekTime, shouldApplyRecoveryCleanupState, canStartEpisodeHistoryLoad, shouldClearStoriesRefreshSuccess, shouldClearStoriesFeedback, getStoriesRefreshCompletionMessage, getStoriesRefreshAccessibilityState, getStoriesFeedbackAccessibilityLabel, getPlaybackMutationAccessibilityState, shouldApplyPlaybackRetryState, shouldApplyPlaybackMutationState, createCancellableDelay } from "../src/story/episode-preview";

describe("saved episode preview state", () => {
  it("accepts a trimmed playable media URI", () => {
    const episode = { mediaUri: "  https://cdn.example/scene.mp4  " };
    expect(getEpisodePreviewState(episode)).toBe("ready");
    expect(getEpisodePreviewUri(episode)).toBe("https://cdn.example/scene.mp4");
  });

  it("maps playback recovery states with unavailable taking precedence", () => {
    const playable = { mediaUri: "https://cdn.example/scene.mp4" };
    expect(getEpisodePlaybackUiState(null, "loading", null)).toBe("unavailable");
    expect(getEpisodePlaybackUiState(playable, "loading", null)).toBe("loading");
    expect(getEpisodePlaybackUiState(playable, "readyToPlay", new Error("network"))).toBe("error");
    expect(getEpisodePlaybackUiState(playable, "error", null)).toBe("error");
    expect(getEpisodePlaybackUiState(playable, "readyToPlay", null)).toBe("ready");
  });

  it("formats positive playback positions and omits empty ones", () => { expect(formatPlaybackPosition(0)).toBeNull(); expect(formatPlaybackPosition(-2)).toBeNull(); expect(formatPlaybackPosition(65.9)).toBe("1:05"); expect(formatPlaybackPosition("bad")).toBeNull(); });

  it("bounds persistence retry delays and handles malformed attempts", () => {
    expect(getPersistenceRetryDelay(0)).toBe(250);
    expect(getPersistenceRetryDelay(1)).toBe(500);
    expect(getPersistenceRetryDelay(4)).toBe(2000);
    expect(getPersistenceRetryDelay(-1)).toBe(250);
    expect(getPersistenceRetryDelay("2")).toBe(250);
  });

  it("resolves cancellable retry delays immediately and clears their timer", async () => {
    vi.useFakeTimers();
    const delay = createCancellableDelay(500);
    let resolved = false;
    void delay.promise.then(() => { resolved = true; });

    delay.cancel();
    await Promise.resolve();
    expect(resolved).toBe(true);
    vi.advanceTimersByTime(500);
    expect(resolved).toBe(true);
    delay.cancel();
    vi.useRealTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("accepts only fresh cancelled-retry snapshots within the bounded window", () => {
    expect(isRetrySnapshotFresh(1000, 1000)).toBe(true);
    expect(isRetrySnapshotFresh(1000, 31_000)).toBe(true);
    expect(isRetrySnapshotFresh(1000, 31_001)).toBe(false);
    expect(isRetrySnapshotFresh(1000, 999)).toBe(false);
    expect(isRetrySnapshotFresh("1000", 1000)).toBe(false);
  });

  it("applies asynchronous recovery cleanup only to mounted screens", () => {
    expect(shouldApplyRecoveryCleanupState(true)).toBe(true);
    expect(shouldApplyRecoveryCleanupState(false)).toBe(false);
    expect(shouldApplyRecoveryCleanupState(undefined)).toBe(false);
    expect(shouldApplyPlaybackMutationState(true, 2, 2)).toBe(true);
    expect(shouldApplyPlaybackMutationState(true, 2, 1)).toBe(false);
    expect(shouldApplyPlaybackRetryState(true, 2, 2)).toBe(true);
    expect(shouldApplyPlaybackRetryState(true, 2, 1)).toBe(false);
    expect(shouldApplyPlaybackRetryState(false, 2, 2)).toBe(false);
    expect(shouldApplyPlaybackRetryState(true, "2", 2)).toBe(false);
    expect(canStartEpisodeHistoryLoad(false)).toBe(true);
    expect(canStartEpisodeHistoryLoad(true)).toBe(false);
    expect(canStartEpisodeHistoryLoad(undefined)).toBe(true);
    expect(shouldClearStoriesRefreshSuccess(true, "Saved episodes refreshed.")).toBe(true);
    expect(shouldClearStoriesRefreshSuccess(false, "Saved episodes refreshed.")).toBe(false);
    expect(shouldClearStoriesFeedback(true, "Playback save recovered.")).toBe(true);
    expect(shouldClearStoriesFeedback(true, "   ")).toBe(false);
    expect(shouldClearStoriesFeedback(false, "Playback save recovered.")).toBe(false);
    expect(getStoriesFeedbackAccessibilityLabel("  Playback save recovered.  ")).toBe("Playback save recovered.");
    expect(getStoriesFeedbackAccessibilityLabel("   ")).toBeUndefined();
    expect(getStoriesFeedbackAccessibilityLabel(null)).toBeUndefined();
    expect(shouldClearStoriesRefreshSuccess(true, "   ")).toBe(false);
    expect(getStoriesRefreshCompletionMessage(true, "Saved episodes refreshed.")).toBeNull();
    expect(getStoriesRefreshCompletionMessage(false, "Saved episodes refreshed.")).toBe("Saved episodes refreshed.");
    expect(getStoriesRefreshCompletionMessage(false, "   ")).toBeNull();
    expect(getStoriesRefreshAccessibilityState(false)).toEqual({ busy: false, disabled: false });
    expect(getStoriesRefreshAccessibilityState(true)).toEqual({ busy: true, disabled: true });
    expect(getPlaybackMutationAccessibilityState(false)).toEqual({ busy: false, disabled: false });
    expect(getPlaybackMutationAccessibilityState(true)).toEqual({ busy: true, disabled: true });
    expect(getPlaybackMutationAccessibilityState(null)).toEqual({ busy: false, disabled: false });
  });

  it("maps pending recovery notices to restored, expired, or invalid states", () => {
    expect(getPendingPlaybackRecoveryNoticeState({ id: "episode-1", target: 42, createdAt: 1_000 }, 1_000)).toBe("restored");
    expect(getPendingPlaybackRecoveryNoticeState({ id: "episode-1", target: 42, createdAt: 1_000 }, 31_000)).toBe("restored");
    expect(getPendingPlaybackRecoveryNoticeState({ id: "episode-1", target: 42, createdAt: 1_000 }, 31_001)).toBe("expired");
    expect(getPendingPlaybackRecoveryNoticeState({ id: "episode-1", target: 42, createdAt: 1_000 }, 999)).toBe("expired");
    expect(getPendingPlaybackRecoveryNoticeState({ id: "episode-1", target: "42", createdAt: 1_000 }, 1_000)).toBe("invalid");
    expect(getPendingPlaybackRecoveryNoticeState(null, 1_000)).toBe("invalid");
  });

  it("formats remaining playback time and omits exhausted or malformed media", () => {
    expect(getPlaybackRemainingTime(30, 120)).toBe("1:30");
    expect(getPlaybackRemainingTime(119.9, 120)).toBe("0:00");
    expect(getPlaybackRemainingTime(120, 120)).toBeNull();
    expect(getPlaybackRemainingTime(-1, 120)).toBeNull();
    expect(getPlaybackRemainingTime("30", 120)).toBeNull();
  });

  it("clamps scrubber taps to the playable duration and rejects bad geometry", () => {
    expect(getPlaybackSeekTime(50, 100, 120)).toBe(60);
    expect(getPlaybackSeekTime(-10, 100, 120)).toBe(0);
    expect(getPlaybackSeekTime(140, 100, 120)).toBe(120);
    expect(getPlaybackSeekTime(12.34, 100, 10)).toBe(1.2);
    expect(getPlaybackSeekTime(20, 0, 120)).toBeNull();
    expect(getPlaybackSeekTime("20", 100, 120)).toBeNull();
  });

  it("bounds valid progress percentages and rejects unusable durations", () => { expect(getPlaybackProgressPercent(30, 120)).toBe(25); expect(getPlaybackProgressPercent(180, 120)).toBe(100); expect(getPlaybackProgressPercent(0, 120)).toBeNull(); expect(getPlaybackProgressPercent(30, 0)).toBeNull(); expect(getPlaybackProgressPercent("30", 120)).toBeNull(); });

  it("falls back safely for missing or malformed media metadata", () => {
    expect(getEpisodePreviewState(null)).toBe("unavailable");
    expect(getEpisodePreviewState({ mediaUri: "   " })).toBe("unavailable");
    expect(getEpisodePreviewUri({ mediaUri: 42 })).toBeNull();
  });
});
