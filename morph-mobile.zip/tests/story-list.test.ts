import { describe, expect, it } from "vitest";
import { buildEpisodeAccessibilityLabel, episodeColor, formatEpisodeLabel } from "../src/story/story-list";

const episode = { id: "episode-1", title: "Orbit 09", world: "Orbit 09", characterName: "Nova", synopsis: "A signal crosses the dark side of the moon.", status: "completed" as const, createdAt: "2026-08-23" };

describe("Stories presentation helpers", () => {
  it("uses the persisted episode label and safe fallback", () => {
    expect(formatEpisodeLabel({ ...episode, episode: "Episode 04 · Signal" }, 0)).toBe("Episode 04 · Signal");
    expect(formatEpisodeLabel(episode, 2)).toBe("Episode 3 · New chapter");
  });

  it("includes synopsis in the accessible episode label", () => {
    expect(buildEpisodeAccessibilityLabel(episode, 0)).toContain("A signal crosses the dark side of the moon.");
  });

  it("prefers persisted colors and cycles safe fallbacks", () => {
    expect(episodeColor({ ...episode, color: "#123456" }, 0)).toBe("#123456");
    expect(episodeColor(episode, 3)).toBe("#8B7CFF");
  });
});
