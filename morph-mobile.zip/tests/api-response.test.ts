import { describe, expect, it } from "vitest";

import { normalizeSuccessfulApiBody } from "../src/network/api-response";

describe("API response normalization", () => {
  it("returns an empty object for an empty success body", () => {
    expect(normalizeSuccessfulApiBody<Record<string, never>>("", "application/json")).toEqual({});
  });

  it("parses JSON success bodies", () => {
    expect(normalizeSuccessfulApiBody<{ ok: boolean }>("{\"ok\":true}", "application/json; charset=utf-8")).toEqual({ ok: true });
  });

  it("preserves successful plain-text bodies", () => {
    expect(normalizeSuccessfulApiBody<string>("queued", "text/plain; charset=utf-8")).toBe("queued");
  });
});
