import { describe, expect, it } from "vitest";
import { morphTokens, pressOpacity, selectedSurface } from "../src/ui/morph-tokens";

describe("MORPH visual system", () => {
  it("keeps cinematic spacing, radius, and motion tokens stable", () => {
    expect(morphTokens.spacing.xl).toBe(20);
    expect(morphTokens.radius.xl).toBe(20);
    expect(morphTokens.motion.normal).toBe(220);
    expect(morphTokens.colors.accent).toBe("#D7F36B");
    expect(morphTokens.shadows.subtle.boxShadow).toContain("rgba");
    expect("shadowColor" in morphTokens.shadows.subtle).toBe(false);
  });

  it("provides bounded press feedback for accessible controls", () => {
    expect(pressOpacity(false)).toBe(1);
    expect(pressOpacity(true)).toBe(0.78);
    expect(pressOpacity(true, true)).toBe(0.5);
  });

  it("uses a distinct selected surface while preserving the dark palette", () => {
    expect(selectedSurface(true)).toEqual({ backgroundColor: "#2A2027", borderColor: "#FF7B68" });
    expect(selectedSurface(false)).toEqual({ backgroundColor: "#151521", borderColor: "#2B2A3A" });
  });
});
