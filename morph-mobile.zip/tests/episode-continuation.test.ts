import { describe, expect, it } from "vitest";
import { buildEpisodeContinuationPrompt } from "../src/story/episode-continuation";

const episode = { id: "episode-1", title: "The hidden club", world: "Anime Academy", characterName: "Nova", synopsis: "Nova finds a door beneath the school.", branchChoiceId: "follow-door", status: "completed", createdAt: "2026-08-23" } as const;

describe("saved episode continuation prompts", () => {
  it("preserves episode and branch context for continuation", () => {
    expect(buildEpisodeContinuationPrompt(episode)).toContain("Continue this episode along branch follow-door");
    expect(buildEpisodeContinuationPrompt(episode)).toContain("The hidden club. Nova finds a door");
  });

  it("marks remix prompts distinctly while retaining the source episode", () => {
    expect(buildEpisodeContinuationPrompt({ ...episode, branchChoiceId: undefined }, true)).toBe("Remix this episode: The hidden club. Nova finds a door beneath the school.");
  });
});
