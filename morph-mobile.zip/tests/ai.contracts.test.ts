import { describe, expect, it } from "vitest";
import { buildMemoryContext, calculateMemoryImportance, rerankMemories, shouldAskForClarification, type RetrievedMemory } from "../src/ai/contracts";

describe("MORPH AI contracts", () => {
  it("weights confidence and importance into a stable memory score", () => {
    expect(calculateMemoryImportance({ confidence: 1, importance: 0 })).toBeCloseTo(0.65);
  });

  it("reranks memories using similarity and memory quality", () => {
    const memories: RetrievedMemory[] = [
      { similarity: 0.4, memory: { id: "1", ownerId: "u", scopeId: "c", type: "fact", key: "home", value: "rooftop", confidence: 1, importance: 1, createdAt: "", updatedAt: "" } },
      { similarity: 0.9, memory: { id: "2", ownerId: "u", scopeId: "c", type: "style", key: "tone", value: "neon", confidence: 0.5, importance: 0.5, createdAt: "", updatedAt: "" } },
    ];
    expect(rerankMemories(memories)[0].memory.id).toBe("2");
    expect(buildMemoryContext(memories)).toContain("[fact] home: rooftop");
  });

  it("asks for clarification only when intent confidence is low", () => {
    expect(shouldAskForClarification({ intent: "create_story", confidence: 0.61 })).toBe(true);
    expect(shouldAskForClarification({ intent: "create_story", confidence: 0.9 })).toBe(false);
  });
});


import { canRetryPipeline, dedupeMemories, memoryDecay, nextPipelineState, retrieveRelevantMemory } from "../src/ai/contracts";

describe("MORPH AI intelligence utilities", () => {
  it("deduplicates extracted memories by type and key", () => {
    const memories = dedupeMemories([
      { type: "fact", key: "home", value: "rooftop", confidence: 0.6 },
      { type: "fact", key: "home", value: "moonbase", confidence: 0.9 },
    ]);
    expect(memories).toHaveLength(1);
    expect(memories[0].value).toBe("moonbase");
  });

  it("decays confidence for older memories without dropping below the floor", () => {
    const old = { id: "1", ownerId: "u", scopeId: "c", type: "fact" as const, key: "home", value: "rooftop", confidence: 0.8, importance: 0.5, createdAt: "2020-01-01", updatedAt: "2020-01-01" };
    expect(memoryDecay(old, new Date("2026-01-01").getTime())).toBeGreaterThanOrEqual(0.1);
    expect(memoryDecay(old, new Date("2026-01-01").getTime())).toBeLessThan(0.8);
  });

  it("limits ranked memory context and supports retryable failures", () => {
    const memories = [{ similarity: 0.8, memory: { id: "1", ownerId: "u", scopeId: "c", type: "style" as const, key: "tone", value: "neon", confidence: 0.9, importance: 0.9, createdAt: "", updatedAt: "" } }];
    expect(retrieveRelevantMemory(memories, 1)).toHaveLength(1);
    const failed = { requestId: "r1", stage: "evaluating" as const, completedStages: [], retryCount: 0, status: "failed" as const, error: { code: "QUALITY", message: "Needs repair", retryable: true } };
    expect(canRetryPipeline(failed)).toBe(true);
    expect(nextPipelineState({ ...failed, status: "running", error: undefined }, "complete").status).toBe("completed");
  });
});


describe("MORPH persistence contracts", () => {
  it("keeps the latest value when a character is upserted", () => {
    const character = { id: "nova", style: "Anime", personality: ["Brave"], version: 2 };
    const next = [character, { id: "milo", style: "Clay", personality: ["Funny"], version: 1 }].filter((item, index, all) => all.findIndex((candidate) => candidate.id === item.id) === index);
    expect(next[0].style).toBe("Anime");
    expect(next).toHaveLength(2);
  });

  it("caps episode history to a bounded local collection", () => {
    const existing = Array.from({ length: 52 }, (_, index) => ({ id: `episode-${index}`, title: `Episode ${index}` }));
    const bounded = existing.slice(0, 50);
    expect(bounded).toHaveLength(50);
  });
});


import { calculateVideoCost, getPlanEntitlements, hasSufficientCredits } from "../src/billing/catalog";
import { buildCreationFlow, completeUXAction, createInitialUXSession, getFirstSessionGoal, minimizeChoices } from "../src/ux/session";
import { diversifyIdeas, randomizeSeed, scoreHook } from "../src/story/story-engine";

describe("MORPH story, UX, and monetization helpers", () => {
  it("scores hooks and removes near-duplicate ideas", () => {
    expect(scoreHook({ clarity: 1, novelty: 1, visualImpact: 1, curiosity: 1 })).toBe(1);
    const ideas = diversifyIdeas([{ id: "a", premise: "A robot finds a key", hook: "", emotionalCore: "", visualHook: "", noveltyScore: 0.9, replayPotential: 0.5 }, { id: "b", premise: "A robot finds a key", hook: "", emotionalCore: "", visualHook: "", noveltyScore: 0.8, replayPotential: 0.5 }]);
    expect(ideas).toHaveLength(1);
  });
  it("keeps randomized seeds within the creative vocabulary", () => {
    expect(randomizeSeed(() => 0).genre).toBe("adventure");
    expect(randomizeSeed(() => 0).constraint).toContain("cannot solve");
  });
  it("advances first-session goals without duplicating actions", () => {
    const initial = createInitialUXSession("2026-01-01");
    const next = completeUXAction(initial, "character_created", "2026-01-02");
    expect(getFirstSessionGoal(initial)).toBe("Create your first character");
    expect(getFirstSessionGoal(next)).toBe("Create your first episode");
    expect(completeUXAction(next, "character_created").completedActions).toHaveLength(1);
  });
  it("builds a low-decision creation flow and exposes plan entitlements", () => {
    expect(buildCreationFlow(false, false).steps).toEqual(["character", "world", "idea"]);
    expect(minimizeChoices([{ optional: false }, { optional: false }, { optional: false }])[2].optional).toBe(true);
    expect(getPlanEntitlements("creator").monthlyCredits).toBe(500);
    expect(calculateVideoCost(9, true)).toBe(15);
    expect(hasSufficientCredits({ available: 15, reserved: 0, lifetimePurchased: 15, lifetimeConsumed: 0 }, 15)).toBe(true);
  });
});


describe("MORPH premise and branch helpers", () => {
  it("builds a readable premise summary with safe defaults", async () => {
    const { buildPremiseSummary } = await import("../src/story/story-engine");
    expect(buildPremiseSummary({ idea: "", genre: "adventure", tone: "cinematic", world: "Orbit 09", character: "Nova" })).toContain("Nova enters Orbit 09");
  });
  it("normalizes branch labels and consequences", async () => {
    const { normalizeBranchChoice } = await import("../src/story/story-engine");
    expect(normalizeBranchChoice({ id: "door", label: " Open the door ", consequence: " Step inside. " }).label).toBe("Open the door");
  });
});


describe("MORPH story continuity", () => {
  it("formats a selected branch as a future creation prompt", async () => {
    const { formatBranchContinuation } = await import("../src/story/story-engine");
    expect(formatBranchContinuation({ id: "door", label: "Open the door", consequence: "Nova enters the hidden club." }, "The hidden club")).toContain("Continue “The hidden club”");
  });
});


describe("MORPH story map and recovery", () => {
  it("traverses a story path and identifies open leaves", async () => {
    const { getStoryLeaves, getStoryPath } = await import("../src/story/story-engine");
    const graph = { rootEpisodeId: "root", nodes: [{ id: "root", episodeId: "e1", title: "Start" }, { id: "next", episodeId: "e2", title: "Next", parentId: "root" }] };
    expect(getStoryPath(graph, "next")).toHaveLength(2);
    expect(getStoryLeaves(graph)).toHaveLength(1);
  });
  it("only shows recovery when a draft exists and dismissal is false", async () => {
    const { shouldShowRecovery } = await import("../src/ux/session");
    expect(shouldShowRecovery(true, false)).toBe(true);
    expect(shouldShowRecovery(true, true)).toBe(false);
  });
});


describe("MORPH error handling", () => {
  it("returns safe retryable messages for storage and generation failures", async () => {
    const { normalizeMorphError } = await import("../src/core/errors");
    expect(normalizeMorphError(new Error("disk unavailable"), "storage").retryable).toBe(true);
    expect(normalizeMorphError(new Error("timeout"), "generation").message).toContain("longer than expected");
  });
  it("does not expose raw error text to users", async () => {
    const { normalizeMorphError } = await import("../src/core/errors");
    expect(normalizeMorphError(new Error("secret backend detail"), "navigation").message).not.toContain("secret backend detail");
  });
});


describe("MORPH persistence recovery", () => {
  it("retries a transient storage write", async () => {
    const { withStorageRetry } = await import("../src/storage/morph-repository");
    let attempts = 0;
    await expect(withStorageRetry(async () => { attempts += 1; if (attempts < 2) throw new Error("transient"); return "saved"; })).resolves.toBe("saved");
    expect(attempts).toBe(2);
  });
  it("fails with a stable storage error after bounded attempts", async () => {
    const { withStorageRetry } = await import("../src/storage/morph-repository");
    await expect(withStorageRetry(async () => { throw new Error("offline"); }, 1)).rejects.toThrow("offline");
  });
});


describe("MORPH defensive generation and monetization", () => {
  it("normalizes generation requests and rejects invalid transitions", async () => {
    const { normalizeGenerationRequest, transitionGeneration } = await import("../src/ai/generation");
    expect(normalizeGenerationRequest({ id: "r1", userId: "u1", type: "video", prompt: "  make it glow  ", referenceAssetIds: ["a", "a", ""] }).referenceAssetIds).toEqual(["a"]);
    expect(() => transitionGeneration("completed", "generating")).toThrow("Invalid generation transition");
  });
  it("clamps invalid progress and monetization scores safely", async () => {
    const { clampProgress } = await import("../src/ai/generation");
    const { clampMonetizationScore, recommendUpgrade } = await import("../src/billing/catalog");
    expect(clampProgress(Number.NaN)).toBe(0);
    expect(clampProgress(2)).toBe(1);
    expect(clampMonetizationScore(-3)).toBe(0);
    expect(clampMonetizationScore(120)).toBe(100);
    expect(recommendUpgrade("free", Number.NaN, 0)).toBe("credits");
  });
});


describe("MORPH structured errors", () => {
  it("classifies timeout and permission failures with safe messages", async () => {
    const { normalizeError, ERROR_CODES } = await import("../src/core/errors");
    expect(normalizeError(new Error("generation timeout"), "generation").code).toBe(ERROR_CODES.TIMEOUT);
    expect(normalizeError(new Error("CAMERA_PERMISSION_REQUIRED"), "media").category).toBe("permission");
  });
  it("creates a redacted error log without raw error text", async () => {
    const { normalizeError, toSafeErrorLog } = await import("../src/core/errors");
    const error = normalizeError(new Error("private backend response"), "storage");
    expect(toSafeErrorLog(error)).not.toHaveProperty("message");
    expect(toSafeErrorLog(error).category).toBe("storage");
  });
});


describe("MORPH mobile state", () => {
  it("normalizes offline and native network states safely", async () => {
    const { normalizeNetworkState } = await import("../src/mobile/mobile-state");
    expect(normalizeNetworkState({ isConnected: false, isInternetReachable: false, type: "NONE" })).toEqual({ online: false, network: "offline" });
    expect(normalizeNetworkState({ isConnected: true, isInternetReachable: true, type: "WIFI" })).toEqual({ online: true, network: "wifi" });
  });
  it("clamps upload progress to a safe range", async () => {
    const { clampUploadProgress } = await import("../src/mobile/mobile-state");
    expect(clampUploadProgress(-10)).toBe(0);
    expect(clampUploadProgress(150)).toBe(100);
    expect(clampUploadProgress(Number.NaN)).toBe(0);
  });
});


describe("MORPH malformed persistence", () => {
  it("drops invalid records and preserves valid local data", async () => {
    const { normalizeCharacters, normalizeEpisodes } = await import("../src/storage/morph-repository");
    expect(normalizeCharacters([{ id: "ok", name: "Nova", style: "Neon", personality: [], color: "#fff", status: "ready", updatedAt: "now" }, { id: 2 }])).toHaveLength(1);
    expect(normalizeEpisodes([{ id: "ok", title: "One", world: "Orbit", characterName: "Nova", synopsis: "A door opens", status: "completed", createdAt: "now" }, { id: "bad", status: "broken" }])).toHaveLength(1);
  });
});
