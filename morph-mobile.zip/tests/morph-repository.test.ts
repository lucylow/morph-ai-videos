import { beforeEach, describe, expect, it, vi } from "vitest";

const { storage, removeItem } = vi.hoisted(() => { const storage = new Map<string, string>(); const removeItem = vi.fn(async (key: string) => { storage.delete(key); }); return { storage, removeItem }; });
vi.mock("@react-native-async-storage/async-storage", () => ({ default: { getItem: vi.fn(async (key: string) => storage.get(key) ?? null), setItem: vi.fn(async (key: string, value: string) => { storage.set(key, value); }), removeItem } }));

import { defaultCharacters, loadCharacters, loadCreationDraft, normalizeCharacterEdits, normalizeCreationDraft, normalizeEpisodes, normalizePlaybackPosition, normalizePendingPlaybackRecovery, loadPendingPlaybackRecovery, savePendingPlaybackRecovery, clearPendingPlaybackRecovery, saveCreationDraft, updateCharacter, updateEpisodePlaybackPosition, withStorageRetry } from "../src/storage/morph-repository";

describe("MORPH repository resilience", () => {
  beforeEach(() => { storage.clear(); removeItem.mockClear(); });

  it("rejects malformed creation drafts instead of trusting parsed storage", async () => {
    expect(normalizeCreationDraft({ selectedStyle: "Cinematic" })).toBeNull();
    storage.set("morph.local.creation-draft.v1", JSON.stringify({ selectedCharacterId: "nova", selectedStyle: "Cinematic", selectedNext: "Adventure", selectedWorld: "Anime Academy", prompt: "", updatedAt: "2026-08-22" }));
    expect(await loadCreationDraft()).toMatchObject({ selectedCharacterId: "nova", selectedWorld: "Anime Academy" });
  });

  it("preserves a recovery draft with the current creation context", async () => {
    await saveCreationDraft({ selectedCharacterId: "nova", selectedStyle: "Cinematic", selectedNext: "Adventure", selectedWorld: "Orbit 09", genre: "mystery", tone: "dreamlike", prompt: "A door opens beneath the city.", updatedAt: "2026-08-23" });
    expect(await loadCreationDraft()).toMatchObject({ selectedWorld: "Orbit 09", genre: "mystery", prompt: "A door opens beneath the city." });
  });

  it("normalizes character edits with bounded, non-empty values", () => { const fallback = defaultCharacters[0]; const edits = normalizeCharacterEdits({ name: "  Nova Prime  ", style: "  Graphic novel  ", personality: [" brave ", "", 4 as never, " curious ", " calm ", " extra "] }, fallback); expect(edits).toEqual({ name: "Nova Prime", style: "Graphic novel", personality: ["brave", "curious", "calm", "extra"] }); expect(normalizeCharacterEdits({ name: " ", personality: [] }, fallback)).toMatchObject({ name: fallback.name, style: fallback.style, personality: fallback.personality }); });

  it("updates a saved character and keeps its DNA aligned", async () => { storage.set("morph.local.characters.v1", JSON.stringify(defaultCharacters.map((character) => character.id === "nova" ? { ...character, dna: { identityDescription: "Persistent hero", visualStyle: character.style, personality: character.personality, version: 1 } } : character))); const updated = await updateCharacter("nova", { name: "Nova Prime", style: "Anime noir", personality: ["Brave"] }); expect(updated).toMatchObject({ id: "nova", name: "Nova Prime", style: "Anime noir", personality: ["Brave"] }); expect(updated?.dna?.visualStyle).toBe("Anime noir"); expect((await loadCharacters())[0]).toMatchObject({ id: "nova", name: "Nova Prime" }); expect(await updateCharacter("missing", { name: "Ghost" })).toBeNull(); });

  it("deduplicates persisted episodes by keeping the newest record", () => { const base = { id: "episode-1", title: "Old", world: "World", characterName: "Nova", synopsis: "", status: "completed" as const, createdAt: "2026-08-20" }; const normalized = normalizeEpisodes([base, { ...base, title: "New", createdAt: "2026-08-23" }]); expect(normalized).toHaveLength(1); expect(normalized[0].title).toBe("New"); });

  it("normalizes playback positions without trusting malformed values", () => { expect(normalizePlaybackPosition(-4, 90)).toBe(0); expect(normalizePlaybackPosition(120, 90)).toBe(90); expect(normalizePlaybackPosition("bad", 90)).toBe(0); expect(normalizePlaybackPosition(12, "bad")).toBe(12); });

  it("updates and persists a saved episode playback position", async () => { const episode = { id: "episode-1", title: "Episode", world: "World", characterName: "Nova", synopsis: "A scene", status: "completed" as const, createdAt: "2026-08-23" }; storage.set("morph.local.episodes.v1", JSON.stringify([episode])); const updated = await updateEpisodePlaybackPosition(episode.id, 42, 60); expect(updated).toMatchObject({ id: episode.id, playbackPositionSec: 42, durationSec: 60 }); expect(await normalizeEpisodes(JSON.parse(storage.get("morph.local.episodes.v1") ?? "[]"))).toMatchObject([{ id: episode.id, playbackPositionSec: 42 }]); expect(await updateEpisodePlaybackPosition("missing", 10)).toBeNull(); });

  it("normalizes persisted pending recovery and clamps it to duration", () => {
    expect(normalizePendingPlaybackRecovery({ id: "episode-1", target: 90, duration: 60, createdAt: 1000 })).toEqual({ id: "episode-1", target: 60, duration: 60, createdAt: 1000 });
    expect(normalizePendingPlaybackRecovery({ id: "episode-1", target: -1, createdAt: 1000 })).toBeNull();
    expect(normalizePendingPlaybackRecovery({ id: "episode-1", target: 1, createdAt: "1000" })).toBeNull();
  });

    it("round-trips pending playback recovery and clears it safely", async () => { await savePendingPlaybackRecovery({ id: "episode-1", target: 42, duration: 60, createdAt: 1000 }); expect(await loadPendingPlaybackRecovery()).toEqual({ id: "episode-1", target: 42, duration: 60, createdAt: 1000 }); await clearPendingPlaybackRecovery(); await clearPendingPlaybackRecovery(); expect(await loadPendingPlaybackRecovery()).toBeNull(); expect(removeItem).toHaveBeenCalledTimes(2); expect(removeItem).toHaveBeenCalledWith("morph.local.pending-playback-recovery.v1"); });

  it("ignores malformed persisted pending recovery", async () => {
    storage.set("morph.local.pending-playback-recovery.v1", JSON.stringify({ id: "", target: "bad" }));
    expect(await loadPendingPlaybackRecovery()).toBeNull();
  });

  it("always attempts storage operations at least once", async () => {
    const operation = vi.fn().mockRejectedValue(new Error("storage unavailable"));
    await expect(withStorageRetry(operation, 0)).rejects.toThrow("storage unavailable");
    expect(operation).toHaveBeenCalledTimes(1);
  });
});
