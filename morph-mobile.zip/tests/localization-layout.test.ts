import { describe, expect, it } from "vitest";
import { directionStyle, rowDirection, textDirection } from "../src/localization/layout";

describe("localization layout helpers", () => {
  it("returns native direction metadata", () => { expect(directionStyle("rtl")).toEqual({ direction: "rtl" }); expect(textDirection("rtl")).toMatchObject({ textAlign: "right", writingDirection: "rtl" }); });
  it("mirrors row layout only for RTL", () => { expect(rowDirection("ltr")).toEqual({ flexDirection: "row" }); expect(rowDirection("rtl")).toEqual({ flexDirection: "row-reverse" }); });
});
