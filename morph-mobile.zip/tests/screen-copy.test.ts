import { describe, expect, it } from "vitest";
import { getCharactersCopy, getCreateCopy, getProfileCopy, getStoryMapCopy, getVideoModeLabels, getVideoStudioCopy, getWorldsCopy } from "../src/localization/screen-copy";
import { getEpisodeReadyCopy } from "../src/localization/episode-copy";
import { getStoriesCopy } from "../src/localization/screen-copy";

describe("screen copy catalogs", () => {
  it("returns translated Characters copy for supported languages", () => {
    expect(getCharactersCopy("fr").create).toBe("Créer un personnage");
    expect(getCharactersCopy("es").empty).toContain("personajes");
  });

  it("falls back to English for enabled languages without a dedicated catalog", () => {
    expect(getCharactersCopy("de").kicker).toBe("CHARACTER VAULT");
    expect(getStoryMapCopy("ja").retry).toBe("Try again");
  });

  it("covers Profile and Worlds catalogs with fallback-safe labels", () => {
    expect(getProfileCopy("fr").language).toBe("LANGUE");
    expect(getWorldsCopy("es").kicker).toBe("DESCUBRE");
    expect(getProfileCopy("ar").morphPlus).toBe("MORPH+");
    expect(getWorldsCopy("ja").back).toBe("Back");
  });

  it("covers Arabic catalog entries and RTL-facing accessibility copy", () => {
    expect(getCharactersCopy("ar").create).toBe("إنشاء شخصية");
    expect(getStoryMapCopy("ar").back).toBe("رجوع");
    expect(getProfileCopy("ar").language).toBe("اللغة");
    expect(getWorldsCopy("ar").openWorld).toContain("إنشاء شخصية");
  });

  it("covers Create and Video Studio accessibility copy", () => {
    expect(getCreateCopy("fr").libraryHint).toContain("photothèque");
    expect(getCreateCopy("es").generate).toBe("Generar episodio");
    expect(getVideoStudioCopy("fr").close).toBe("Fermer le studio vidéo");
    expect(getVideoStudioCopy("ar").play).toBe("تشغيل الفيديو");
    expect(getVideoStudioCopy("fr").durationPending).toBe("durée en attente");
    expect(getVideoStudioCopy("ar").durationPending).toBe("المدة قيد الانتظار");
    expect(getVideoStudioCopy("fr").rewindBoundary).toBe("Au début du montage");
    expect(getVideoStudioCopy("ar").forwardBoundary).toBe("عند نهاية المخطط الزمني");
    expect(getVideoStudioCopy("fr").position("00:01", "00:12")).toBe("Position dans le montage : 00:01 sur 00:12");
    expect(getVideoStudioCopy("ar").position("00:01", "00:12")).toBe("موضع المخطط الزمني 00:01 من 00:12");
    expect(getVideoStudioCopy("es").clipSelection("Club oculto")).toBe("Club oculto seleccionado");
    expect(getVideoStudioCopy("fr").zoomLevel("1.5×")).toBe("Zoom du montage : 1.5×");
    expect(getVideoStudioCopy("es").modeSelection("Edición IA")).toBe("Modo Edición IA seleccionado");
    expect(getVideoStudioCopy("ar").modeSelection("تحرير")).toBe("تم اختيار وضع تحرير");
    expect(getVideoStudioCopy("es").aiOpened).toBe("Abriendo el copiloto de IA");
    expect(getVideoStudioCopy("ar").aiOpened).toBe("جارٍ فتح مساعد الذكاء الاصطناعي");
    expect(getVideoModeLabels("es").ai).toBe("Edición IA");
    expect(getVideoModeLabels("ar").ai).toBe("تحرير بالذكاء الاصطناعي");
  });

  it("keeps Story Map accessibility hints localized", () => {
    expect(getStoryMapCopy("fr").backHint).toContain("écran");
    expect(getStoryMapCopy("es").retryHint).toContain("mapa");
    expect(getStoryMapCopy("ar").continueHint).toContain("القصة");
    expect(getStoryMapCopy("ja").retryHint).toBe("Reloads your story map");
  });

  it("keeps Stories recovery and navigation hints localized", () => {
    expect(getStoriesCopy("en").loading).toContain("Refreshing");
    expect(getStoriesCopy("en").loaded).toBe("Saved episodes refreshed.");
    expect(getStoriesCopy("fr").loaded).toContain("actualisés");
    expect(getStoriesCopy("es").loaded).toContain("actualizados");
    expect(getStoriesCopy("ar").loaded).toContain("تحديث");
    expect(getStoriesCopy("ja").loaded).toBe("Saved episodes refreshed.");
    expect(getStoriesCopy("fr").loading).toContain("Actualisation");
    expect(getStoriesCopy("es").loading).toContain("Actualizando");
    expect(getStoriesCopy("ar").loading).toContain("تحديث");
    expect(getStoriesCopy("ja").loading).toContain("Refreshing");
    expect(getStoriesCopy("fr").retryHint).toContain("épisodes");
    expect(getStoriesCopy("es").mapHint).toContain("mapa");
    expect(getStoriesCopy("ar").continueHint).toContain("استوديو");
    expect(getStoriesCopy("ja").offlineError).toContain("offline catalog");
    expect(getStoriesCopy("en").refreshError).toContain("refreshed");
    expect(getStoriesCopy("fr").refreshError).toContain("actualisés");
    expect(getStoriesCopy("es").refreshError).toContain("actualizar");
    expect(getStoriesCopy("ar").refreshError).toContain("تحديث");
    expect(getStoriesCopy("ja").refreshError).toContain("refreshed");
    expect(getStoriesCopy("fr").resumeFrom("1:05")).toBe("Reprendre à 1:05");
    expect(getStoriesCopy("es").resumeFrom("0:42")).toBe("Reanudar desde 0:42");
    expect(getStoriesCopy("ar").resumeFrom("2:10")).toBe("استئناف من 2:10");
    expect(getStoriesCopy("ja").resumeFrom("0:10")).toBe("Resume from 0:10");
    expect(getStoriesCopy("en").progressLabel(42)).toBe("42% watched");
    expect(getStoriesCopy("fr").progressLabel(42)).toContain("42 %");
    expect(getStoriesCopy("es").progressLabel(42)).toBe("42% visto");
    expect(getStoriesCopy("ar").progressLabel(42)).toContain("42٪");
    expect(getStoriesCopy("ja").progressLabel(42)).toBe("42% watched");
    expect(getStoriesCopy("en").resumeAction).toBe("Resume episode");
    expect(getStoriesCopy("fr").resumeAction).toBe("Reprendre l’épisode");
    expect(getStoriesCopy("es").resumeAction).toBe("Reanudar episodio");
    expect(getStoriesCopy("ar").resumeAction).toBe("استئناف الحلقة");
    expect(getStoriesCopy("ja").resumeAction).toBe("Resume episode");
    expect(getStoriesCopy("en").undoAction).toBe("Undo");
    expect(getStoriesCopy("fr").resetNotice).toBe("Progression réinitialisée");
    expect(getStoriesCopy("es").undoHint).toContain("posición");
    expect(getStoriesCopy("ar").undoAction).toBe("تراجع");
    expect(getStoriesCopy("ja").startOverAction).toBe("Start over");
    expect(getStoriesCopy("en").retryPersistence).toBe("Retry save");
    expect(getStoriesCopy("fr").persistenceError).toContain("enregistrés");
    expect(getStoriesCopy("es").retryPersistenceHint).toContain("guardar");
    expect(getStoriesCopy("ar").persistenceError).toContain("حفظ");
    expect(getStoriesCopy("en").offlinePersistence).toContain("offline");
    expect(getStoriesCopy("fr").offlinePersistence).toContain("hors ligne");
    expect(getStoriesCopy("es").offlinePersistence).toContain("conexión");
    expect(getStoriesCopy("ar").offlinePersistence).toContain("متصل");
    expect(getStoriesCopy("en").restoredRecoveryFor("Episode 03")).toContain("Episode 03");
    expect(getStoriesCopy("fr").restoredRecoveryFor("Épisode 03")).toContain("Épisode 03");
    expect(getStoriesCopy("es").restoredRecoveryFor("Episodio 03")).toContain("Episodio 03");
    expect(getStoriesCopy("ar").restoredRecoveryFor("الحلقة 03")).toContain("الحلقة 03");
    expect(getStoriesCopy("ja").restoredRecoveryFor("Episode 03")).toContain("Episode 03");
    expect(getStoriesCopy("en").persistenceSaved).toBe("Playback saved.");
    expect(getStoriesCopy("fr").persistenceSaved).toBe("Lecture enregistrée.");
    expect(getStoriesCopy("es").persistenceSaved).toBe("Reproducción guardada.");
    expect(getStoriesCopy("ar").persistenceSaved).toBe("تم حفظ التشغيل.");
    expect(getStoriesCopy("ja").persistenceSaved).toBe("Playback saved.");
    expect(getStoriesCopy("en").retrySaved).toContain("recovered");
    expect(getStoriesCopy("fr").retrySaved).toContain("récupérée");
    expect(getStoriesCopy("es").retrySaved).toContain("recuperado");
    expect(getStoriesCopy("ar").retrySaved).toContain("استرداد");
    expect(getStoriesCopy("ja").retrySaved).toContain("recovered");
  });

  it("keeps Episode Ready accessibility hints localized", () => {
    expect(getEpisodeReadyCopy("fr").backHint).toBe("Retourne à l’écran précédent");
    expect(getEpisodeReadyCopy("es").backHint).toBe("Vuelve a la pantalla anterior");
    expect(getEpisodeReadyCopy("ar").backHint).toBe("يعود إلى الشاشة السابقة");
  });

  it("keeps Story Map accessibility back labels localized", () => {
    expect(getStoryMapCopy("fr").back).toBe("Retour");
    expect(getStoryMapCopy("es").back).toBe("Volver");
    expect(getStoryMapCopy("en").back).toBe("Back");
  });
});
