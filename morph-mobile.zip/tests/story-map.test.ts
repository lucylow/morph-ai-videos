import { describe, expect, it } from "vitest";
import { mergeCompletedStoryNodes, type StoryGraph } from "../src/story/story-engine";
import type { LocalEpisode } from "../src/storage/morph-repository";

const graph: StoryGraph = { rootEpisodeId: "episode-01", nodes: [
  { id: "root", episodeId: "episode-01", title: "Root" },
  { id: "door", episodeId: "episode-02a", choiceId: "follow-door", title: "Door", parentId: "root" },
  { id: "milo", episodeId: "episode-02b", choiceId: "ask-milo", title: "Milo", parentId: "root" },
] };

const episode = (overrides: Partial<LocalEpisode>): LocalEpisode => ({ id: "saved-1", title: "Saved", world: "World", characterName: "Nova", synopsis: "", status: "completed", createdAt: "2026-08-23", ...overrides });

describe("Story Map completed nodes", () => {
  it("marks nodes from episode ids, episode labels, and branch choices", () => {
    const merged = mergeCompletedStoryNodes(graph, [episode({ id: "episode-01" }), episode({ id: "saved-2", episode: "episode-02a" }), episode({ id: "saved-3", branchChoiceId: "ask-milo" })]);
    expect(merged.nodes.map((node) => node.completed)).toEqual([true, true, true]);
  });

  it("does not mark failed episodes as completed", () => {
    const merged = mergeCompletedStoryNodes(graph, [episode({ id: "episode-01", status: "failed" })]);
    expect(merged.nodes[0].completed).toBe(false);
    expect(merged.nodes[1].completed).toBe(false);
  });
});
