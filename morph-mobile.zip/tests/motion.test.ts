import { describe, expect, it } from "vitest";

import { motionDuration } from "../src/ui/motion";

describe("motion policy", () => {
  it("disables optional motion when reduced motion is enabled", () => {
    expect(motionDuration(true, 360)).toBe(0);
    expect(motionDuration(true, 180)).toBe(0);
  });

  it("keeps the cinematic duration when motion is allowed", () => {
    expect(motionDuration(false, 360)).toBe(360);
    expect(motionDuration(false, 180)).toBe(180);
  });

  it("fails safely for invalid durations", () => {
    expect(motionDuration(false, -1)).toBe(0);
    expect(motionDuration(false, Number.NaN)).toBe(0);
  });
});
