import { describe, expect, it } from "vitest";

import { getCreateRequestFeedback } from "../src/creation/create-error-feedback";
import { getCreateCopy } from "../src/localization/screen-copy";

describe("Create request feedback", () => {
  it("maps timeout errors to localized copy", () => {
    const copy = getCreateCopy("fr");
    expect(getCreateRequestFeedback(new Error("API request timed out"), copy)).toBe(copy.requestTimedOut);
  });

  it("maps cancellation errors to localized copy", () => {
    const copy = getCreateCopy("ar");
    expect(getCreateRequestFeedback(new Error("API request cancelled"), copy)).toBe(copy.requestCancelled);
  });

  it("returns null for unrelated errors", () => {
    expect(getCreateRequestFeedback(new Error("storage unavailable"), getCreateCopy("en"))).toBeNull();
  });
});
