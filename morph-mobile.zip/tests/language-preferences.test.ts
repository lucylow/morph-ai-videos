import { beforeEach, describe, expect, it, vi } from "vitest";

const storage = new Map<string, string>();
vi.mock("@react-native-async-storage/async-storage", () => ({ default: { getItem: vi.fn(async (key: string) => storage.get(key) ?? null), setItem: vi.fn(async (key: string, value: string) => { storage.set(key, value); }) } }));

import { defaultLanguagePreference, getLanguagePresentation, loadLanguagePreference, localizedShellLabels, normalizeLanguagePreference, saveLanguagePreference, subscribeLanguagePreference } from "../src/localization/language-preferences";

describe("language preferences", () => {
  beforeEach(() => storage.clear());
  it("normalizes invalid language values and keeps safe defaults", () => { expect(normalizeLanguagePreference({ interfaceLanguage: "invalid" as never })).toEqual(defaultLanguagePreference); expect(normalizeLanguagePreference({ autoTranslateAI: false }).autoTranslateAI).toBe(false); });
  it("persists normalized preferences", async () => { await saveLanguagePreference({ interfaceLanguage: "fr", contentLanguage: "ar" }); expect(await loadLanguagePreference()).toMatchObject({ interfaceLanguage: "fr", contentLanguage: "ar" }); });
  it("provides localized shell labels and direction metadata", () => { expect(localizedShellLabels("fr").stories).toBe("Histoires"); expect(getLanguagePresentation("ar").direction).toBe("rtl"); });
  it("notifies active listeners and supports cleanup", async () => { const updates: string[] = []; const unsubscribe = subscribeLanguagePreference((preference) => updates.push(preference.interfaceLanguage)); await saveLanguagePreference({ interfaceLanguage: "ja" }); unsubscribe(); await saveLanguagePreference({ interfaceLanguage: "fr" }); expect(updates).toEqual(["ja"]); });
  it("isolates listener failures after persistence succeeds", async () => { subscribeLanguagePreference(() => { throw new Error("listener failed"); }); await expect(saveLanguagePreference({ interfaceLanguage: "ar" })).resolves.toMatchObject({ interfaceLanguage: "ar" }); expect(await loadLanguagePreference()).toMatchObject({ interfaceLanguage: "ar" }); });
});
