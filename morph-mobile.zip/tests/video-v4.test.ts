import { describe, expect, it } from "vitest";
import { buildVideoGenerationTaskGraph, normalizeVideoGenerationRequest, normalizeVideoJob, normalizeVideoQuality, selectBestVideoCandidate, type VideoCandidate, type VideoGenerationJobV4 } from "../src/ai/video-v4";

describe("video generation v4", () => {
  it("normalizes bounded requests and deduplicates references", () => {
    const request = normalizeVideoGenerationRequest({ id: " v4-1 ", userId: " local ", prompt: "  a cinematic door  ", intent: "story_to_video", durationSeconds: 99, aspectRatio: "9:16", resolution: "1080p", characterIds: ["nova", "nova", ""], referenceAssetIds: ["asset-1", "asset-1"], style: "  noir ", audio: 1 as unknown as boolean });
    expect(request.id).toBe("v4-1");
    expect(request.prompt).toBe("a cinematic door");
    expect(request.durationSeconds).toBe(60);
    expect(request.characterIds).toEqual(["nova"]);
    expect(request.referenceAssetIds).toEqual(["asset-1"]);
    expect(request.audio).toBe(true);
  });

  it("bounds quality scores and computes overall when absent", () => {
    const quality = normalizeVideoQuality({ promptAlignment: 2, characterConsistency: -1, visualQuality: 0.8 });
    expect(quality.promptAlignment).toBe(1);
    expect(quality.characterConsistency).toBe(0);
    expect(quality.visualQuality).toBe(0.8);
    expect(quality.overall).toBeGreaterThan(0);
    expect(quality.overall).toBeLessThanOrEqual(1);
  });

  it("builds the V4 pipeline on the existing task graph boundary", () => {
    const graph = buildVideoGenerationTaskGraph({ id: "request-1", userId: "local", prompt: "make a scene", intent: "remix", durationSeconds: 8, aspectRatio: "9:16", resolution: "720p", audio: false });
    expect(graph.rootTask).toBe("understand");
    expect(graph.nodes.map((node) => node.id)).toEqual(["understand", "context", "direct", "shots", "generate", "evaluate", "repair", "remember"]);
    expect(graph.nodes.find((node) => node.id === "generate")?.dependencies).toEqual(["shots"]);
  });

  it("normalizes invalid selection and picks the highest quality ready candidate", () => {
    const candidates: VideoCandidate[] = [
      { id: "low", provider: "p1", model: "m1", durationMs: 1000, prompt: "low", status: "ready", quality: normalizeVideoQuality({ overall: 0.4 }) },
      { id: "best", provider: "p2", model: "m2", durationMs: 1000, prompt: "best", status: "ready", quality: normalizeVideoQuality({ overall: 0.9 }) },
      { id: "pending", provider: "p3", model: "m3", durationMs: 1000, prompt: "pending", status: "pending", quality: normalizeVideoQuality({ overall: 1 }) },
    ];
    expect(selectBestVideoCandidate(candidates)?.id).toBe("best");
    const job: VideoGenerationJobV4 = { id: "job", requestId: "request", status: "evaluating", progress: 4, candidates, selectedCandidateId: "missing", createdAt: "now" };
    expect(normalizeVideoJob(job).progress).toBe(1);
    expect(normalizeVideoJob(job).selectedCandidateId).toBeUndefined();
  });
});
