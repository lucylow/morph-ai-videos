import { describe, expect, it } from "vitest";
import { createKernelRequest, normalizeCreativePlan, topologicalSort, validateTaskGraph, type AITaskGraph } from "../src/ai/kernel-v3";

const graph: AITaskGraph = { id: "g1", rootTask: "understand", createdAt: "now", nodes: [{ id: "understand", type: "understand", description: "Understand", dependencies: [], status: "completed" }, { id: "plan", type: "plan", description: "Plan", dependencies: ["understand"], status: "pending" }, { id: "generate", type: "generate", description: "Generate", dependencies: ["plan"], status: "pending" }] };

describe("AI kernel v3", () => {
  it("normalizes kernel requests without inventing attachments", () => { const request = createKernelRequest({ userId: "local", intent: "create", prompt: "  make a scene  ", attachments: ["", "image-1"] }); expect(request.id).toMatch(/^kernel-/); expect(request.prompt).toBe("make a scene"); expect(request.attachments).toEqual(["image-1"]); });
  it("validates and orders dependent tasks", () => { expect(validateTaskGraph(graph).valid).toBe(true); expect(topologicalSort(graph).map((node) => node.id)).toEqual(["understand", "plan", "generate"]); });
  it("rejects cycles", () => { const cyclic = { ...graph, nodes: graph.nodes.map((node) => node.id === "understand" ? { ...node, dependencies: ["generate"] } : node) }; expect(() => topologicalSort(cyclic)).toThrow("AI_TASK_CYCLE"); });
  it("bounds creative plans to safe mobile payload sizes", () => { const plan = normalizeCreativePlan({ objective: "  Make it vivid ", subgoals: [{ id: "a", goal: "go", priority: 4 }], constraints: ["  no shortcuts "], successCriteria: ["clear ending"] }); expect(plan.objective).toBe("Make it vivid"); expect(plan.subgoals[0].priority).toBe(1); expect(plan.constraints).toEqual(["no shortcuts"]); });
});
