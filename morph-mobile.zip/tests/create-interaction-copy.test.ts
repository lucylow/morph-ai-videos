import { describe, expect, it } from "vitest";
import { getCreateInteractionCopy } from "../src/localization/create-interaction-copy";

describe("Create interaction copy", () => {
  it("localizes recovery and generation hints", () => {
    expect(getCreateInteractionCopy("fr").retrySaveHint).toContain("Réessaie");
    expect(getCreateInteractionCopy("es").cancelHint).toContain("Detiene");
    expect(getCreateInteractionCopy("ar").backHint).toContain("الشاشة");
    expect(getCreateInteractionCopy("fr").draftRecovery).toContain("derniers choix");
    expect(getCreateInteractionCopy("es").cameraPermissionTitle).toContain("cámara");
  });

  it("falls back to English for unsupported languages", () => {
    expect(getCreateInteractionCopy("ja").creativeIdeaHint).toBe("Fills the premise with a new creative idea");
    expect(getCreateInteractionCopy("ja").cameraPermissionBody).toContain("Settings");
  });
});
