import { describe, expect, it, vi } from "vitest";
import { canApplyCreateFeedbackState, canApplyCreateHydrationState, canApplyGenerationResult, canApplyGenerationState, canStartGeneration, canStartPersistenceRetry, clearGenerationTimers, getGenerationRetryAccessibilityState, getRetrySaveAccessibilityState, nextGenerationRunId, resetGenerationTimers } from "../src/creation/generation-lifecycle";

describe("generation lifecycle cleanup", () => {
  it("clears both generation and timeout handles", () => {
    const generation = setTimeout(() => undefined, 1000);
    const timeout = setTimeout(() => undefined, 1000);
    const clearSpy = vi.spyOn(globalThis, "clearTimeout");
    clearGenerationTimers({ generation, timeout });
    expect(clearSpy).toHaveBeenCalledWith(generation);
    expect(clearSpy).toHaveBeenCalledWith(timeout);
    clearSpy.mockRestore();
  });

  it("only applies results for mounted current runs", () => {
    expect(canApplyGenerationResult(true, true)).toBe(true);
    expect(canApplyGenerationResult(false, true)).toBe(false);
    expect(canApplyGenerationResult(true, false)).toBe(false);
    expect(canApplyGenerationResult(true, true)).toBe(true);
  });

  it("uses the same mounted-current contract for progress updates", () => {
    expect(canApplyGenerationState(true, true)).toBe(true);
    expect(canApplyGenerationState(false, true)).toBe(false);
    expect(canApplyGenerationState(true, false)).toBe(false);
  });

  it("creates safe monotonic run identifiers", () => {
    expect(nextGenerationRunId(0)).toBe(1);
    expect(nextGenerationRunId(7)).toBe(8);
    expect(nextGenerationRunId(-1)).toBe(1);
    expect(nextGenerationRunId("7")).toBe(1);
    expect(nextGenerationRunId(Number.MAX_SAFE_INTEGER)).toBe(1);
  });

  it("rejects overlapping persistence retries", () => {
    expect(canStartPersistenceRetry(false)).toBe(true);
    expect(canStartPersistenceRetry(true)).toBe(false);
  });

  it("exposes busy and disabled state while a retry is active", () => {
    expect(getRetrySaveAccessibilityState(false)).toEqual({ disabled: false, busy: false });
    expect(getRetrySaveAccessibilityState(true)).toEqual({ disabled: true, busy: true });
  });

  it("rejects generation starts while another Create task is active", () => {
    expect(canStartGeneration(false, false)).toBe(true);
    expect(canStartGeneration(true, false)).toBe(false);
    expect(canStartGeneration(false, true)).toBe(false);
  });

  it("only applies Create hydration while mounted", () => {
    expect(canApplyCreateHydrationState(true)).toBe(true);
    expect(canApplyCreateHydrationState(false)).toBe(false);
  });

  it("only applies Create feedback while mounted", () => {
    expect(canApplyCreateFeedbackState(true)).toBe(true);
    expect(canApplyCreateFeedbackState(false)).toBe(false);
  });

  it("marks generation retry busy whenever generation or persistence is active", () => {
    expect(getGenerationRetryAccessibilityState(false, false)).toEqual({ disabled: false, busy: false });
    expect(getGenerationRetryAccessibilityState(true, false)).toEqual({ disabled: true, busy: true });
    expect(getGenerationRetryAccessibilityState(false, true)).toEqual({ disabled: true, busy: true });
  });

  it("accepts empty timer refs", () => {
    expect(() => clearGenerationTimers({ generation: null, timeout: null })).not.toThrow();
  });

  it("returns empty timer refs after cleanup", () => {
    const generation = setTimeout(() => undefined, 1000);
    const timeout = setTimeout(() => undefined, 1000);
    const emptyTimers = resetGenerationTimers({ generation, timeout });
    expect(emptyTimers).toEqual({ generation: null, timeout: null });
  });

  it("keeps consumed timer cleanup idempotent", () => {
    expect(resetGenerationTimers({ generation: null, timeout: null })).toEqual({ generation: null, timeout: null });
  });
});
