import { describe, expect, it, vi } from "vitest";
import { persistCreationRecords } from "../src/creation/persistence-outcome";

describe("creation persistence outcomes", () => {
  it("stops before the episode when character persistence fails", async () => {
    const order: string[] = [];
    const outcome = await persistCreationRecords({
      saveCharacter: vi.fn(async () => { order.push("character"); throw new Error("character storage unavailable"); }),
      saveEpisode: vi.fn(async () => { order.push("episode"); }),
      clearDraft: vi.fn(async () => { order.push("draft"); }),
    });

    expect(outcome).toMatchObject({ character: "pending", episode: "pending", failedStage: "character" });
    expect(order).toEqual(["character"]);
  });

  it("keeps the character saved when episode persistence fails", async () => {
    const clearDraft = vi.fn(async () => undefined);
    const outcome = await persistCreationRecords({
      saveCharacter: vi.fn(async () => undefined),
      saveEpisode: vi.fn(async () => { throw new Error("episode storage unavailable"); }),
      clearDraft,
    });

    expect(outcome).toMatchObject({ character: "saved", episode: "pending", failedStage: "episode" });
    expect(clearDraft).not.toHaveBeenCalled();
  });

  it("clears the draft only after both records are saved", async () => {
    const order: string[] = [];
    const outcome = await persistCreationRecords({
      saveCharacter: vi.fn(async () => { order.push("character"); }),
      saveEpisode: vi.fn(async () => { order.push("episode"); }),
      clearDraft: vi.fn(async () => { order.push("draft"); }),
    });

    expect(outcome).toEqual({ character: "saved", episode: "saved", failedStage: null, error: null });
    expect(order).toEqual(["character", "episode", "draft"]);
  });
});
