import { describe, expect, it } from "vitest";
import { calculateSceneImportance, createGenerationGraph, orderGenerationGraph, passesV5QualityGate, prioritizeScenes, rankV5Candidates } from "../src/ai/video-v5";
import { normalizeVideoQuality, type VideoCandidate } from "../src/ai/video-v4";

describe("video generation v5", () => {
  it("builds and orders the multimodal generation graph", () => {
    const graph = createGenerationGraph("request-1", "graph-1");
    expect(graph.id).toBe("graph-1");
    expect(graph.edges).toContainEqual({ from: "camera", to: "motion" });
    expect(orderGenerationGraph(graph).map((node) => node.id)).toEqual(["context", "storyboard", "shots", "audio", "camera", "motion", "generation", "evaluation", "repair", "postprocess"]);
  });

  it("rejects graph cycles", () => {
    const graph = createGenerationGraph("request-1");
    graph.nodes[0].dependencies = ["postprocess"];
    expect(() => orderGenerationGraph(graph)).toThrow("V5_GENERATION_GRAPH_CYCLE");
  });

  it("prioritizes scenes using bounded narrative signals", () => {
    const importance = calculateSceneImportance({ story: 2, emotion: 0, character: 1, visual: 1, novelty: 0.5 });
    expect(importance.story).toBe(1);
    expect(importance.emotion).toBe(0);
    expect(importance.total).toBeGreaterThan(0);
    const ranked = prioritizeScenes([{ id: "quiet", importance: 0.2, characters: [], semanticTags: [] }, { id: "hero", importance: 0.9, emotionalTone: "hope", characters: ["a", "b"], semanticTags: ["door"] }]);
    expect(ranked[0].scene.id).toBe("hero");
  });

  it("filters candidates through identity, temporal, and artifact gates", () => {
    const gate = { minimumOverall: 0.7, minimumTemporal: 0.7, minimumIdentity: 0.7, maximumArtifact: 0.2 };
    const passing = { id: "pass", provider: "p", model: "m", durationMs: 1000, prompt: "pass", status: "ready", quality: normalizeVideoQuality({ overall: 0.9, temporalConsistency: 0.9, characterConsistency: 0.8, artifactScore: 0.1 }) } satisfies VideoCandidate;
    const rejected = { id: "reject", provider: "p", model: "m", durationMs: 1000, prompt: "reject", status: "ready", quality: normalizeVideoQuality({ overall: 0.95, temporalConsistency: 0.9, characterConsistency: 0.9, artifactScore: 0.5 }) } satisfies VideoCandidate;
    expect(passesV5QualityGate(passing.quality!, gate)).toBe(true);
    expect(rankV5Candidates([rejected, passing], gate).map((candidate) => candidate.id)).toEqual(["pass"]);
  });
});
