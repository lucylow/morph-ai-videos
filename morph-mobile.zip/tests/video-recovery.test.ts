import { describe, expect, it } from "vitest";
import { beginPlaybackRetry, canRetryPlayback, canStartVideoImport, classifyPlaybackError, clearPlaybackError, resolvePlaybackStatus, type VideoRecoveryState } from "../src/video/video-recovery";

const ready: VideoRecoveryState = { hasSource: true, status: "ready", hasError: false };

describe("video recovery", () => {
  it("blocks duplicate imports while an import is active", () => {
    expect(canStartVideoImport(false)).toBe(true);
    expect(canStartVideoImport(true)).toBe(false);
  });

  it("only allows retry when a source exists and playback is not loading", () => {
    expect(canRetryPlayback(ready)).toBe(true);
    expect(canRetryPlayback({ ...ready, hasSource: false })).toBe(false);
    expect(canRetryPlayback({ ...ready, status: "loading" })).toBe(false);
  });

  it("moves an eligible retry into a clean loading state", () => {
    expect(beginPlaybackRetry({ ...ready, status: "error", hasError: true })).toEqual({ hasSource: true, status: "loading", hasError: false });
    expect(beginPlaybackRetry({ ...ready, status: "loading" })).toEqual({ ...ready, status: "loading" });
  });

  it("classifies provider errors without exposing their raw messages", () => {
    expect(classifyPlaybackError(new Error("network timeout"))).toBe("network");
    expect(classifyPlaybackError(new Error("unsupported codec"))).toBe("format");
    expect(classifyPlaybackError(new Error("provider secret: abc"))).toBe("unknown");
  });

  it("normalizes status events and clears recovered errors", () => {
    const errored = resolvePlaybackStatus(ready, "error");
    expect(errored).toEqual({ hasSource: true, status: "error", hasError: true });
    expect(clearPlaybackError(errored)).toEqual(ready);
    expect(resolvePlaybackStatus({ hasSource: false, status: "idle", hasError: false }, "ready")).toEqual({ hasSource: false, status: "ready", hasError: false });
  });
});
