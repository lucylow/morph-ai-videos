import { describe, expect, it } from "vitest";
import { getCharacterDetailCopy } from "../src/localization/character-copy";

describe("Character Detail localization", () => {
  it("provides editor copy for every supported language", () => {
    for (const language of ["en", "fr", "es", "ar"] as const) {
      const copy = getCharacterDetailCopy(language);
      expect(copy.edit.length).toBeGreaterThan(0);
      expect(copy.saved.length).toBeGreaterThan(0);
      expect(copy.retry.length).toBeGreaterThan(0);
    }
  });

  it("falls back safely for an unknown language", () => {
    expect(getCharacterDetailCopy("de" as never).save).toBe("Save");
  });
});
