import { beforeEach, describe, expect, it, vi } from "vitest";

const { launchImageLibraryAsync } = vi.hoisted(() => ({ launchImageLibraryAsync: vi.fn() }));
vi.mock("expo-image-picker", () => ({ launchImageLibraryAsync }));

import { pickVideoFromLibrary } from "../src/video/video-picker";

describe("video picker", () => {
  beforeEach(() => { launchImageLibraryAsync.mockReset(); });
  it("returns selected video metadata", async () => { launchImageLibraryAsync.mockResolvedValue({ canceled: false, assets: [{ uri: "  file://scene.mov  ", fileName: "scene.mov", duration: 4200, width: 1920, height: 1080 }] }); const result = await pickVideoFromLibrary(); expect(result.ok).toBe(true); if (result.ok) expect(result.video).toEqual({ uri: "file://scene.mov", fileName: "scene.mov", durationMs: 4200, width: 1920, height: 1080 }); });
  it("drops invalid optional metadata without rejecting a readable video", async () => { launchImageLibraryAsync.mockResolvedValue({ canceled: false, assets: [{ uri: "file://scene.mov", fileName: "  ", duration: -1, width: Number.NaN, height: Number.POSITIVE_INFINITY }] }); const result = await pickVideoFromLibrary(); expect(result).toEqual({ ok: true, video: { uri: "file://scene.mov", fileName: undefined, durationMs: undefined, width: undefined, height: undefined } }); });
  it("treats picker cancellation as a safe no-op", async () => { launchImageLibraryAsync.mockResolvedValue({ canceled: true, assets: [] }); expect(await pickVideoFromLibrary()).toEqual({ ok: false, canceled: true }); });
  it("rejects selected assets without a readable URI", async () => { launchImageLibraryAsync.mockResolvedValue({ canceled: false, assets: [{ uri: "" }] }); const result = await pickVideoFromLibrary(); expect(result).toEqual({ ok: false, canceled: false, error: { kind: "media", message: "The media couldn't be processed.", retryable: true } }); });
  it("normalizes picker failures for safe UI messaging", async () => { launchImageLibraryAsync.mockRejectedValue(new Error("picker failed")); const result = await pickVideoFromLibrary(); expect(result.ok).toBe(false); if (!result.ok) expect(result.error?.kind).toBe("media"); });
});
