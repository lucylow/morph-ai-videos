# Expo Video SDK 54 implementation notes

Source: /home/ubuntu/morph-mobile_helper/docs/media/video/DOCS.md

The project uses `expo-video` with `useVideoPlayer` and `VideoView`. Player state should be observed through player listeners because player properties do not automatically update React state. The implementation uses `playingChange` and `statusChange` listeners, renders `VideoView` only after a selected URI exists, and shows loading/error messaging. Players created through `useVideoPlayer` are lifecycle-managed. Fullscreen and picture-in-picture are supported by the existing app configuration.
