import { Pressable, StyleSheet, Text, View, type PressableProps, type StyleProp, type TextStyle, type ViewStyle } from "react-native";
import { morphTokens, pressOpacity } from "@/src/ui/morph-tokens";

type ButtonProps = Omit<PressableProps, "children"> & { title: string; accessibilityHint?: string; style?: StyleProp<ViewStyle> };

export function SurfaceCard({ children, elevated = false, style }: { children: React.ReactNode; elevated?: boolean; style?: StyleProp<ViewStyle> }) {
  return <View style={[styles.surfaceCard, elevated && morphTokens.shadows.subtle, style]}>{children}</View>;
}

export function PrimaryButton({ title, disabled, accessibilityLabel, ...props }: ButtonProps) {
  const isDisabled = disabled === true;
  return <Pressable {...props} disabled={isDisabled} accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} accessibilityState={{ disabled: isDisabled }} style={({ pressed }) => [styles.primaryButton, { opacity: pressOpacity(pressed, isDisabled) }, isDisabled && styles.disabledButton, props.style]}><Text style={[styles.primaryText, isDisabled && styles.disabledText]}>{title}</Text></Pressable>;
}

export function SecondaryButton({ title, disabled, accessibilityLabel, ...props }: ButtonProps) {
  const isDisabled = disabled === true;
  return <Pressable {...props} disabled={isDisabled} accessibilityRole="button" accessibilityLabel={accessibilityLabel ?? title} accessibilityState={{ disabled: isDisabled }} style={({ pressed }) => [styles.secondaryButton, { opacity: pressOpacity(pressed, isDisabled) }, props.style]}><Text style={styles.secondaryText}>{title}</Text></Pressable>;
}

export function IconButton({ label, icon, onPress, hint, style }: { label: string; icon: React.ReactNode; onPress: () => void; hint?: string; style?: StyleProp<ViewStyle> }) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityHint={hint} onPress={onPress} style={({ pressed }) => [styles.iconButton, { opacity: pressOpacity(pressed) }, style]}>{icon}</Pressable>;
}

export function AIButton({ title, loading = false, onPress }: { title: string; loading?: boolean; onPress: () => void }) {
  return <PrimaryButton title={loading ? "Thinking…" : `✦ ${title}`} onPress={onPress} disabled={loading} accessibilityLabel={loading ? "AI is thinking" : title} accessibilityHint="Opens MORPH’s AI creative tools" />;
}

export function Badge({ label, tone = "neutral" }: { label: string; tone?: "neutral" | "accent" | "success" | "warning" }) {
  const color = tone === "accent" ? morphTokens.colors.violet : tone === "success" ? morphTokens.colors.success : tone === "warning" ? morphTokens.colors.warning : morphTokens.colors.muted;
  return <View accessible accessibilityRole="text" accessibilityLabel={label} style={[styles.badge, { borderColor: color }]}><Text style={[styles.badgeText, { color }]}>{label}</Text></View>;
}

export function Typography({ children, variant = "body", style }: { children: React.ReactNode; variant?: keyof typeof morphTokens.typography; style?: StyleProp<TextStyle> }) {
  return <Text style={[styles.text, morphTokens.typography[variant], style]}>{children}</Text>;
}

const styles = StyleSheet.create({
  surfaceCard: { backgroundColor: morphTokens.colors.surface, borderRadius: morphTokens.radius.xl, borderWidth: 1, borderColor: morphTokens.colors.border, padding: morphTokens.spacing.xl },
  primaryButton: { minHeight: 54, paddingHorizontal: morphTokens.spacing.xl, borderRadius: morphTokens.radius.lg, alignItems: "center", justifyContent: "center", backgroundColor: morphTokens.colors.accent },
  secondaryButton: { minHeight: 52, paddingHorizontal: morphTokens.spacing.xl, borderRadius: morphTokens.radius.lg, alignItems: "center", justifyContent: "center", backgroundColor: morphTokens.colors.surfaceStrong, borderWidth: 1, borderColor: morphTokens.colors.border },
  iconButton: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center", backgroundColor: morphTokens.colors.surfaceStrong },
  primaryText: { color: morphTokens.colors.background, fontSize: 16, fontWeight: "800" },
  secondaryText: { color: morphTokens.colors.foreground, fontSize: 14, fontWeight: "800" },
  disabledButton: { backgroundColor: morphTokens.colors.surfaceStrong },
  disabledText: { color: morphTokens.colors.muted },
  badge: { alignSelf: "flex-start", paddingHorizontal: morphTokens.spacing.sm, paddingVertical: 5, borderRadius: morphTokens.radius.pill, borderWidth: 1 },
  badgeText: { fontSize: 11, fontWeight: "800" },
  text: { color: morphTokens.colors.foreground },
});
