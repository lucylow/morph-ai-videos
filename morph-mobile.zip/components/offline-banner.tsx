import * as Network from "expo-network";
import { StyleSheet, Text, View } from "react-native";
import { useLanguagePreference } from "@/hooks/use-language-preference";
import { getSystemCopy } from "@/src/localization/system-copy";
import { shouldShowOfflineBanner } from "@/src/mobile/mobile-state";

export function OfflineBanner() {
  const network = Network.useNetworkState();
  const { language, presentation } = useLanguagePreference();
  const copy = getSystemCopy(language);
  if (!shouldShowOfflineBanner(network)) return null;
  return <View accessibilityRole="alert" accessibilityLiveRegion="polite" style={styles.container}><Text style={[styles.text, presentation.direction === "rtl" && styles.rtl]}>{copy.offlineDrafts}</Text></View>;
}

const styles = StyleSheet.create({ container: { backgroundColor: "#242331", borderBottomWidth: 1, borderBottomColor: "#3A394B", paddingHorizontal: 16, paddingVertical: 8 }, text: { color: "#F7F4EF", textAlign: "center", fontSize: 12, fontWeight: "700" }, rtl: { writingDirection: "rtl" } });
