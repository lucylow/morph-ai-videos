import { Component, type ErrorInfo, type ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

interface Props { children: ReactNode; onReset: () => void; }
interface State { hasError: boolean; }

export class MorphErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State { return { hasError: true }; }

  componentDidCatch(error: Error, info: ErrorInfo) {
    if (__DEV__) console.warn("MORPH render recovery", error.message, info.componentStack);
  }

  handleReset = () => { try { this.setState({ hasError: false }); this.props.onReset(); } catch (error) { if (__DEV__) console.warn("MORPH recovery navigation failed", error instanceof Error ? error.message : String(error)); this.setState({ hasError: true }); } };

  render() {
    if (!this.state.hasError) return this.props.children;
    return <View style={styles.screen}><Text style={styles.kicker}>MORPH / RECOVERY</Text><Text style={styles.title}>This scene needs{`\n`}a fresh start.</Text><Text style={styles.copy}>An unexpected screen error occurred. Your saved characters and drafts are still protected.</Text><Pressable accessibilityRole="button" accessibilityLabel="Return home" accessibilityHint="Leaves the failed screen and returns to the MORPH home screen" onPress={this.handleReset} style={({ pressed }) => [styles.button, pressed && { opacity: 0.8 }]}><Text style={styles.buttonText}>Return home ↗</Text></Pressable></View>;
  }
}

const styles = StyleSheet.create({ screen: { flex: 1, backgroundColor: "#0B0B10", justifyContent: "center", padding: 24 }, kicker: { color: "#D7F36B", fontSize: 10, fontWeight: "900", letterSpacing: 1.8 }, title: { color: "#F7F4EF", fontSize: 34, lineHeight: 37, fontWeight: "900", marginTop: 12 }, copy: { color: "#A9A6B2", fontSize: 14, lineHeight: 20, marginTop: 14, maxWidth: 320 }, button: { marginTop: 28, height: 54, borderRadius: 16, backgroundColor: "#D7F36B", justifyContent: "center", alignItems: "center" }, buttonText: { color: "#0B0B10", fontSize: 14, fontWeight: "800" } });
