export function motionDuration(reduceMotion: boolean, durationMs: number): number {
  if (!Number.isFinite(durationMs) || durationMs < 0) return 0;
  return reduceMotion ? 0 : durationMs;
}
