export const morphTokens = {
  spacing: { xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 24, xxxl: 32, huge: 48 },
  radius: { sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, pill: 999 },
  typography: {
    display: { fontSize: 34, lineHeight: 40, fontWeight: "900" as const },
    title: { fontSize: 28, lineHeight: 34, fontWeight: "800" as const },
    section: { fontSize: 20, lineHeight: 26, fontWeight: "800" as const },
    body: { fontSize: 16, lineHeight: 23, fontWeight: "400" as const },
    label: { fontSize: 13, lineHeight: 18, fontWeight: "700" as const },
    caption: { fontSize: 12, lineHeight: 16, fontWeight: "600" as const },
  },
  motion: { fast: 120, normal: 220, slow: 380 },
  colors: {
    background: "#0B0B10",
    surface: "#151521",
    surfaceStrong: "#202032",
    foreground: "#F7F4EF",
    muted: "#A9A6B2",
    border: "#2B2A3A",
    accent: "#D7F36B",
    accentStrong: "#B7D744",
    coral: "#FF7B68",
    violet: "#8B7CFF",
    success: "#6EE7B7",
    warning: "#F7C66B",
    danger: "#FF8A8A",
  },
  shadows: {
    subtle: { boxShadow: "0px 3px 8px rgba(0, 0, 0, 0.16)", elevation: 2 },
    elevated: { boxShadow: "0px 8px 18px rgba(0, 0, 0, 0.24)", elevation: 5 },
  },
} as const;

export type MorphTokens = typeof morphTokens;
export type MorphTypographyKey = keyof typeof morphTokens.typography;

export function pressOpacity(pressed: boolean, disabled = false): number {
  if (disabled) return 0.5;
  return pressed ? 0.78 : 1;
}

export function selectedSurface(selected: boolean): { backgroundColor: string; borderColor: string } {
  return selected ? { backgroundColor: "#2A2027", borderColor: morphTokens.colors.coral } : { backgroundColor: morphTokens.colors.surface, borderColor: morphTokens.colors.border };
}
