import type { VideoCandidate, VideoGenerationQuality } from "./video-v4";

export type GenerationGraphNodeType = "context" | "storyboard" | "shot" | "camera" | "motion" | "audio" | "generation" | "evaluation" | "repair" | "postprocess";
export type GenerationGraphStatus = "planning" | "executing" | "completed" | "failed";
export type GenerationNodeStatus = "pending" | "running" | "completed" | "failed";

export interface GenerationNode {
  id: string;
  type: GenerationGraphNodeType;
  dependencies: string[];
  status: GenerationNodeStatus;
  result?: unknown;
}

export interface GenerationEdge { from: string; to: string; }

export interface GenerationGraph {
  id: string;
  requestId: string;
  nodes: GenerationNode[];
  edges: GenerationEdge[];
  status: GenerationGraphStatus;
}

export interface V5Scene {
  id: string;
  importance: number;
  emotionalTone?: string;
  characters: string[];
  semanticTags: string[];
}

export interface SceneImportance {
  story: number;
  emotion: number;
  character: number;
  visual: number;
  novelty: number;
  total: number;
}

export interface V5QualityGate {
  minimumOverall: number;
  minimumTemporal: number;
  minimumIdentity: number;
  maximumArtifact: number;
}

const clampUnit = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : 0;
const cleanId = (value: string, fallback: string) => value.trim() || fallback;

export function calculateSceneImportance(input: Omit<SceneImportance, "total">): SceneImportance {
  const bounded = { story: clampUnit(input.story), emotion: clampUnit(input.emotion), character: clampUnit(input.character), visual: clampUnit(input.visual), novelty: clampUnit(input.novelty) };
  return { ...bounded, total: bounded.story * 0.3 + bounded.emotion * 0.2 + bounded.character * 0.2 + bounded.visual * 0.15 + bounded.novelty * 0.15 };
}

export function prioritizeScenes(scenes: V5Scene[]): { scene: V5Scene; importance: SceneImportance }[] {
  return scenes.map((scene) => ({ scene, importance: calculateSceneImportance({ story: scene.importance, emotion: scene.emotionalTone ? 0.8 : 0.4, character: Math.min(1, scene.characters.length / 3), visual: scene.semanticTags.length ? 0.8 : 0.5, novelty: 0.7 }) })).sort((a, b) => b.importance.total - a.importance.total);
}

export function createGenerationGraph(requestId: string, graphId = `generation-v5-${Date.now()}`): GenerationGraph {
  const makeNode = (id: string, type: GenerationGraphNodeType, dependencies: string[]): GenerationNode => ({ id, type, dependencies, status: "pending" });
  const nodes = [
    makeNode("context", "context", []),
    makeNode("storyboard", "storyboard", ["context"]),
    makeNode("shots", "shot", ["storyboard"]),
    makeNode("camera", "camera", ["shots"]),
    makeNode("motion", "motion", ["shots", "camera"]),
    makeNode("audio", "audio", ["storyboard"]),
    makeNode("generation", "generation", ["camera", "motion", "audio"]),
    makeNode("evaluation", "evaluation", ["generation"]),
    makeNode("repair", "repair", ["evaluation"]),
    makeNode("postprocess", "postprocess", ["repair"]),
  ];
  return { id: cleanId(graphId, `generation-v5-${Date.now()}`), requestId: requestId.trim(), nodes, edges: nodes.flatMap((node) => node.dependencies.map((from) => ({ from, to: node.id }))), status: "planning" };
}

export function validateGenerationGraph(graph: GenerationGraph): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const ids = new Set<string>();
  for (const node of graph.nodes) { if (!node.id.trim()) errors.push("EMPTY_NODE_ID"); else if (ids.has(node.id)) errors.push(`DUPLICATE_NODE:${node.id}`); ids.add(node.id); }
  for (const node of graph.nodes) for (const dependency of node.dependencies) if (!ids.has(dependency)) errors.push(`MISSING_DEPENDENCY:${dependency}`);
  for (const edge of graph.edges) if (!ids.has(edge.from) || !ids.has(edge.to)) errors.push(`INVALID_EDGE:${edge.from}->${edge.to}`);
  return { valid: errors.length === 0, errors };
}

export function orderGenerationGraph(graph: GenerationGraph): GenerationNode[] {
  const validation = validateGenerationGraph(graph);
  if (!validation.valid) throw new Error("V5_GENERATION_GRAPH_INVALID");
  const pending = new Map(graph.nodes.map((node) => [node.id, node]));
  const ordered: GenerationNode[] = [];
  while (pending.size) {
    const ready = [...pending.values()].filter((node) => node.dependencies.every((dependency) => ordered.some((item) => item.id === dependency)));
    if (!ready.length) throw new Error("V5_GENERATION_GRAPH_CYCLE");
    ready.forEach((node) => { ordered.push(node); pending.delete(node.id); });
  }
  return ordered;
}

export function passesV5QualityGate(quality: VideoGenerationQuality, gate: V5QualityGate): boolean {
  return clampUnit(quality.overall) >= clampUnit(gate.minimumOverall) && clampUnit(quality.temporalConsistency) >= clampUnit(gate.minimumTemporal) && clampUnit(quality.characterConsistency) >= clampUnit(gate.minimumIdentity) && clampUnit(quality.artifactScore) <= clampUnit(gate.maximumArtifact);
}

export function rankV5Candidates(candidates: VideoCandidate[], gate: V5QualityGate): VideoCandidate[] {
  return candidates.filter((candidate) => candidate.status === "ready" && candidate.quality && passesV5QualityGate(candidate.quality, gate)).sort((a, b) => (b.quality?.overall ?? 0) - (a.quality?.overall ?? 0));
}
