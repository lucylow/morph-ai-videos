export type AIKernelIntent = "create" | "edit" | "continue" | "remix" | "explore" | "analyze" | "publish" | "organize";
export type AITaskType = "understand" | "retrieve" | "plan" | "generate" | "evaluate" | "repair" | "remember";
export type AITaskStatus = "pending" | "running" | "completed" | "failed";

export interface AIKernelRequest { id: string; userId: string; intent: AIKernelIntent; prompt: string; projectId?: string; storyId?: string; episodeId?: string; sceneId?: string; attachments?: string[]; metadata?: Record<string, unknown>; }
export interface CopilotAction { id: string; label: string; intent: AIKernelIntent; }
export interface AIKernelResponse<T = unknown> { requestId: string; result: T; confidence: number; actions: CopilotAction[]; memoriesCreated: number; toolsUsed: string[]; elapsedMs: number; }
export interface AITaskNode { id: string; type: AITaskType; description: string; dependencies: string[]; status: AITaskStatus; result?: unknown; }
export interface AITaskGraph { id: string; nodes: AITaskNode[]; rootTask: string; createdAt: string; }
export interface CreativePlanV3 { objective: string; constraints: string[]; subgoals: { id: string; goal: string; priority: number }[]; successCriteria: string[]; }

export function createKernelRequest(input: Omit<AIKernelRequest, "id"> & { id?: string }): AIKernelRequest { return { ...input, id: input.id?.trim() || `kernel-${Date.now()}`, prompt: input.prompt.trim(), attachments: input.attachments?.filter(Boolean) }; }

export function validateTaskGraph(graph: AITaskGraph) {
  const ids = new Set<string>(); const errors: string[] = [];
  for (const node of graph.nodes) { if (ids.has(node.id)) errors.push(`Duplicate task id: ${node.id}`); ids.add(node.id); }
  if (!ids.has(graph.rootTask)) errors.push(`Missing root task: ${graph.rootTask}`);
  for (const node of graph.nodes) for (const dependency of node.dependencies) if (!ids.has(dependency)) errors.push(`Missing dependency: ${dependency}`);
  return { valid: errors.length === 0, errors };
}

export function topologicalSort(graph: AITaskGraph): AITaskNode[] {
  const validation = validateTaskGraph(graph); if (!validation.valid) throw new Error("AI_TASK_GRAPH_INVALID");
  const pending = new Map(graph.nodes.map((node) => [node.id, { ...node, dependencies: [...node.dependencies] }])); const result: AITaskNode[] = [];
  while (pending.size) { const ready = [...pending.values()].filter((node) => node.dependencies.every((dependency) => result.some((item) => item.id === dependency))); if (!ready.length) throw new Error("AI_TASK_CYCLE"); for (const node of ready) { result.push(node); pending.delete(node.id); } }
  return result;
}

export function normalizeCreativePlan(plan: Partial<CreativePlanV3>): CreativePlanV3 {
  return { objective: typeof plan.objective === "string" ? plan.objective.trim() : "Create the next meaningful story beat.", constraints: Array.isArray(plan.constraints) ? plan.constraints.filter((item): item is string => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 12) : [], subgoals: Array.isArray(plan.subgoals) ? plan.subgoals.filter((item) => item && typeof item.id === "string" && typeof item.goal === "string").map((item) => ({ id: item.id, goal: item.goal.trim(), priority: Math.max(0, Math.min(1, Number(item.priority) || 0)) })).slice(0, 12) : [], successCriteria: Array.isArray(plan.successCriteria) ? plan.successCriteria.filter((item): item is string => typeof item === "string").map((item) => item.trim()).filter(Boolean).slice(0, 12) : [] };
}

export function nextTaskAfterFailure(graph: AITaskGraph, failedId: string): AITaskNode | undefined { const ordered = topologicalSort(graph); const index = ordered.findIndex((node) => node.id === failedId); return index >= 0 ? ordered[index + 1] : undefined; }
