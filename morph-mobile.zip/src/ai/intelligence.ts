import type { AIContext, AIIntent, AIRequest } from "./contracts";

export type IntelligenceTask = "intent" | "reasoning" | "story" | "character" | "world" | "visual" | "audio" | "video" | "retrieval" | "ranking" | "critique" | "repair" | "planning" | "summarization" | "personalization";
export type ReasoningMode = "fast" | "balanced" | "deep";

export function estimateComplexity(input: string, context: Pick<AIContext, "characterIds" | "worldIds" | "memoryIds"> = {}) {
  const characters = context.characterIds?.length ?? 0;
  const worlds = context.worldIds?.length ?? 0;
  const memories = context.memoryIds?.length ?? 0;
  return Math.min(1, characters * 0.08 + worlds * 0.06 + memories * 0.04 + Math.min(input.trim().length / 5000, 1) * 0.4);
}

export function chooseReasoningMode(task: IntelligenceTask, complexity: number): ReasoningMode {
  const safeComplexity = Math.max(0, Math.min(1, complexity));
  if ((task === "visual" || task === "video" || task === "story") && safeComplexity > 0.7) return "deep";
  if (task === "intent" && safeComplexity < 0.3) return "fast";
  return safeComplexity > 0.75 ? "deep" : "balanced";
}

export function composeCopilotRequest(input: string, context: AIContext = {}): AIRequest {
  const task: AIIntent = context.storyId ? "continue_story" : "create_story";
  return { requestId: `copilot-${Date.now()}`, userId: "local-user", intent: task, input: { text: input.trim() }, context };
}
