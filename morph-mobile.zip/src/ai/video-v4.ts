import type { AITaskGraph, AITaskNode } from "./kernel-v3";

export type VideoGenerationIntent =
  | "text_to_video"
  | "image_to_video"
  | "character_to_video"
  | "scene_to_video"
  | "story_to_video"
  | "remix"
  | "continue"
  | "extend"
  | "restyle"
  | "animate_camera"
  | "animate_character"
  | "generate_broll";

export type VideoAspectRatio = "9:16" | "1:1" | "16:9";
export type VideoResolution = "720p" | "1080p" | "4k";
export type VideoJobStatus = "queued" | "planning" | "generating" | "evaluating" | "repairing" | "upscaling" | "completed" | "failed";
export type VideoCandidateStatus = "pending" | "ready" | "rejected" | "selected";

export interface VideoGenerationRequestV4 {
  id: string;
  userId: string;
  prompt: string;
  intent: VideoGenerationIntent;
  durationSeconds: number;
  aspectRatio: VideoAspectRatio;
  resolution: VideoResolution;
  characterIds?: string[];
  worldId?: string;
  storyId?: string;
  referenceAssetIds?: string[];
  style?: string;
  language?: string;
  audio: boolean;
}

export interface VideoGenerationQuality {
  promptAlignment: number;
  characterConsistency: number;
  worldConsistency: number;
  temporalConsistency: number;
  motionQuality: number;
  cameraQuality: number;
  composition: number;
  visualQuality: number;
  audioQuality: number;
  storyQuality: number;
  creativity: number;
  artifactScore: number;
  overall: number;
}

export interface VideoCandidate {
  id: string;
  provider: string;
  model: string;
  assetId?: string;
  durationMs: number;
  prompt: string;
  quality?: VideoGenerationQuality;
  status: VideoCandidateStatus;
}

export interface VideoGenerationJobV4 {
  id: string;
  requestId: string;
  status: VideoJobStatus;
  progress: number;
  candidates: VideoCandidate[];
  selectedCandidateId?: string;
  error?: string;
  createdAt: string;
  completedAt?: string;
}

export interface CreativeDirectiveV4 {
  coreIdea: string;
  emotionalGoal: string;
  narrativeGoal: string;
  visualGoal: string;
  motionGoal: string;
  cameraGoal: string;
  audioGoal: string;
  continuityRequirements: string[];
  prohibitedChanges: string[];
  qualityTargets: string[];
}

const QUALITY_KEYS: (keyof Omit<VideoGenerationQuality, "overall">)[] = [
  "promptAlignment", "characterConsistency", "worldConsistency", "temporalConsistency", "motionQuality", "cameraQuality", "composition", "visualQuality", "audioQuality", "storyQuality", "creativity", "artifactScore",
];

const clampUnit = (value: unknown) => typeof value === "number" && Number.isFinite(value) ? Math.min(1, Math.max(0, value)) : 0;
const cleanList = (values: unknown) => Array.from(new Set(Array.isArray(values) ? values.filter((value): value is string => typeof value === "string").map((value) => value.trim()).filter(Boolean) : []));

export function clampVideoProgress(value: unknown): number { return clampUnit(value); }
export function clampVideoScore(value: unknown): number { return clampUnit(value); }

export function normalizeVideoGenerationRequest(request: VideoGenerationRequestV4): VideoGenerationRequestV4 {
  return {
    ...request,
    id: request.id.trim(),
    userId: request.userId.trim(),
    prompt: request.prompt.trim(),
    durationSeconds: Math.min(60, Math.max(1, Number.isFinite(request.durationSeconds) ? request.durationSeconds : 1)),
    characterIds: cleanList(request.characterIds),
    referenceAssetIds: cleanList(request.referenceAssetIds),
    style: request.style?.trim() || undefined,
    language: request.language?.trim() || undefined,
    audio: Boolean(request.audio),
  };
}

export function normalizeVideoQuality(input?: Partial<VideoGenerationQuality>): VideoGenerationQuality {
  const quality = {} as VideoGenerationQuality;
  for (const key of QUALITY_KEYS) quality[key] = clampVideoScore(input?.[key]);
  quality.overall = clampVideoScore(input?.overall ?? QUALITY_KEYS.reduce((sum, key) => sum + quality[key], 0) / QUALITY_KEYS.length);
  return quality;
}

export function normalizeVideoCandidate(candidate: VideoCandidate): VideoCandidate {
  return { ...candidate, id: candidate.id.trim(), provider: candidate.provider.trim() || "unknown", model: candidate.model.trim() || "unknown", durationMs: Math.max(0, Number.isFinite(candidate.durationMs) ? candidate.durationMs : 0), prompt: candidate.prompt.trim(), quality: candidate.quality ? normalizeVideoQuality(candidate.quality) : undefined };
}

export function normalizeVideoJob(job: VideoGenerationJobV4): VideoGenerationJobV4 {
  const candidates = job.candidates.map(normalizeVideoCandidate);
  const selectedCandidateId = job.selectedCandidateId && candidates.some((candidate) => candidate.id === job.selectedCandidateId) ? job.selectedCandidateId : undefined;
  return { ...job, id: job.id.trim(), requestId: job.requestId.trim(), progress: clampVideoProgress(job.progress), candidates, selectedCandidateId, error: job.error?.trim() || undefined };
}

export function buildVideoGenerationTaskGraph(request: VideoGenerationRequestV4): AITaskGraph {
  const normalized = normalizeVideoGenerationRequest(request);
  const definitions: Pick<AITaskNode, "id" | "type" | "description" | "dependencies">[] = [
    { id: "understand", type: "understand", description: "Understand generation intent and constraints", dependencies: [] },
    { id: "context", type: "retrieve", description: "Retrieve story, character, and world continuity", dependencies: ["understand"] },
    { id: "direct", type: "plan", description: "Create a creative and visual directive", dependencies: ["context"] },
    { id: "shots", type: "plan", description: "Plan shots, camera, motion, and audio", dependencies: ["direct"] },
    { id: "generate", type: "generate", description: `Generate ${normalized.intent} candidates`, dependencies: ["shots"] },
    { id: "evaluate", type: "evaluate", description: "Evaluate temporal, visual, story, and continuity quality", dependencies: ["generate"] },
    { id: "repair", type: "repair", description: "Repair only candidates that fail quality gates", dependencies: ["evaluate"] },
    { id: "remember", type: "remember", description: "Persist the selected candidate and continuity signals", dependencies: ["repair"] },
  ];
  return { id: normalized.id || `video-v4-${Date.now()}`, rootTask: "understand", createdAt: new Date().toISOString(), nodes: definitions.map((node) => ({ ...node, status: "pending" })) };
}

export function selectBestVideoCandidate(candidates: VideoCandidate[]): VideoCandidate | undefined {
  return candidates.filter((candidate) => candidate.status === "ready" && candidate.quality).sort((a, b) => (b.quality?.overall ?? 0) - (a.quality?.overall ?? 0))[0];
}
