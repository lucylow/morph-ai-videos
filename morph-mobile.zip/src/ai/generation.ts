export type GenerationType = "image" | "video" | "voice" | "music";
export type GenerationStatus = "created" | "queued" | "preparing" | "generating" | "evaluating" | "repairing" | "completed" | "failed" | "cancelled";
export type GenerationStage = "queue" | "context" | "prompt" | "provider" | "render" | "evaluate" | "repair" | "complete";

export interface GenerationRequest { id: string; userId: string; type: GenerationType; prompt: string; characterId?: string; worldId?: string; storyId?: string; referenceAssetIds: string[]; durationSeconds?: number; }
export interface GenerationJob { id: string; requestId: string; userId: string; status: GenerationStatus; progress: number; stage: GenerationStage; attempt: number; maxAttempts: number; createdAt: string; error?: { code: string; message: string; retryable: boolean }; }

export function normalizeGenerationRequest(request: GenerationRequest): GenerationRequest { return { ...request, prompt: request.prompt.trim(), referenceAssetIds: Array.from(new Set(request.referenceAssetIds.filter(Boolean))) }; }
export function clampProgress(progress: number): number { return Math.min(1, Math.max(0, Number.isFinite(progress) ? progress : 0)); }

const allowedTransitions: Record<GenerationStatus, GenerationStatus[]> = { created: ["queued", "cancelled"], queued: ["preparing", "cancelled"], preparing: ["generating", "failed"], generating: ["evaluating", "failed", "cancelled"], evaluating: ["completed", "repairing", "failed"], repairing: ["generating", "failed"], completed: [], failed: ["queued"], cancelled: [] };
export function canTransition(current: GenerationStatus, next: GenerationStatus): boolean { return allowedTransitions[current]?.includes(next) ?? false; }
export function transitionGeneration(current: GenerationStatus, next: GenerationStatus): GenerationStatus { if (!canTransition(current, next)) throw new Error(`Invalid generation transition: ${current} -> ${next}`); return next; }
export function retryableGenerationError(code: string, message: string): GenerationJob["error"] { return { code, message: message || "Generation failed. Please try again.", retryable: code !== "policy_blocked" && code !== "cancelled" }; }
