export type AIIntent =
  | "create_character"
  | "animate_character"
  | "create_story"
  | "continue_story"
  | "create_world"
  | "remix"
  | "generate_image"
  | "generate_video"
  | "generate_voice"
  | "generate_music";

export type MemoryType = "identity" | "fact" | "preference" | "relationship" | "event" | "style" | "story";

export interface MultimodalInput {
  text?: string;
  images?: { assetId: string; url: string; purpose: "character_reference" | "style_reference" | "scene_reference" | "background" }[];
  audio?: { assetId: string; url: string; purpose: "voice_reference" | "sound_reference" }[];
  video?: { assetId: string; url: string; purpose: "motion_reference" | "style_reference" | "scene_reference" }[];
}

export interface AIContext {
  characterIds?: string[];
  worldIds?: string[];
  storyId?: string;
  episodeId?: string;
  memoryIds?: string[];
  preferredStyle?: string;
  locale?: string;
}

export interface AIRequest {
  requestId: string;
  userId: string;
  intent: AIIntent;
  input: MultimodalInput;
  context?: AIContext;
}

export interface AIResponse<T = unknown> {
  requestId: string;
  success: boolean;
  data?: T;
  error?: { code: string; message: string; retryable: boolean };
  metadata: { provider?: string; model?: string; latencyMs: number; estimatedCost?: number };
}

export interface AIMemory {
  id: string;
  ownerId: string;
  scopeId: string;
  type: MemoryType;
  key: string;
  value: string;
  confidence: number;
  importance: number;
  lastUsedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RetrievedMemory { memory: AIMemory; similarity: number; score?: number }
export interface VisualEvaluation { qualityScore: number; consistencyScore: number; safetyScore: number; issues: string[]; shouldRepair: boolean }
export type GenerationStage = "understanding" | "memory_retrieval" | "directing" | "planning" | "routing" | "generating" | "evaluating" | "repairing" | "complete";

export function calculateMemoryImportance(memory: Pick<AIMemory, "confidence" | "importance">) {
  return memory.confidence * 0.65 + memory.importance * 0.35;
}

export function rerankMemories(memories: RetrievedMemory[]) {
  return memories.map((item) => ({ ...item, score: item.similarity * 0.65 + item.memory.confidence * 0.2 + item.memory.importance * 0.15 })).sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
}

export function buildMemoryContext(memories: RetrievedMemory[]) {
  return memories.map(({ memory }) => `[${memory.type}] ${memory.key}: ${memory.value}`).join("\n");
}

export function shouldAskForClarification(prediction: { intent: AIIntent; confidence: number }) {
  return prediction.confidence < 0.62;
}


export interface MemoryExtraction {
  type: MemoryType;
  key: string;
  value: string;
  confidence: number;
}

export function dedupeMemories(memories: MemoryExtraction[]) {
  const map = new Map<string, MemoryExtraction>();
  for (const memory of memories) map.set(`${memory.type}:${memory.key}`, memory);
  return [...map.values()];
}

export function memoryDecay(memory: AIMemory, now = Date.now()) {
  const ageDays = Math.max(0, (now - new Date(memory.updatedAt).getTime()) / 86_400_000);
  return Math.max(0.1, memory.confidence * Math.exp(-ageDays / 365));
}

export function retrieveRelevantMemory(memories: RetrievedMemory[], limit = 12) {
  return rerankMemories(memories).slice(0, Math.max(1, limit));
}

export interface AIPipelineState {
  requestId: string;
  stage: GenerationStage;
  completedStages: GenerationStage[];
  retryCount: number;
  status: "idle" | "running" | "repairing" | "completed" | "failed" | "cancelled";
  error?: { code: string; message: string; retryable: boolean };
}

export interface PersonalizationSignal {
  kind: "style_preference" | "world_affinity" | "story_choice" | "remix_action";
  value: string;
  weight: number;
  observedAt: string;
}

export function nextPipelineState(state: AIPipelineState, stage: GenerationStage): AIPipelineState {
  const completedStages = state.completedStages.includes(stage) ? state.completedStages : [...state.completedStages, stage];
  return { ...state, stage, completedStages, status: stage === "complete" ? "completed" : state.status === "idle" ? "running" : state.status };
}

export function canRetryPipeline(state: AIPipelineState, maxRetries = 2) {
  return state.status === "failed" && state.retryCount < maxRetries && Boolean(state.error?.retryable);
}
