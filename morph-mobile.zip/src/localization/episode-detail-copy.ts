import type { LanguageCode } from "@/src/localization/i18n";

export interface EpisodeDetailCopy {
  back: string;
  loading: string;
  preview: string;
  previewLoading: string;
  previewError: string;
  retryPreview: string;
  resumeFrom: (time: string) => string;
  startOver: string;
  startOverHint: string;
  progressLabel: (percent: number) => string;
  remainingLabel: (time: string) => string;
  previewUnavailable: string;
  episodeLabel: string;
  synopsisLabel: string;
  worldLabel: string;
  characterLabel: string;
  continue: string;
  remix: string;
  missingTitle: string;
  missingBody: string;
  retry: string;
  loadError: string;
  backHint: string;
  continueHint: string;
  remixHint: string;
}

const copy: Record<"en" | "fr" | "es" | "ar", EpisodeDetailCopy> = {
  en: { back: "Back", loading: "Opening saved episode…", preview: "PREVIEW", previewLoading: "Loading preview…", previewError: "This preview could not be played. Try again later.", retryPreview: "Retry preview", resumeFrom: (time) => `Resume from ${time}`, startOver: "Start over", startOverHint: "Restarts this episode from the beginning", progressLabel: (percent) => `${percent}% watched`, remainingLabel: (time) => `${time} remaining`, previewUnavailable: "A media preview will appear when this episode has a playable scene.", episodeLabel: "EPISODE", synopsisLabel: "SYNOPSIS", worldLabel: "WORLD", characterLabel: "CHARACTER", continue: "Continue story", remix: "Remix episode", missingTitle: "This episode moved", missingBody: "We couldn’t find this saved episode. Return to Stories to choose another chapter.", retry: "Try again", loadError: "Saved episode details are temporarily unavailable.", backHint: "Returns to your saved stories", continueHint: "Continues this episode in the creation studio", remixHint: "Starts a new creation inspired by this episode" },
  fr: { back: "Retour", loading: "Ouverture de l’épisode enregistré…", preview: "APERÇU", previewLoading: "Chargement de l’aperçu…", previewError: "Cet aperçu ne peut pas être lu. Réessayez plus tard.", retryPreview: "Réessayer l’aperçu", resumeFrom: (time) => `Reprendre à ${time}`, startOver: "Recommencer", startOverHint: "Redémarre cet épisode depuis le début", progressLabel: (percent) => `${percent} % regardé`, remainingLabel: (time) => `${time} restantes`, previewUnavailable: "Un aperçu média apparaîtra lorsque cet épisode aura une scène lisible.", episodeLabel: "ÉPISODE", synopsisLabel: "SYNOPSIS", worldLabel: "MONDE", characterLabel: "PERSONNAGE", continue: "Continuer l’histoire", remix: "Remixer l’épisode", missingTitle: "Cet épisode a bougé", missingBody: "Impossible de trouver cet épisode enregistré. Retournez aux histoires pour choisir un autre chapitre.", retry: "Réessayer", loadError: "Les détails de l’épisode enregistré sont temporairement indisponibles.", backHint: "Retourne à vos histoires enregistrées", continueHint: "Continue cet épisode dans le studio de création", remixHint: "Commence une création inspirée de cet épisode" },
  es: { back: "Volver", loading: "Abriendo el episodio guardado…", preview: "VISTA PREVIA", previewLoading: "Cargando vista previa…", previewError: "No se pudo reproducir esta vista previa. Inténtalo más tarde.", retryPreview: "Reintentar vista previa", resumeFrom: (time) => `Reanudar desde ${time}`, startOver: "Empezar de nuevo", startOverHint: "Reinicia este episodio desde el principio", progressLabel: (percent) => `${percent}% visto`, remainingLabel: (time) => `${time} restantes`, previewUnavailable: "La vista previa aparecerá cuando este episodio tenga una escena reproducible.", episodeLabel: "EPISODIO", synopsisLabel: "SINOPSIS", worldLabel: "MUNDO", characterLabel: "PERSONAJE", continue: "Continuar historia", remix: "Remezclar episodio", missingTitle: "Este episodio cambió de lugar", missingBody: "No encontramos este episodio guardado. Vuelve a Historias para elegir otro capítulo.", retry: "Intentar de nuevo", loadError: "Los detalles del episodio guardado no están disponibles temporalmente.", backHint: "Vuelve a tus historias guardadas", continueHint: "Continúa este episodio en el estudio de creación", remixHint: "Inicia una creación inspirada en este episodio" },
  ar: { back: "رجوع", loading: "جارٍ فتح الحلقة المحفوظة…", preview: "المعاينة", previewLoading: "جارٍ تحميل المعاينة…", previewError: "تعذر تشغيل هذه المعاينة. حاول مرة أخرى لاحقًا.", retryPreview: "إعادة محاولة المعاينة", resumeFrom: (time) => `استئناف من ${time}`, startOver: "البدء من جديد", startOverHint: "يعيد تشغيل هذه الحلقة من البداية", progressLabel: (percent) => `تمت مشاهدة ${percent}٪`, remainingLabel: (time) => `${time} متبقية`, previewUnavailable: "ستظهر معاينة الوسائط عندما تحتوي هذه الحلقة على مشهد قابل للتشغيل.", episodeLabel: "الحلقة", synopsisLabel: "الملخص", worldLabel: "العالم", characterLabel: "الشخصية", continue: "متابعة القصة", remix: "إعادة مزج الحلقة", missingTitle: "انتقلت هذه الحلقة", missingBody: "تعذر العثور على هذه الحلقة المحفوظة. عد إلى القصص لاختيار فصل آخر.", retry: "حاول مرة أخرى", loadError: "تفاصيل الحلقة المحفوظة غير متاحة مؤقتًا.", backHint: "يعود إلى قصصك المحفوظة", continueHint: "يتابع هذه الحلقة في استوديو الإنشاء", remixHint: "يبدأ إنشاءً جديدًا مستوحى من هذه الحلقة" },
};

export function getEpisodeDetailCopy(language: LanguageCode): EpisodeDetailCopy {
  return copy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
