import AsyncStorage from "@react-native-async-storage/async-storage";

import { getLocaleProfile, LANGUAGES, resolveLanguage, type LanguageCode } from "./i18n";
import { withStorageRetry } from "../storage/morph-repository";

const LANGUAGE_KEY = "morph.language.preference.v1";
const listeners = new Set<(preference: LanguagePreference) => void>();
export interface LanguagePreference { interfaceLanguage: LanguageCode; contentLanguage: LanguageCode; autoTranslateAI: boolean; translateCaptions: boolean; }
export const defaultLanguagePreference: LanguagePreference = { interfaceLanguage: "en", contentLanguage: "en", autoTranslateAI: true, translateCaptions: true };
export function normalizeLanguagePreference(value: Partial<LanguagePreference> | null | undefined): LanguagePreference { return { interfaceLanguage: resolveLanguage(value?.interfaceLanguage), contentLanguage: resolveLanguage(value?.contentLanguage), autoTranslateAI: value?.autoTranslateAI !== false, translateCaptions: value?.translateCaptions !== false }; }
export async function loadLanguagePreference(): Promise<LanguagePreference> { try { const raw = await AsyncStorage.getItem(LANGUAGE_KEY); return normalizeLanguagePreference(raw ? JSON.parse(raw) : undefined); } catch { return defaultLanguagePreference; } }
export function subscribeLanguagePreference(listener: (preference: LanguagePreference) => void) { listeners.add(listener); return () => listeners.delete(listener); }
function notifyLanguagePreferenceListeners(normalized: LanguagePreference) { listeners.forEach((listener) => { try { listener(normalized); } catch (error) { if (typeof __DEV__ !== "undefined" && __DEV__) console.warn("MORPH language listener failed", error instanceof Error ? error.message : String(error)); } }); }
export async function saveLanguagePreference(value: Partial<LanguagePreference>): Promise<LanguagePreference> { const normalized = normalizeLanguagePreference(value); await withStorageRetry(() => AsyncStorage.setItem(LANGUAGE_KEY, JSON.stringify(normalized))); notifyLanguagePreferenceListeners(normalized); return normalized; }
export function localizedShellLabels(language: LanguageCode) { const labels: Partial<Record<LanguageCode, { home: string; create: string; worlds: string; stories: string; profile: string }>> = { fr: { home: "Accueil", create: "Créer", worlds: "Mondes", stories: "Histoires", profile: "Profil" }, es: { home: "Inicio", create: "Crear", worlds: "Mundos", stories: "Historias", profile: "Perfil" }, ar: { home: "الرئيسية", create: "إنشاء", worlds: "عوالم", stories: "قصص", profile: "الملف الشخصي" }, ja: { home: "ホーム", create: "作成", worlds: "世界", stories: "ストーリー", profile: "プロフィール" } }; return labels[language] ?? { home: "Home", create: "Create", worlds: "Worlds", stories: "Stories", profile: "Profile" }; }
export function getLanguagePresentation(language: LanguageCode) { const definition = LANGUAGES[language] ?? LANGUAGES.en; const locale = getLocaleProfile(definition.code); return { code: definition.code, nativeName: definition.nativeName, direction: locale.direction, script: definition.code === "ar" ? "Arab" : definition.code === "ja" ? "Jpan" : "Latn" }; }
