import type { LanguageCode } from "./i18n";

export interface CharactersCopy {
  kicker: string;
  title: string;
  subtitle: string;
  create: string;
  loading: string;
  error: string;
  retry: string;
  empty: string;
  unwritten: string;
}

const charactersCopy: Record<"en" | "fr" | "es" | "ar", CharactersCopy> = {
  en: {
    kicker: "CHARACTER VAULT",
    title: "People worth\nwriting about.",
    subtitle: "Your recurring cast, ready for another episode.",
    create: "Create a new character",
    loading: "Opening your vault…",
    error: "Your character vault could not be opened.",
    retry: "Try again",
    empty: "No characters yet. Start with someone only you could imagine.",
    unwritten: "Unwritten",
  },
  fr: {
    kicker: "GALERIE DE PERSONNAGES",
    title: "Des personnages qui méritent\nd’être écrits.",
    subtitle: "Votre distribution récurrente, prête pour un nouvel épisode.",
    create: "Créer un personnage",
    loading: "Ouverture de votre galerie…",
    error: "Votre galerie de personnages est indisponible.",
    retry: "Réessayer",
    empty: "Aucun personnage pour le moment. Imaginez quelqu’un que vous seul pourriez créer.",
    unwritten: "À écrire",
  },
  es: {
    kicker: "GALERÍA DE PERSONAJES",
    title: "Personajes que merecen\nuna historia.",
    subtitle: "Tu elenco recurrente, listo para otro episodio.",
    create: "Crear personaje",
    loading: "Abriendo tu galería…",
    error: "No se pudo abrir tu galería de personajes.",
    retry: "Reintentar",
    empty: "Aún no tienes personajes. Empieza con alguien que solo tú podrías imaginar.",
    unwritten: "Sin definir",
  },
  ar: { kicker: "خزينة الشخصيات", title: "شخصيات تستحق\nأن نكتب عنها.", subtitle: "طاقمك المتكرر، جاهز لحلقة جديدة.", create: "إنشاء شخصية", loading: "جارٍ فتح خزانتك…", error: "تعذر فتح خزينة الشخصيات.", retry: "حاول مرة أخرى", empty: "لا توجد شخصيات بعد. ابدأ بشخص لا يمكنك تخيله إلا بطريقتك.", unwritten: "غير مكتمل" },
};

export interface StoriesCopy {
  offlineError: string;
  refreshError: string;
  retryHint: string;
  loading: string;
  loaded: string;
  mapHint: string;
  continueHint: string;
  resumeFrom: (time: string) => string;
  progressLabel: (percent: number) => string;
  remainingLabel: (time: string) => string;
  resumeAction: string;
  startOverAction: string;
  startOverHint: string;
  resetNotice: string;
  undoAction: string;
  undoHint: string;
  persistenceError: string;
  persistenceTimedOut: string;
  persistenceCancelled: string;
  retryPersistence: string;
  retryPersistenceHint: string;
  offlinePersistence: string;
  reconnectingPersistence: string;
  retryingPersistence: string;
  cancelRetry: string;
  cancelRetryHint: string;
  retryCancelled: string;
  resumeRetry: string;
  resumeRetryHint: string;
  retryExpired: string;
  restoredRecoveryFor: (title: string) => string;
  persistenceSaved: string;
  retrySaved: string;
  dismissRecovery: string;
}

const storiesCopy: Record<"en" | "fr" | "es" | "ar", StoriesCopy> = {
  en: { offlineError: "Saved episodes are temporarily unavailable. Showing your offline catalog.", refreshError: "Saved episodes could not be refreshed. Try again.", retryHint: "Reloads your saved episodes", loading: "Refreshing saved episodes…", loaded: "Saved episodes refreshed.", mapHint: "Opens the branching story map", continueHint: "Continues this story in the creation studio", resumeFrom: (time) => `Resume from ${time}`, progressLabel: (percent) => `${percent}% watched`, remainingLabel: (time) => `${time} remaining`, resumeAction: "Resume episode", startOverAction: "Start over", startOverHint: "Clears saved playback and starts this episode from the beginning", resetNotice: "Playback reset", undoAction: "Undo", undoHint: "Restores the previous playback position", persistenceError: "Playback changes could not be saved. Try again.", persistenceTimedOut: "Saving took too long. Try again when you’re ready.", persistenceCancelled: "Saving was cancelled. Your playback position is still here.", retryPersistence: "Retry save", retryPersistenceHint: "Attempts to save the playback change again", offlinePersistence: "You’re offline. Reconnect before retrying the playback save.", reconnectingPersistence: "Connection restored. Retrying playback save…", retryingPersistence: "Retrying playback save…", cancelRetry: "Cancel retry", cancelRetryHint: "Stops the pending playback save retry", retryCancelled: "Playback save retry cancelled.", resumeRetry: "Resume retry", resumeRetryHint: "Restores the pending playback save retry", retryExpired: "The cancelled playback save retry has expired.", restoredRecoveryFor: (title) => `Pending playback save restored for ${title}.`, persistenceSaved: "Playback saved.", retrySaved: "Playback save recovered.", dismissRecovery: "Dismiss" },
  fr: { offlineError: "Vos épisodes enregistrés sont temporairement indisponibles. Voici votre catalogue hors ligne.", refreshError: "Vos épisodes enregistrés n’ont pas pu être actualisés. Réessayez.", retryHint: "Recharge vos épisodes enregistrés", loading: "Actualisation des épisodes enregistrés…", loaded: "Épisodes enregistrés actualisés.", mapHint: "Ouvre la carte des embranchements", continueHint: "Continue cette histoire dans le studio de création", resumeFrom: (time) => `Reprendre à ${time}`, progressLabel: (percent) => `${percent} % regardé`, remainingLabel: (time) => `${time} restantes`, resumeAction: "Reprendre l’épisode", startOverAction: "Recommencer", startOverHint: "Efface la progression et redémarre cet épisode depuis le début", resetNotice: "Progression réinitialisée", undoAction: "Annuler", undoHint: "Restaure la position de lecture précédente", persistenceError: "Les changements de lecture n’ont pas pu être enregistrés. Réessayez.", persistenceTimedOut: "L’enregistrement a pris trop de temps. Réessayez quand vous êtes prêt.", persistenceCancelled: "L’enregistrement a été annulé. Votre position de lecture est toujours là.", retryPersistence: "Réessayer", retryPersistenceHint: "Tente à nouveau d’enregistrer le changement de lecture", offlinePersistence: "Vous êtes hors ligne. Reconnectez-vous avant de réessayer l’enregistrement.", reconnectingPersistence: "Connexion rétablie. Nouvelle tentative d’enregistrement…", retryingPersistence: "Nouvelle tentative d’enregistrement…", cancelRetry: "Annuler", cancelRetryHint: "Arrête la nouvelle tentative d’enregistrement", retryCancelled: "Nouvelle tentative d’enregistrement annulée.", resumeRetry: "Reprendre", resumeRetryHint: "Restaure la nouvelle tentative d’enregistrement", retryExpired: "La nouvelle tentative d’enregistrement annulée a expiré.", restoredRecoveryFor: (title) => `Une sauvegarde de lecture en attente a été restaurée pour ${title}.`, persistenceSaved: "Lecture enregistrée.", retrySaved: "Sauvegarde de lecture récupérée.", dismissRecovery: "Fermer" },
  es: { offlineError: "Tus episodios guardados no están disponibles temporalmente. Mostramos tu catálogo sin conexión.", refreshError: "No se pudieron actualizar tus episodios guardados. Inténtalo de nuevo.", retryHint: "Vuelve a cargar tus episodios guardados", loading: "Actualizando los episodios guardados…", loaded: "Episodios guardados actualizados.", mapHint: "Abre el mapa de historias ramificadas", continueHint: "Continúa esta historia en el estudio de creación", resumeFrom: (time) => `Reanudar desde ${time}`, progressLabel: (percent) => `${percent}% visto`, remainingLabel: (time) => `${time} restantes`, resumeAction: "Reanudar episodio", startOverAction: "Empezar de nuevo", startOverHint: "Borra el progreso guardado y reinicia este episodio desde el principio", resetNotice: "Progreso reiniciado", undoAction: "Deshacer", undoHint: "Restaura la posición de reproducción anterior", persistenceError: "No se pudieron guardar los cambios de reproducción. Inténtalo de nuevo.", persistenceTimedOut: "El guardado tardó demasiado. Inténtalo de nuevo cuando quieras.", persistenceCancelled: "El guardado se canceló. Tu posición de reproducción sigue aquí.", retryPersistence: "Reintentar", retryPersistenceHint: "Intenta guardar de nuevo el cambio de reproducción", offlinePersistence: "Estás sin conexión. Reconéctate antes de reintentar el guardado.", reconnectingPersistence: "Conexión restablecida. Reintentando el guardado…", retryingPersistence: "Reintentando el guardado…", cancelRetry: "Cancelar", cancelRetryHint: "Detiene el reintento de guardado", retryCancelled: "Reintento de guardado cancelado.", resumeRetry: "Reanudar", resumeRetryHint: "Restaura el reintento de guardado pendiente", retryExpired: "El reintento de guardado cancelado ha caducado.", restoredRecoveryFor: (title) => `Se restauró un guardado de reproducción pendiente para ${title}.`, persistenceSaved: "Reproducción guardada.", retrySaved: "Guardado de reproducción recuperado.", dismissRecovery: "Cerrar" },
  ar: { offlineError: "الحلقات المحفوظة غير متاحة مؤقتًا. نعرض الكتالوج المتاح دون اتصال.", refreshError: "تعذر تحديث الحلقات المحفوظة. حاول مرة أخرى.", retryHint: "يعيد تحميل حلقاتك المحفوظة", loading: "جارٍ تحديث الحلقات المحفوظة…", loaded: "تم تحديث الحلقات المحفوظة.", mapHint: "يفتح خريطة القصة المتفرعة", continueHint: "يتابع هذه القصة في استوديو الإنشاء", resumeFrom: (time) => `استئناف من ${time}`, progressLabel: (percent) => `تمت مشاهدة ${percent}٪`, remainingLabel: (time) => `${time} متبقية`, resumeAction: "استئناف الحلقة", startOverAction: "البدء من جديد", startOverHint: "يمسح التقدم المحفوظ ويعيد تشغيل الحلقة من البداية", resetNotice: "تمت إعادة ضبط التشغيل", undoAction: "تراجع", undoHint: "يستعيد موضع التشغيل السابق", persistenceError: "تعذر حفظ تغييرات التشغيل. حاول مرة أخرى.", persistenceTimedOut: "استغرق الحفظ وقتًا طويلاً. حاول مرة أخرى عندما تكون مستعدًا.", persistenceCancelled: "تم إلغاء الحفظ. ما زال موضع التشغيل محفوظًا هنا.", retryPersistence: "إعادة المحاولة", retryPersistenceHint: "يحاول حفظ تغيير التشغيل مرة أخرى", offlinePersistence: "أنت غير متصل. أعد الاتصال قبل إعادة محاولة حفظ التشغيل.", reconnectingPersistence: "تم استعادة الاتصال. جارٍ إعادة محاولة حفظ التشغيل…", retryingPersistence: "جارٍ إعادة محاولة حفظ التشغيل…", cancelRetry: "إلغاء المحاولة", cancelRetryHint: "يوقف محاولة حفظ التشغيل المعلقة", retryCancelled: "تم إلغاء محاولة حفظ التشغيل.", resumeRetry: "استئناف المحاولة", resumeRetryHint: "يستعيد محاولة حفظ التشغيل المعلقة", retryExpired: "انتهت صلاحية محاولة حفظ التشغيل الملغاة.", restoredRecoveryFor: (title) => `تمت استعادة عملية حفظ تشغيل معلقة لـ ${title}.`, persistenceSaved: "تم حفظ التشغيل.", retrySaved: "تم استرداد حفظ التشغيل.", dismissRecovery: "إغلاق" },
};

export interface StoryMapCopy {
  kicker: string;
  title: string;
  subtitle: string;
  loading: string;
  error: string;
  retry: string;
  current: string;
  saved: string;
  open: string;
  ready: string;
  completed: string;
  progress: (completed: number, total: number) => string;
  first: string;
  back: string;
  backHint: string;
  retryHint: string;
  continueHint: string;
}

const storyMapCopy: Record<"en" | "fr" | "es" | "ar", StoryMapCopy> = {
  en: {
    kicker: "STORY MAP",
    title: "Choose where\nthe story goes.",
    subtitle: "Every choice leaves a thread behind. You can always return to the path.",
    loading: "Reconnecting to your story…",
    error: "Your story map could not be opened.",
    retry: "Try again",
    current: "CURRENT PATH",
    saved: "SAVED EPISODES",
    open: "OPEN THREADS",
    ready: "Ready to continue",
    completed: "Completed",
    progress: (completed, total) => `${completed} of ${total} nodes completed`,
    first: "Your first completed episode will appear here as your path grows.",
    back: "Back",
    backHint: "Returns to the previous screen",
    retryHint: "Reloads your story map",
    continueHint: "Continues this story thread in the creation studio",
  },
  fr: {
    kicker: "CARTE DE L’HISTOIRE",
    title: "Choisissez la suite\nde l’histoire.",
    subtitle: "Chaque choix laisse une piste. Vous pouvez toujours revenir au chemin.",
    loading: "Reconnexion à votre histoire…",
    error: "Votre carte de l’histoire est indisponible.",
    retry: "Réessayer",
    current: "CHEMIN ACTUEL",
    saved: "ÉPISODES SAUVEGARDÉS",
    open: "FILS OUVERTS",
    ready: "Prêt à continuer",
    completed: "Terminé",
    progress: (completed, total) => `${completed} nœuds sur ${total} terminés`,
    first: "Votre premier épisode terminé apparaîtra ici au fil de votre histoire.",
    back: "Retour",
    backHint: "Retourne à l’écran précédent",
    retryHint: "Recharge votre carte de l’histoire",
    continueHint: "Continue ce fil narratif dans le studio de création",
  },
  es: {
    kicker: "MAPA DE HISTORIA",
    title: "Elige hacia dónde\nva la historia.",
    subtitle: "Cada elección deja un hilo. Siempre puedes volver al camino.",
    loading: "Reconectando con tu historia…",
    error: "No se pudo abrir tu mapa de historia.",
    retry: "Reintentar",
    current: "CAMINO ACTUAL",
    saved: "EPISODIOS GUARDADOS",
    open: "HILOS ABIERTOS",
    ready: "Listo para continuar",
    completed: "Completado",
    progress: (completed, total) => `${completed} de ${total} nodos completados`,
    first: "Tu primer episodio completado aparecerá aquí mientras crece tu historia.",
    back: "Volver",
    backHint: "Vuelve a la pantalla anterior",
    retryHint: "Vuelve a cargar tu mapa de historia",
    continueHint: "Continúa este hilo en el estudio de creación",
  },
  ar: { kicker: "خريطة القصة", title: "اختر إلى أين\nتتجه القصة.", subtitle: "كل اختيار يترك خيطًا. يمكنك دائمًا العودة إلى المسار.", loading: "جارٍ الاتصال بقصتك…", error: "تعذر فتح خريطة قصتك.", retry: "حاول مرة أخرى", current: "المسار الحالي", saved: "الحلقات المحفوظة", open: "الخيوط المفتوحة", ready: "جاهز للمتابعة", completed: "مكتملة", progress: (completed, total) => `اكتمل ${completed} من أصل ${total} عقد`, first: "ستظهر أول حلقة مكتملة هنا مع نمو مسارك.", back: "رجوع", backHint: "يعود إلى الشاشة السابقة", retryHint: "يعيد تحميل خريطة قصتك", continueHint: "يتابع خيط القصة في استوديو الإنشاء" },
};

export interface ProfileCopy {
  kicker: string;
  episodes: string;
  characters: string;
  remixes: string;
  language: string;
  languageDescription: string;
  saving: string;
  saved: string;
  sessionSaved: string;
  stories: string;
  vault: string;
  morphPlus: string;
  morphPlusDescription: string;
}

const profileCopy: Record<"en" | "fr" | "es" | "ar", ProfileCopy> = {
  en: { kicker: "CREATOR PROFILE", episodes: "EPISODES", characters: "CHARACTERS", remixes: "REMIXES", language: "LANGUAGE", languageDescription: "Choose the language MORPH uses for your interface and new story prompts.", saving: "Saving…", saved: "Language preference saved", sessionSaved: "Language saved for this session", stories: "Open published stories", vault: "Character vault", morphPlus: "MORPH+", morphPlusDescription: "Unlock longer stories and advanced character memory." },
  fr: { kicker: "PROFIL CRÉATEUR", episodes: "ÉPISODES", characters: "PERSONNAGES", remixes: "REMIXES", language: "LANGUE", languageDescription: "Choisissez la langue utilisée par MORPH pour votre interface et vos nouveaux prompts.", saving: "Enregistrement…", saved: "Préférence de langue enregistrée", sessionSaved: "Langue enregistrée pour cette session", stories: "Ouvrir les histoires publiées", vault: "Galerie de personnages", morphPlus: "MORPH+", morphPlusDescription: "Débloquez des histoires plus longues et une mémoire avancée pour vos personnages." },
  es: { kicker: "PERFIL DE CREADOR", episodes: "EPISODIOS", characters: "PERSONAJES", remixes: "REMIXES", language: "IDIOMA", languageDescription: "Elige el idioma que MORPH usa para tu interfaz y tus nuevos prompts de historia.", saving: "Guardando…", saved: "Preferencia de idioma guardada", sessionSaved: "Idioma guardado para esta sesión", stories: "Abrir historias publicadas", vault: "Galería de personajes", morphPlus: "MORPH+", morphPlusDescription: "Desbloquea historias más largas y memoria avanzada para tus personajes." },
  ar: { kicker: "ملف المبدع", episodes: "الحلقات", characters: "الشخصيات", remixes: "إعادات المزج", language: "اللغة", languageDescription: "اختر اللغة التي يستخدمها MORPH لواجهة التطبيق ومطالبات القصص الجديدة.", saving: "جارٍ الحفظ…", saved: "تم حفظ تفضيل اللغة", sessionSaved: "تم حفظ اللغة لهذه الجلسة", stories: "فتح القصص المنشورة", vault: "خزينة الشخصيات", morphPlus: "MORPH+", morphPlusDescription: "افتح قصصًا أطول وذاكرة متقدمة للشخصيات." },
};

export interface WorldsCopy {
  kicker: string;
  title: string;
  subtitle: string;
  back: string;
  openWorld: string;
}

const worldsCopy: Record<"en" | "fr" | "es" | "ar", WorldsCopy> = {
  en: { kicker: "DISCOVER", title: "Find a world\nworth getting lost in.", subtitle: "Every world has a story waiting for your character.", back: "Back", openWorld: "Opens character creation in this world" },
  fr: { kicker: "DÉCOUVRIR", title: "Trouvez un monde\noù vous perdre.", subtitle: "Chaque monde cache une histoire pour votre personnage.", back: "Retour", openWorld: "Ouvre la création de personnage dans ce monde" },
  es: { kicker: "DESCUBRE", title: "Encuentra un mundo\ndonde perderte.", subtitle: "Cada mundo tiene una historia para tu personaje.", back: "Volver", openWorld: "Abre la creación de personaje en este mundo" },
  ar: { kicker: "اكتشف", title: "اعثر على عالم\nيستحق أن تضيع فيه.", subtitle: "كل عالم يحمل قصة تنتظر شخصيتك.", back: "رجوع", openWorld: "يفتح إنشاء شخصية في هذا العالم" },
};

export interface CreateCopy {
  title: string; subtitle: string; recovered: string; discard: string; note: string; surprise: string; generate: string; building: string;
  persisting: string; characterSaveFailed: string; episodeSaveFailed: string; savedCharacter: string; savedEpisode: string; pendingCharacter: string; pendingEpisode: string; savingCharacter: string; savingEpisode: string; savedAll: string; retrySave: string; retry: string; cancel: string; reference: string; ready: string; hero: string; library: string; camera: string; libraryHint: string; cameraHint: string; back: string; dismiss: string; optional: string; promptHint: string; premisePlaceholder: string; premiseKicker: string; failureTitle: string; failureCopy: string; requestTimedOut: string; requestCancelled: string; characterLabel: string; styleLabel: string; nextLabel: string; genreLabel: string; toneLabel: string; worldLabel: string;
}

const createCopy: Record<"en" | "fr" | "es" | "ar", CreateCopy> = {
  en: { title: "Put your character\nin a story.", subtitle: "Choose a direction. MORPH handles the rest.", recovered: "Unfinished scene recovered", discard: "Discard draft", note: "Director note", surprise: "Surprise me ↗", generate: "Generate episode", building: "Building your episode…", persisting: "Saving your story…", characterSaveFailed: "Your character could not be saved.", episodeSaveFailed: "Your episode could not be saved.", savedCharacter: "Character saved", savedEpisode: "Episode saved", pendingCharacter: "Character still needs saving", pendingEpisode: "Episode still needs saving", savingCharacter: "Saving character…", savingEpisode: "Saving episode…", savedAll: "Character and episode saved", retrySave: "Retry save", retry: "Retry generation ↗", cancel: "Cancel", reference: "Reference photo", ready: "Ready to morph", hero: "Your cinematic hero", library: "Library", camera: "Camera", libraryHint: "Open the photo library to choose a picture", cameraHint: "Open the camera to take a picture", back: "Back", dismiss: "Dismiss", optional: "OPTIONAL", promptHint: "Shape the premise", premisePlaceholder: "Make it unexpected…", premiseKicker: "YOUR EPISODE PREMISE", failureTitle: "The scene needs another take.", failureCopy: "MORPH couldn’t finish this generation. Your choices are saved.", requestTimedOut: "The request took too long. Try again when you’re ready.", requestCancelled: "The request was cancelled. Your choices are still here.", characterLabel: "CHARACTER", styleLabel: "VISUAL STYLE", nextLabel: "WHAT HAPPENS NEXT?", genreLabel: "GENRE", toneLabel: "TONE", worldLabel: "WORLD" },
  fr: { title: "Mettez votre personnage\ndans une histoire.", subtitle: "Choisissez une direction. MORPH s’occupe du reste.", recovered: "Scène inachevée récupérée", discard: "Supprimer le brouillon", note: "Note du réalisateur", surprise: "Surprenez-moi ↗", generate: "Générer l’épisode", building: "Construction de votre épisode…", persisting: "Enregistrement de votre histoire…", characterSaveFailed: "Votre personnage n’a pas pu être enregistré.", episodeSaveFailed: "Votre épisode n’a pas pu être enregistré.", savedCharacter: "Personnage enregistré", savedEpisode: "Épisode enregistré", pendingCharacter: "Personnage à enregistrer", pendingEpisode: "Épisode à enregistrer", savingCharacter: "Enregistrement du personnage…", savingEpisode: "Enregistrement de l’épisode…", savedAll: "Personnage et épisode enregistrés", retrySave: "Réessayer l’enregistrement", retry: "Réessayer la génération ↗", cancel: "Annuler", reference: "Photo de référence", ready: "Prêt à transformer", hero: "Votre héros cinématographique", library: "Galerie", camera: "Caméra", libraryHint: "Ouvre la photothèque pour choisir une photo", cameraHint: "Ouvre la caméra pour prendre une photo", back: "Retour", dismiss: "Fermer", optional: "OPTIONNEL", promptHint: "Façonnez le synopsis", premisePlaceholder: "Rendez-la inattendue…", premiseKicker: "SYNOPSIS DE VOTRE ÉPISODE", failureTitle: "La scène mérite une nouvelle prise.", failureCopy: "MORPH n’a pas terminé cette génération. Vos choix sont enregistrés.", requestTimedOut: "La demande a pris trop de temps. Réessayez quand vous êtes prêt.", requestCancelled: "La demande a été annulée. Vos choix sont toujours là.", characterLabel: "PERSONNAGE", styleLabel: "STYLE VISUEL", nextLabel: "QUE SE PASSE-T-IL ENSUITE ?", genreLabel: "GENRE", toneLabel: "TON", worldLabel: "MONDE" },
  es: { title: "Pon tu personaje\nen una historia.", subtitle: "Elige una dirección. MORPH hace el resto.", recovered: "Escena sin terminar recuperada", discard: "Descartar borrador", note: "Nota del director", surprise: "Sorpréndeme ↗", generate: "Generar episodio", building: "Creando tu episodio…", persisting: "Guardando tu historia…", characterSaveFailed: "No se pudo guardar tu personaje.", episodeSaveFailed: "No se pudo guardar tu episodio.", savedCharacter: "Personaje guardado", savedEpisode: "Episodio guardado", pendingCharacter: "Personaje pendiente de guardado", pendingEpisode: "Episodio pendiente de guardado", savingCharacter: "Guardando personaje…", savingEpisode: "Guardando episodio…", savedAll: "Personaje y episodio guardados", retrySave: "Reintentar guardado", retry: "Reintentar generación ↗", cancel: "Cancelar", reference: "Foto de referencia", ready: "Listo para transformar", hero: "Tu héroe cinematográfico", library: "Galería", camera: "Cámara", libraryHint: "Abre el carrete para elegir una foto", cameraHint: "Abre la cámara para tomar una foto", back: "Volver", dismiss: "Cerrar", optional: "OPCIONAL", promptHint: "Da forma a la premisa", premisePlaceholder: "Hazlo inesperado…", premiseKicker: "PREMISA DE TU EPISODIO", failureTitle: "La escena necesita otra toma.", failureCopy: "MORPH no pudo terminar esta generación. Tus elecciones están guardadas.", requestTimedOut: "La solicitud tardó demasiado. Inténtalo de nuevo cuando quieras.", requestCancelled: "La solicitud se canceló. Tus elecciones siguen aquí.", characterLabel: "PERSONAJE", styleLabel: "ESTILO VISUAL", nextLabel: "¿QUÉ PASA DESPUÉS?", genreLabel: "GÉNERO", toneLabel: "TONO", worldLabel: "MUNDO" },
  ar: { title: "ضع شخصيتك\nفي قصة.", subtitle: "اختر اتجاهًا، وسيتولى MORPH الباقي.", recovered: "تم استرداد المشهد غير المكتمل", discard: "حذف المسودة", note: "ملاحظة المخرج", surprise: "فاجئني ↗", generate: "إنشاء الحلقة", building: "جارٍ بناء الحلقة…", persisting: "جارٍ حفظ قصتك…", characterSaveFailed: "تعذر حفظ شخصيتك.", episodeSaveFailed: "تعذر حفظ حلقتك.", savedCharacter: "تم حفظ الشخصية", savedEpisode: "تم حفظ الحلقة", pendingCharacter: "الشخصية بانتظار الحفظ", pendingEpisode: "الحلقة بانتظار الحفظ", savingCharacter: "جارٍ حفظ الشخصية…", savingEpisode: "جارٍ حفظ الحلقة…", savedAll: "تم حفظ الشخصية والحلقة", retrySave: "إعادة محاولة الحفظ", retry: "إعادة محاولة الإنشاء ↗", cancel: "إلغاء", reference: "صورة مرجعية", ready: "جاهز للتحويل", hero: "بطلك السينمائي", library: "المكتبة", camera: "الكاميرا", libraryHint: "افتح مكتبة الصور لاختيار صورة", cameraHint: "افتح الكاميرا لالتقاط صورة", back: "رجوع", dismiss: "إغلاق", optional: "اختياري", promptHint: "شكّل فكرة القصة", premisePlaceholder: "اجعلها غير متوقعة…", premiseKicker: "فكرة حلقتك", failureTitle: "يحتاج المشهد إلى محاولة أخرى.", failureCopy: "تعذر على MORPH إكمال الإنشاء. اختياراتك محفوظة.", requestTimedOut: "استغرق الطلب وقتًا طويلاً. حاول مرة أخرى عندما تكون مستعدًا.", requestCancelled: "تم إلغاء الطلب. ما زالت اختياراتك محفوظة هنا.", characterLabel: "الشخصية", styleLabel: "الأسلوب البصري", nextLabel: "ماذا يحدث بعد ذلك؟", genreLabel: "النوع", toneLabel: "النبرة", worldLabel: "العالم" },
};

export interface VideoStudioCopy {
  kicker: string; title: string; importTitle: string; choose: string; preview: string; timeline: string; modes: string; ai: string; clips: string; zoom: string; emptyPreview: string; clipOne: string; clipTwo: string; loading: string; unavailable: string; selected: string; rewind: string; play: string; pause: string; forward: string; aiMeta: string; close: string; importHint: string; modeHint: string; aiTitle: string; importReady: (fileName: string) => string; importFailed: string; networkError: string; formatError: string; retryPlayback: string; retryImport: string; closeHint: string; clipHint: string; zoomHint: string; seekHint: string; playbackHint: string; aiHint: string; durationPending: string; rewindBoundary: string; forwardBoundary: string; position: (current: string, total: string) => string; clipSelection: (name: string) => string; zoomLevel: (zoom: string) => string; modeSelection: (mode: string) => string; aiOpened: string;
}

const videoStudioCopy: Record<"en" | "fr" | "es" | "ar", VideoStudioCopy> = {
  en: { kicker: "VIDEO STUDIO", title: "Cut the moment\nuntil it feels like you.", importTitle: "+ Import a video", choose: "Choose from your camera roll", preview: "IMPORTED PREVIEW", timeline: "TIMELINE", modes: "EDIT MODE", ai: "Need a stronger cut?", clips: "Episode 01 · 2 clips", zoom: "Zoom", emptyPreview: "PREVIEW", clipOne: "Hidden club", clipTwo: "Door opens", loading: "Loading media…", unavailable: "Preview unavailable", selected: "Selected video", rewind: "Back one second", play: "Play video", pause: "Pause video", forward: "Forward one second", aiMeta: "Rewrite, remix, enhance, or check continuity.", close: "Close Video Studio", importHint: "Open the library to choose a video", modeHint: "Select an editing mode", aiTitle: "Ask AI to reshape this cut", importReady: (fileName) => `${fileName} is ready to edit.`, importFailed: "The video could not be selected.", networkError: "Check your connection and try playback again.", formatError: "This video format could not be decoded.", retryPlayback: "Retry playback", retryImport: "Choose another video", closeHint: "Return to the previous screen", clipHint: "Move the playhead to this clip", zoomHint: "Increase timeline scale", seekHint: "Move one second on the timeline", playbackHint: "Start or pause the preview", aiHint: "Open Creator Studio to ask AI for an edit", durationPending: "duration pending", rewindBoundary: "At the beginning of the timeline", forwardBoundary: "At the end of the timeline", position: (current, total) => `Timeline position ${current} of ${total}`, clipSelection: (name) => `${name} selected`, zoomLevel: (zoom) => `Timeline zoom ${zoom}`, modeSelection: (mode) => `${mode} mode selected`, aiOpened: "Opening AI copilot" },
  fr: { kicker: "STUDIO VIDÉO", title: "Coupez le moment\njusqu’à ce qu’il vous ressemble.", importTitle: "+ Importer une vidéo", choose: "Choisir dans votre pellicule", preview: "APERÇU IMPORTÉ", timeline: "MONTAGE", modes: "MODE D’ÉDITION", ai: "Besoin d’un montage plus fort ?", clips: "Épisode 01 · 2 clips", zoom: "Zoom", emptyPreview: "APERÇU", clipOne: "Club secret", clipTwo: "La porte s’ouvre", loading: "Chargement du média…", unavailable: "Aperçu indisponible", selected: "Vidéo sélectionnée", rewind: "Reculer d’une seconde", play: "Lire la vidéo", pause: "Mettre en pause", forward: "Avancer d’une seconde", aiMeta: "Réécrire, remixer, améliorer ou vérifier la continuité.", close: "Fermer le studio vidéo", importHint: "Ouvre la photothèque pour choisir une vidéo", modeHint: "Sélectionne le mode de montage", aiTitle: "Demander à l’IA de remodeler ce montage", importReady: (fileName) => `${fileName} est prêt à être monté.`, importFailed: "La vidéo n’a pas pu être sélectionnée.", networkError: "Vérifiez votre connexion, puis réessayez la lecture.", formatError: "Ce format vidéo n’a pas pu être décodé.", retryPlayback: "Réessayer la lecture", retryImport: "Choisir une autre vidéo", closeHint: "Retourner à l’écran précédent", clipHint: "Déplacer la tête de lecture vers ce clip", zoomHint: "Augmenter l’échelle du montage", seekHint: "Déplacer la tête de lecture d’une seconde", playbackHint: "Lancer ou mettre l’aperçu en pause", aiHint: "Ouvrir le studio créateur pour demander un montage à l’IA", durationPending: "durée en attente", rewindBoundary: "Au début du montage", forwardBoundary: "À la fin du montage", position: (current, total) => `Position dans le montage : ${current} sur ${total}`, clipSelection: (name) => `${name} sélectionné`, zoomLevel: (zoom) => `Zoom du montage : ${zoom}`, modeSelection: (mode) => `Mode ${mode} sélectionné`, aiOpened: "Ouverture du copilote IA" },
  es: { kicker: "ESTUDIO DE VIDEO", title: "Corta el momento\nhasta que se sienta tuyo.", importTitle: "+ Importar un video", choose: "Elegir del carrete", preview: "VISTA PREVIA IMPORTADA", timeline: "LÍNEA DE TIEMPO", modes: "MODO DE EDICIÓN", ai: "¿Necesitas un montaje más fuerte?", clips: "Episodio 01 · 2 clips", zoom: "Zoom", emptyPreview: "VISTA PREVIA", clipOne: "Club oculto", clipTwo: "La puerta se abre", loading: "Cargando contenido…", unavailable: "Vista previa no disponible", selected: "Video seleccionado", rewind: "Retroceder un segundo", play: "Reproducir vídeo", pause: "Pausar vídeo", forward: "Avanzar un segundo", aiMeta: "Reescribe, remezcla, mejora o revisa la continuidad.", close: "Cerrar el estudio de video", importHint: "Abre el carrete para elegir un video", modeHint: "Selecciona el modo de edición", aiTitle: "Pedir a la IA que remodele este montaje", importReady: (fileName) => `${fileName} está listo para editar.`, importFailed: "No se pudo seleccionar el video.", networkError: "Comprueba tu conexión y vuelve a intentar la reproducción.", formatError: "No se pudo decodificar este formato de video.", retryPlayback: "Reintentar reproducción", retryImport: "Elegir otro video", closeHint: "Volver a la pantalla anterior", clipHint: "Mover el cabezal a este clip", zoomHint: "Aumentar la escala de la línea de tiempo", seekHint: "Mover un segundo en la línea de tiempo", playbackHint: "Iniciar o pausar la vista previa", aiHint: "Abrir Creator Studio para pedir una edición a la IA", durationPending: "duración pendiente", rewindBoundary: "Al principio de la línea de tiempo", forwardBoundary: "Al final de la línea de tiempo", position: (current, total) => `Posición en la línea de tiempo: ${current} de ${total}`, clipSelection: (name) => `${name} seleccionado`, zoomLevel: (zoom) => `Zoom de la línea de tiempo: ${zoom}`, modeSelection: (mode) => `Modo ${mode} seleccionado`, aiOpened: "Abriendo el copiloto de IA" },
  ar: { kicker: "استوديو الفيديو", title: "اقطع اللحظة\nحتى تشبهك.", importTitle: "+ استيراد فيديو", choose: "اختر من ألبوم الكاميرا", preview: "المعاينة المستوردة", timeline: "المخطط الزمني", modes: "وضع التحرير", ai: "هل تحتاج إلى مونتاج أقوى؟", clips: "الحلقة 01 · مقطعان", zoom: "تكبير", emptyPreview: "المعاينة", clipOne: "النادي الخفي", clipTwo: "الباب يُفتح", loading: "جارٍ تحميل الوسائط…", unavailable: "المعاينة غير متاحة", selected: "الفيديو المحدد", rewind: "رجوع ثانية واحدة", play: "تشغيل الفيديو", pause: "إيقاف الفيديو مؤقتًا", forward: "تقدم ثانية واحدة", aiMeta: "أعد الكتابة أو المزج أو التحسين أو تحقق من الاستمرارية.", close: "إغلاق استوديو الفيديو", importHint: "افتح المكتبة لاختيار فيديو", modeHint: "اختر وضع التحرير", aiTitle: "اطلب من الذكاء الاصطناعي إعادة تشكيل هذا المقطع", importReady: (fileName) => `الفيديو ${fileName} جاهز للتحرير.`, importFailed: "تعذر اختيار الفيديو.", networkError: "تحقق من اتصالك ثم حاول التشغيل مرة أخرى.", formatError: "تعذر فك ترميز تنسيق الفيديو هذا.", retryPlayback: "إعادة محاولة التشغيل", retryImport: "اختيار فيديو آخر", closeHint: "العودة إلى الشاشة السابقة", clipHint: "نقل مؤشر التشغيل إلى هذا المقطع", zoomHint: "زيادة مقياس المخطط الزمني", seekHint: "تحريك مؤشر التشغيل ثانية واحدة", playbackHint: "بدء المعاينة أو إيقافها مؤقتًا", aiHint: "افتح استوديو المبدع لطلب تعديل من الذكاء الاصطناعي", durationPending: "المدة قيد الانتظار", rewindBoundary: "عند بداية المخطط الزمني", forwardBoundary: "عند نهاية المخطط الزمني", position: (current, total) => `موضع المخطط الزمني ${current} من ${total}`, clipSelection: (name) => `تم تحديد ${name}`, zoomLevel: (zoom) => `تكبير المخطط الزمني ${zoom}`, modeSelection: (mode) => `تم اختيار وضع ${mode}`, aiOpened: "جارٍ فتح مساعد الذكاء الاصطناعي" },
};

export function getCreateCopy(language: LanguageCode): CreateCopy {
  return createCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}

export function getVideoStudioCopy(language: LanguageCode): VideoStudioCopy {
  return videoStudioCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}

export function getVideoModeLabels(language: LanguageCode): Partial<Record<"edit" | "trim" | "effects" | "audio" | "captions" | "ai", string>> {
  return language === "fr" ? { edit: "Éditer", trim: "Rogner", effects: "Effets", audio: "Audio", captions: "Sous-titres", ai: "Montage IA" } : language === "es" ? { edit: "Editar", trim: "Recortar", effects: "Efectos", audio: "Audio", captions: "Subtítulos", ai: "Edición IA" } : language === "ar" ? { edit: "تحرير", trim: "قص", effects: "تأثيرات", audio: "الصوت", captions: "الترجمة", ai: "تحرير بالذكاء الاصطناعي" } : { edit: "Edit", trim: "Trim", effects: "Effects", audio: "Audio", captions: "Captions", ai: "AI edit" };
}

export function getCharactersCopy(language: LanguageCode): CharactersCopy {
  return charactersCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}

export function getProfileCopy(language: LanguageCode): ProfileCopy {
  return profileCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}

export function getWorldsCopy(language: LanguageCode): WorldsCopy {
  return worldsCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}

export function getStoriesCopy(language: LanguageCode): StoriesCopy {
  return storiesCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
export function getStoryMapCopy(language: LanguageCode): StoryMapCopy {
  return storyMapCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
