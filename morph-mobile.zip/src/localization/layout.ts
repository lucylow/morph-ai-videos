import type { ViewStyle, TextStyle } from "react-native";
import type { TextDirection } from "./i18n";

export function directionStyle(direction: TextDirection): ViewStyle { return { direction }; }
export function rowDirection(direction: TextDirection): ViewStyle { return { flexDirection: direction === "rtl" ? "row-reverse" : "row" }; }
export function textDirection(direction: TextDirection): TextStyle { return { textAlign: direction === "rtl" ? "right" : "left", writingDirection: direction }; }
