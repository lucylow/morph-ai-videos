import type { LanguageCode } from "./i18n";

export interface CharacterDetailCopy {
  edit: string;
  name: string;
  style: string;
  personality: string;
  namePlaceholder: string;
  stylePlaceholder: string;
  personalityPlaceholder: string;
  cancel: string;
  save: string;
  saving: string;
  editHint: string;
  saveError: string;
  unavailable: string;
  saved: string;
  loadError: string;
  retry: string;
  discardTitle: string;
  discardMessage: string;
  discard: string;
  keepEditing: string;
}

const COPY: Partial<Record<LanguageCode, CharacterDetailCopy>> = {
  en: { edit: "Edit character", name: "CHARACTER NAME", style: "VISUAL STYLE", personality: "PERSONALITY", namePlaceholder: "Name", stylePlaceholder: "Style", personalityPlaceholder: "Curious, brave", cancel: "Cancel", save: "Save", saving: "Saving…", editHint: "Opens editable character details", saveError: "Could not save these changes. Try again.", unavailable: "This character is no longer available.", saved: "Character saved", loadError: "Could not load this character.", retry: "Try again", discardTitle: "Discard changes?", discardMessage: "Your edits have not been saved.", discard: "Discard", keepEditing: "Keep editing" },
  fr: { edit: "Modifier le personnage", name: "NOM DU PERSONNAGE", style: "STYLE VISUEL", personality: "PERSONNALITÉ", namePlaceholder: "Nom", stylePlaceholder: "Style", personalityPlaceholder: "Curieux, courageux", cancel: "Annuler", save: "Enregistrer", saving: "Enregistrement…", editHint: "Ouvre les détails modifiables du personnage", saveError: "Impossible d’enregistrer ces changements. Réessayez.", unavailable: "Ce personnage n’est plus disponible.", saved: "Personnage enregistré", loadError: "Impossible de charger ce personnage.", retry: "Réessayer", discardTitle: "Abandonner les changements ?", discardMessage: "Vos modifications ne sont pas enregistrées.", discard: "Abandonner", keepEditing: "Continuer la modification" },
  es: { edit: "Editar personaje", name: "NOMBRE DEL PERSONAJE", style: "ESTILO VISUAL", personality: "PERSONALIDAD", namePlaceholder: "Nombre", stylePlaceholder: "Estilo", personalityPlaceholder: "Curioso, valiente", cancel: "Cancelar", save: "Guardar", saving: "Guardando…", editHint: "Abre los detalles editables del personaje", saveError: "No se pudieron guardar los cambios. Inténtalo de nuevo.", unavailable: "Este personaje ya no está disponible.", saved: "Personaje guardado", loadError: "No se pudo cargar este personaje.", retry: "Intentar de nuevo", discardTitle: "¿Descartar cambios?", discardMessage: "Tus cambios aún no se han guardado.", discard: "Descartar", keepEditing: "Seguir editando" },
  ar: { edit: "تعديل الشخصية", name: "اسم الشخصية", style: "الأسلوب البصري", personality: "الشخصية", namePlaceholder: "الاسم", stylePlaceholder: "الأسلوب", personalityPlaceholder: "فضولي، شجاع", cancel: "إلغاء", save: "حفظ", saving: "جارٍ الحفظ…", editHint: "يفتح تفاصيل الشخصية القابلة للتعديل", saveError: "تعذر حفظ التغييرات. حاول مرة أخرى.", unavailable: "لم تعد هذه الشخصية متاحة.", saved: "تم حفظ الشخصية", loadError: "تعذر تحميل هذه الشخصية.", retry: "حاول مرة أخرى", discardTitle: "هل تريد تجاهل التغييرات؟", discardMessage: "لم يتم حفظ تعديلاتك بعد.", discard: "تجاهل", keepEditing: "متابعة التعديل" },
};

export function getCharacterDetailCopy(language: LanguageCode): CharacterDetailCopy {
  return COPY[language] ?? COPY.en!;
}
