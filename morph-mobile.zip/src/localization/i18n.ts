export type LanguageCode = "en" | "fr" | "es" | "de" | "pt" | "it" | "ja" | "ko" | "zh" | "ar" | "hi" | "sw" | "wo";
export type TextDirection = "ltr" | "rtl";
export interface LanguageDefinition { code: LanguageCode; name: string; nativeName: string; direction: TextDirection; locale: string; enabled: boolean; aiSupported: boolean; speechSupported: boolean; captionsSupported: boolean; }
export interface LocaleProfile { language: LanguageCode; locale: string; direction: TextDirection; decimalSeparator: string; thousandsSeparator: string; dateFormat: "numeric" | "2-digit"; timeFormat: "numeric" | "2-digit"; }
export interface LocalizedText { canonical: string; translations?: Partial<Record<LanguageCode, string>>; }

export const LANGUAGES: Record<LanguageCode, LanguageDefinition> = {
  en: { code: "en", name: "English", nativeName: "English", direction: "ltr", locale: "en-US", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  fr: { code: "fr", name: "French", nativeName: "Français", direction: "ltr", locale: "fr-FR", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  es: { code: "es", name: "Spanish", nativeName: "Español", direction: "ltr", locale: "es-ES", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  de: { code: "de", name: "German", nativeName: "Deutsch", direction: "ltr", locale: "de-DE", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  pt: { code: "pt", name: "Portuguese", nativeName: "Português", direction: "ltr", locale: "pt-BR", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  it: { code: "it", name: "Italian", nativeName: "Italiano", direction: "ltr", locale: "it-IT", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  ja: { code: "ja", name: "Japanese", nativeName: "日本語", direction: "ltr", locale: "ja-JP", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  ko: { code: "ko", name: "Korean", nativeName: "한국어", direction: "ltr", locale: "ko-KR", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  zh: { code: "zh", name: "Chinese", nativeName: "中文", direction: "ltr", locale: "zh-CN", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  ar: { code: "ar", name: "Arabic", nativeName: "العربية", direction: "rtl", locale: "ar", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  hi: { code: "hi", name: "Hindi", nativeName: "हिन्दी", direction: "ltr", locale: "hi-IN", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  sw: { code: "sw", name: "Swahili", nativeName: "Kiswahili", direction: "ltr", locale: "sw", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
  wo: { code: "wo", name: "Wolof", nativeName: "Wolof", direction: "ltr", locale: "wo", enabled: true, aiSupported: true, speechSupported: true, captionsSupported: true },
};

export function resolveLanguage(requested?: string | null, detected?: string | null): LanguageCode { const normalize = (value?: string | null) => value?.toLowerCase().split(/[-_]/)[0] as LanguageCode | undefined; const candidate = normalize(requested); if (candidate && LANGUAGES[candidate]?.enabled) return candidate; const device = normalize(detected); return device && LANGUAGES[device]?.enabled ? device : "en"; }
export function getLocaleProfile(language: LanguageCode): LocaleProfile { const definition = LANGUAGES[language] ?? LANGUAGES.en; const parts = new Intl.NumberFormat(definition.locale).formatToParts(12345.6); return { language: definition.code, locale: definition.locale, direction: definition.direction, decimalSeparator: parts.find((part) => part.type === "decimal")?.value ?? ".", thousandsSeparator: parts.find((part) => part.type === "group")?.value ?? ",", dateFormat: "numeric", timeFormat: "numeric" }; }
export function formatNumber(value: number, language: LanguageCode): string { return new Intl.NumberFormat(getLocaleProfile(language).locale).format(Number.isFinite(value) ? value : 0); }
export function formatCurrency(value: number, language: LanguageCode, currency = "USD"): string { return new Intl.NumberFormat(getLocaleProfile(language).locale, { style: "currency", currency }).format(Number.isFinite(value) ? value : 0); }
export function formatDate(value: Date | number | string, language: LanguageCode): string { const date = new Date(value); return new Intl.DateTimeFormat(getLocaleProfile(language).locale, { dateStyle: "medium" }).format(Number.isNaN(date.getTime()) ? new Date(0) : date); }
export function translateText(text: LocalizedText, language: LanguageCode, fallback: LanguageCode = "en"): string { const translated = text.translations?.[language]?.trim(); if (translated) return translated; const fallbackText = text.translations?.[fallback]?.trim(); return fallbackText || text.canonical; }
export function isRTL(language: LanguageCode): boolean { return getLocaleProfile(language).direction === "rtl"; }
export function localizePrompt(prompt: string, language: LanguageCode): string { const safePrompt = prompt.trim(); return language === "en" ? safePrompt : `[${LANGUAGES[language].name} response requested] ${safePrompt}`; }
