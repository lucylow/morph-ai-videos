import type { LanguageCode } from "./i18n";

export interface HomeCopy {
  greeting: string;
  hero: string;
  create: string;
  createHint: string;
  studio: string;
  studioHint: string;
  profileHint: string;
  characters: string;
  seeAll: string;
  worlds: string;
  explore: string;
  next: string;
  episode: string;
  filters: string[];
}

const copy: Record<"en" | "fr" | "es" | "ar", HomeCopy> = {
  en: { greeting: "GOOD EVENING, JORDAN", hero: "What should your\ncharacter become today?", create: "+  Create character", createHint: "Opens character creation", studio: "Open Creator Studio", studioHint: "Opens Creator Studio", profileHint: "Opens your profile and language settings", characters: "Your characters", seeAll: "See all", worlds: "Find your next world", explore: "Explore", next: "What happens next?", episode: "One tap to start a new episode", filters: ["For you", "Trending", "Continue"] },
  fr: { greeting: "BONSOIR, JORDAN", hero: "Que doit devenir votre\npersonnage aujourd’hui ?", create: "+  Créer un personnage", createHint: "Ouvre la création de personnage", studio: "Ouvrir Creator Studio", studioHint: "Ouvre Creator Studio", profileHint: "Ouvre votre profil et les réglages de langue", characters: "Vos personnages", seeAll: "Tout voir", worlds: "Trouvez votre prochain monde", explore: "Explorer", next: "Et maintenant ?", episode: "Un geste pour commencer un nouvel épisode", filters: ["Pour vous", "Tendances", "Continuer"] },
  es: { greeting: "BUENAS NOCHES, JORDAN", hero: "¿En qué debería convertirse tu\npersonaje hoy?", create: "+  Crear personaje", createHint: "Abre la creación de personajes", studio: "Abrir Creator Studio", studioHint: "Abre Creator Studio", profileHint: "Abre tu perfil y los ajustes de idioma", characters: "Tus personajes", seeAll: "Ver todo", worlds: "Encuentra tu próximo mundo", explore: "Explorar", next: "¿Qué ocurre después?", episode: "Un toque para comenzar un episodio nuevo", filters: ["Para ti", "Tendencias", "Continuar"] },
  ar: { greeting: "مساء الخير، جوردان", hero: "إلى ماذا ينبغي أن تصبح\nشخصيتك اليوم؟", create: "+  إنشاء شخصية", createHint: "يفتح إنشاء الشخصية", studio: "فتح استوديو Creator", studioHint: "يفتح استوديو Creator", profileHint: "يفتح ملفك وإعدادات اللغة", characters: "شخصياتك", seeAll: "عرض الكل", worlds: "اعثر على عالمك التالي", explore: "استكشاف", next: "ماذا يحدث بعد ذلك؟", episode: "لمسة واحدة لبدء حلقة جديدة", filters: ["لك", "رائج", "متابعة"] },
};

export function getHomeCopy(language: LanguageCode): HomeCopy {
  return copy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
