import type { LanguageCode } from "./i18n";

export interface SystemCopy {
  offlineDrafts: string;
  dismiss: string;
  returnHome: string;
  recoveryTitle: string;
  recoveryBody: string;
  retry: string;
}

const systemCopy: Record<"en" | "fr" | "es" | "ar", SystemCopy> = {
  en: { offlineDrafts: "You’re offline · Your drafts are still available", dismiss: "Dismiss", returnHome: "Return home", recoveryTitle: "This scene needs a fresh start.", recoveryBody: "An unexpected screen error occurred. Your saved characters and drafts are still protected.", retry: "Try again" },
  fr: { offlineDrafts: "Vous êtes hors ligne · Vos brouillons restent disponibles", dismiss: "Fermer", returnHome: "Retour à l’accueil", recoveryTitle: "Cette scène doit repartir de zéro.", recoveryBody: "Une erreur d’écran inattendue s’est produite. Vos personnages et brouillons enregistrés restent protégés.", retry: "Réessayer" },
  es: { offlineDrafts: "Estás sin conexión · Tus borradores siguen disponibles", dismiss: "Cerrar", returnHome: "Volver al inicio", recoveryTitle: "Esta escena necesita un nuevo comienzo.", recoveryBody: "Ocurrió un error inesperado en la pantalla. Tus personajes y borradores guardados siguen protegidos.", retry: "Reintentar" },
  ar: { offlineDrafts: "أنت غير متصل · لا تزال مسوداتك متاحة", dismiss: "إغلاق", returnHome: "العودة إلى الرئيسية", recoveryTitle: "يحتاج هذا المشهد إلى بداية جديدة.", recoveryBody: "حدث خطأ غير متوقع في الشاشة. لا تزال شخصياتك ومسوداتك المحفوظة محمية.", retry: "حاول مرة أخرى" },
};

export function getSystemCopy(language: LanguageCode): SystemCopy {
  return systemCopy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
