import type { LanguageCode } from "@/src/localization/i18n";

export interface CreateInteractionCopy {
  backHint: string;
  dismiss: string;
  draftRecovery: string;
  cameraPermissionTitle: string;
  cameraPermissionBody: string;
  discardHint: string;
  creativeIdeaHint: string;
  cancelHint: string;
  retrySaveHint: string;
  retryGenerationHint: string;
}

const copy: Record<"en" | "fr" | "es" | "ar", CreateInteractionCopy> = {
  en: { backHint: "Returns to the previous screen", dismiss: "Dismiss", draftRecovery: "Your last choices are still here. Continue shaping the episode or discard this draft.", cameraPermissionTitle: "Camera access needed", cameraPermissionBody: "Allow camera access in Settings to take a character reference photo.", discardHint: "Removes the saved creation draft", creativeIdeaHint: "Fills the premise with a new creative idea", cancelHint: "Stops generation and keeps your choices", retrySaveHint: "Retries saving without generating again", retryGenerationHint: "Tries generation again" },
  fr: { backHint: "Retourne à l’écran précédent", dismiss: "Fermer", draftRecovery: "Vos derniers choix sont toujours là. Continuez à façonner l’épisode ou supprimez ce brouillon.", cameraPermissionTitle: "Accès à la caméra requis", cameraPermissionBody: "Autorisez l’accès à la caméra dans les réglages pour prendre une photo de référence.", discardHint: "Supprime le brouillon de création enregistré", creativeIdeaHint: "Remplit le synopsis avec une nouvelle idée créative", cancelHint: "Arrête la génération et conserve vos choix", retrySaveHint: "Réessaie l’enregistrement sans relancer la génération", retryGenerationHint: "Réessaie la génération" },
  es: { backHint: "Vuelve a la pantalla anterior", dismiss: "Cerrar", draftRecovery: "Tus últimas elecciones siguen aquí. Continúa dando forma al episodio o descarta este borrador.", cameraPermissionTitle: "Se necesita acceso a la cámara", cameraPermissionBody: "Permite el acceso a la cámara en Ajustes para tomar una foto de referencia.", discardHint: "Elimina el borrador de creación guardado", creativeIdeaHint: "Rellena la premisa con una nueva idea creativa", cancelHint: "Detiene la generación y conserva tus elecciones", retrySaveHint: "Reintenta guardar sin generar de nuevo", retryGenerationHint: "Vuelve a intentar la generación" },
  ar: { backHint: "يعود إلى الشاشة السابقة", dismiss: "إغلاق", draftRecovery: "اختياراتك الأخيرة ما زالت هنا. واصل تشكيل الحلقة أو احذف هذه المسودة.", cameraPermissionTitle: "يلزم الوصول إلى الكاميرا", cameraPermissionBody: "اسمح بالوصول إلى الكاميرا من الإعدادات لالتقاط صورة مرجعية للشخصية.", discardHint: "يزيل مسودة الإنشاء المحفوظة", creativeIdeaHint: "يملأ الفكرة بفكرة إبداعية جديدة", cancelHint: "يوقف الإنشاء ويحافظ على اختياراتك", retrySaveHint: "يعيد محاولة الحفظ دون الإنشاء من جديد", retryGenerationHint: "يعيد محاولة الإنشاء" },
};

export function getCreateInteractionCopy(language: LanguageCode): CreateInteractionCopy {
  return copy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
