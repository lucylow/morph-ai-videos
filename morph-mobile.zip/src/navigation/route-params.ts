export interface CharacterRouteParams {
  id?: string | string[];
}

function firstRouteValue(value: string | string[] | undefined): string | null {
  const candidate = Array.isArray(value) ? value[0] : value;
  const normalized = candidate?.trim().toLowerCase();
  return normalized ? normalized : null;
}

export function parseCharacterId(value: CharacterRouteParams["id"]): string | null {
  return firstRouteValue(value);
}

export function parseCharacterRouteParams(params: Partial<CharacterRouteParams> | null | undefined): { id: string | null } {
  return { id: parseCharacterId(params?.id) };
}
