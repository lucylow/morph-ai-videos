export const DEFAULT_API_TIMEOUT_MS = 15_000;

export type ApiAbortReason = "timeout" | "cancelled";

export interface ApiAbortControllerHandle {
  signal: AbortSignal;
  getReason: () => ApiAbortReason | null;
  dispose: () => void;
}

export function createApiAbortController(
  externalSignal?: AbortSignal | null,
  timeoutMs = DEFAULT_API_TIMEOUT_MS,
): ApiAbortControllerHandle {
  const controller = new AbortController();
  const safeTimeoutMs = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : DEFAULT_API_TIMEOUT_MS;
  let reason: ApiAbortReason | null = null;
  const timeoutHandle = setTimeout(() => {
    if (controller.signal.aborted) return;
    reason = "timeout";
    controller.abort();
  }, safeTimeoutMs);
  const forwardAbort = () => {
    if (controller.signal.aborted) return;
    reason = "cancelled";
    controller.abort();
  };

  if (externalSignal) {
    if (externalSignal.aborted) {
      forwardAbort();
    } else {
      externalSignal.addEventListener("abort", forwardAbort, { once: true });
    }
  }

  let disposed = false;
  return {
    signal: controller.signal,
    getReason: () => reason,
    dispose: () => {
      if (disposed) return;
      disposed = true;
      clearTimeout(timeoutHandle);
      externalSignal?.removeEventListener("abort", forwardAbort);
    },
  };
}
