import AsyncStorage from "@react-native-async-storage/async-storage";

import { withStorageRetry } from "../storage/morph-repository";

const ONBOARDING_KEY = "morph.onboarding.completed.v1";

export interface OnboardingState {
  completed: boolean;
}

export function normalizeOnboardingState(value: unknown): OnboardingState {
  if (value === true || value === "true") return { completed: true };
  if (typeof value === "object" && value !== null && "completed" in value) {
    return { completed: (value as { completed?: unknown }).completed === true };
  }
  return { completed: false };
}

export async function loadOnboardingState(): Promise<OnboardingState> {
  try {
    const raw = await AsyncStorage.getItem(ONBOARDING_KEY);
    return normalizeOnboardingState(raw);
  } catch {
    return { completed: false };
  }
}

export async function completeOnboarding(): Promise<void> {
  await withStorageRetry(() => AsyncStorage.setItem(ONBOARDING_KEY, "true"));
}

export async function resetOnboarding(): Promise<void> {
  await withStorageRetry(() => AsyncStorage.removeItem(ONBOARDING_KEY));
}
