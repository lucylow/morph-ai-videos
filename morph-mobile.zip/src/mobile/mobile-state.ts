export type DeviceNetwork = "wifi" | "cellular" | "offline" | "unknown";
export type MobilePermission = "camera" | "photos" | "notifications" | "microphone";
export type MobileAppState = "active" | "inactive" | "background";

export interface MobileState { network: DeviceNetwork; online: boolean; lowPowerMode: boolean; appState: MobileAppState; permissions: Record<MobilePermission, boolean>; pendingGeneration?: string; pendingUpload?: string; }
export const defaultMobileState: MobileState = { network: "unknown", online: true, lowPowerMode: false, appState: "active", permissions: { camera: false, photos: false, notifications: false, microphone: false } };

export function normalizeNetworkState(input: { isConnected?: boolean | null; isInternetReachable?: boolean | null; type?: string | null }): Pick<MobileState, "network" | "online"> { const online = input.isInternetReachable ?? input.isConnected ?? false; const network = !online ? "offline" : input.type === "WIFI" ? "wifi" : input.type === "CELLULAR" ? "cellular" : "unknown"; return { online: Boolean(online), network }; }

export function shouldShowOfflineBanner(input: { isConnected?: boolean | null; isInternetReachable?: boolean | null }): boolean { if (input.isInternetReachable === false) return true; if (input.isInternetReachable === true) return false; return input.isConnected === false; }
export function clampUploadProgress(progress: number): number { return Math.min(100, Math.max(0, Number.isFinite(progress) ? progress : 0)); }
