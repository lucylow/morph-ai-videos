import AsyncStorage from "@react-native-async-storage/async-storage";

export type StudioMode = "timeline" | "scene" | "story" | "characters" | "worlds" | "assets" | "templates" | "history" | "publish";
export type StudioEntityType = "project" | "story" | "episode" | "scene" | "character" | "world" | "asset" | "template";
export type StudioPanel = "navigator" | "assets" | "characters" | "worlds";
export type StudioRightPanel = "copilot" | "inspector" | "history";

export interface CreatorStudioProject {
  id: string;
  ownerId: string;
  title: string;
  description?: string;
  activeStoryId?: string;
  activeEpisodeId?: string;
  activeSceneId?: string;
  mode: StudioMode;
  storyIds: string[];
  characterIds: string[];
  worldIds: string[];
  assetIds: string[];
  templateIds: string[];
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface StudioState {
  project?: CreatorStudioProject;
  selectedEntity?: { type: StudioEntityType; id: string };
  mode: StudioMode;
  leftPanel: StudioPanel;
  rightPanel: StudioRightPanel;
  timelineZoom: number;
  dirty: boolean;
  saving: boolean;
  lastSavedAt?: string;
}

const STORAGE_KEY = "morph.local.studio-state.v1";
const MODES: StudioMode[] = ["timeline", "scene", "story", "characters", "worlds", "assets", "templates", "history", "publish"];
const PANELS: StudioPanel[] = ["navigator", "assets", "characters", "worlds"];
const RIGHT_PANELS: StudioRightPanel[] = ["copilot", "inspector", "history"];

export const defaultStudioState: StudioState = { mode: "timeline", leftPanel: "navigator", rightPanel: "copilot", timelineZoom: 1, dirty: false, saving: false };

export function normalizeStudioState(value: unknown): StudioState {
  if (!value || typeof value !== "object") return defaultStudioState;
  const input = value as Partial<StudioState>;
  return {
    ...defaultStudioState,
    ...input,
    mode: MODES.includes(input.mode as StudioMode) ? input.mode as StudioMode : "timeline",
    leftPanel: PANELS.includes(input.leftPanel as StudioPanel) ? input.leftPanel as StudioPanel : "navigator",
    rightPanel: RIGHT_PANELS.includes(input.rightPanel as StudioRightPanel) ? input.rightPanel as StudioRightPanel : "copilot",
    timelineZoom: typeof input.timelineZoom === "number" && Number.isFinite(input.timelineZoom) ? Math.max(0.5, Math.min(input.timelineZoom, 3)) : 1,
    dirty: input.dirty === true,
    saving: false,
  };
}

export function setStudioMode(state: StudioState, mode: StudioMode): StudioState { return { ...state, mode, dirty: true }; }
export function selectStudioEntity(state: StudioState, entity: StudioState["selectedEntity"]): StudioState { const changed = state.selectedEntity?.type !== entity?.type || state.selectedEntity?.id !== entity?.id || state.rightPanel !== "inspector"; return { ...state, selectedEntity: entity, rightPanel: "inspector", dirty: state.dirty || changed }; }
export function clearStudioEntity(state: StudioState): StudioState { const changed = Boolean(state.selectedEntity) || state.rightPanel !== "copilot"; return { ...state, selectedEntity: undefined, rightPanel: "copilot", dirty: state.dirty || changed }; }
export function focusStudioEntityPanel(state: StudioState): StudioState { const panel = state.selectedEntity?.type === "character" ? "characters" : state.selectedEntity?.type === "world" ? "worlds" : state.selectedEntity?.type === "asset" ? "assets" : undefined; return panel ? setStudioPanel(state, panel) : state; }
export function setStudioPanel(state: StudioState, panel: StudioPanel): StudioState { return { ...state, leftPanel: panel, dirty: state.leftPanel !== panel || state.dirty }; }
export function setStudioSaving(state: StudioState, saving: boolean): StudioState { return { ...state, saving }; }
export function canSaveStudioState(state: StudioState | null | undefined, saving = false): boolean { return Boolean(state && state.dirty && !saving && !state.saving); }

export async function loadStudioState(): Promise<StudioState> {
  try { const serialized = await AsyncStorage.getItem(STORAGE_KEY); return serialized ? normalizeStudioState(JSON.parse(serialized)) : defaultStudioState; } catch { return defaultStudioState; }
}

export async function withStudioStorageRetry<T>(operation: () => Promise<T>, attempts = 3): Promise<T> {
  const safeAttempts = Math.max(1, Math.floor(attempts));
  let lastError: unknown;
  for (let attempt = 0; attempt < safeAttempts; attempt += 1) {
    try { return await operation(); } catch (error) { lastError = error; if (attempt < safeAttempts - 1) await new Promise((resolve) => setTimeout(resolve, 100 * (attempt + 1))); }
  }
  throw lastError instanceof Error ? lastError : new Error("MORPH Creator Studio storage failed");
}

export async function saveStudioState(state: StudioState): Promise<StudioState> {
  const saved = { ...normalizeStudioState(state), dirty: false, saving: false, lastSavedAt: new Date().toISOString() };
  await withStudioStorageRetry(() => AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(saved)));
  return saved;
}
