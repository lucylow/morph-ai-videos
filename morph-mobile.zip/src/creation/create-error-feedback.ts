import type { CreateCopy } from "@/src/localization/screen-copy";

export function getCreateRequestFeedback(error: unknown, copy: CreateCopy): string | null {
  const raw = error instanceof Error ? error.message : String(error);
  if (raw === "API request timed out") return copy.requestTimedOut;
  if (raw === "API request cancelled") return copy.requestCancelled;
  return null;
}
