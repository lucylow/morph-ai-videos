export type PersistenceStage = "character" | "episode";
export type PersistenceRecordState = "pending" | "saved";

export interface CreationPersistenceOutcome {
  character: PersistenceRecordState;
  episode: PersistenceRecordState;
  failedStage: PersistenceStage | null;
  error: unknown | null;
}

export interface CreationPersistenceOperations {
  saveCharacter: () => Promise<void>;
  saveEpisode: () => Promise<void>;
  clearDraft: () => Promise<void>;
}

/**
 * Persists generated records in dependency order. A character write must succeed
 * before an episode is attempted; a partial result is returned for retry-safe UI.
 */
export async function persistCreationRecords(
  operations: CreationPersistenceOperations,
): Promise<CreationPersistenceOutcome> {
  try {
    await operations.saveCharacter();
  } catch (error) {
    return { character: "pending", episode: "pending", failedStage: "character", error };
  }

  try {
    await operations.saveEpisode();
  } catch (error) {
    return { character: "saved", episode: "pending", failedStage: "episode", error };
  }

  try {
    await operations.clearDraft();
  } catch (error) {
    return { character: "saved", episode: "saved", failedStage: null, error };
  }

  return { character: "saved", episode: "saved", failedStage: null, error: null };
}
