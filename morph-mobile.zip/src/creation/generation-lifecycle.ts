export interface GenerationTimers {
  generation?: ReturnType<typeof setTimeout> | null;
  timeout?: ReturnType<typeof setTimeout> | null;
}

export function clearGenerationTimers(timers: GenerationTimers): void {
  if (timers.generation) clearTimeout(timers.generation);
  if (timers.timeout) clearTimeout(timers.timeout);
}

export interface ResetGenerationTimers {
  generation: ReturnType<typeof setTimeout> | null;
  timeout: ReturnType<typeof setTimeout> | null;
}

export function resetGenerationTimers(timers: GenerationTimers): ResetGenerationTimers {
  clearGenerationTimers(timers);
  return { generation: null, timeout: null };
}

export function canStartGeneration(isGenerating: boolean, isPersisting: boolean): boolean {
  return !isGenerating && !isPersisting;
}

export interface RetrySaveAccessibilityState {
  disabled: boolean;
  busy: boolean;
}

export function getRetrySaveAccessibilityState(isPersisting: boolean): RetrySaveAccessibilityState {
  return { disabled: isPersisting, busy: isPersisting };
}

export function getGenerationRetryAccessibilityState(isGenerating: boolean, isPersisting: boolean): RetrySaveAccessibilityState {
  const busy = isGenerating || isPersisting;
  return { disabled: busy, busy };
}

export function canStartPersistenceRetry(isPersisting: boolean): boolean {
  return !isPersisting;
}

export function nextGenerationRunId(currentRunId: unknown): number {
  return typeof currentRunId === "number" && Number.isSafeInteger(currentRunId) && currentRunId >= 0 && currentRunId < Number.MAX_SAFE_INTEGER ? currentRunId + 1 : 1;
}

export function canApplyGenerationState(isMounted: boolean, isCurrentRun: boolean): boolean {
  return isMounted && isCurrentRun;
}

export function canApplyCreateHydrationState(isMounted: boolean): boolean {
  return isMounted;
}

export function canApplyCreateFeedbackState(isMounted: boolean): boolean {
  return isMounted;
}

export function canApplyGenerationResult(isMounted: boolean, isCurrentRun: boolean): boolean {
  return canApplyGenerationState(isMounted, isCurrentRun);
}
