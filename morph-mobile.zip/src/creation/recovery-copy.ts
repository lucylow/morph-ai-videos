export type PersistenceUiStage = "character" | "episode" | null;

export interface PersistenceCopyLabels {
  persisting: string;
  savingCharacter: string;
  savingEpisode: string;
  savedCharacter: string;
  pendingCharacter: string;
  savedEpisode: string;
  pendingEpisode: string;
}

export interface PersistenceUiState {
  activeStage: PersistenceUiStage;
  characterSaved: boolean;
  episodeSaved: boolean;
}

export interface PersistenceUiLabels {
  active: string;
  character: string;
  episode: string;
}

export interface PersistenceAccessibilityState {
  busy: boolean;
}

export function getPersistenceAccessibilityState(state: Pick<PersistenceUiState, "activeStage">): PersistenceAccessibilityState {
  return { busy: state.activeStage !== null };
}

export function getPersistenceUiLabels(
  state: PersistenceUiState,
  copy: PersistenceCopyLabels,
): PersistenceUiLabels {
  return {
    active:
      state.activeStage === "character"
        ? copy.savingCharacter
        : state.activeStage === "episode"
          ? copy.savingEpisode
          : copy.persisting,
    character: state.activeStage === "character"
      ? copy.savingCharacter
      : state.characterSaved
        ? copy.savedCharacter
        : copy.pendingCharacter,
    episode: state.activeStage === "episode"
      ? copy.savingEpisode
      : state.episodeSaved
        ? copy.savedEpisode
        : copy.pendingEpisode,
  };
}
