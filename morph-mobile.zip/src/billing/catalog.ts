export type ProductKind = "subscription" | "credit_pack";
export type PlanId = "free" | "plus" | "creator";
export type BillingPeriod = "monthly" | "yearly";

export interface ProductDefinition { id: string; kind: ProductKind; plan?: PlanId; billingPeriod?: BillingPeriod; credits?: number; enabled: boolean; }
export const PRODUCTS: ProductDefinition[] = [
  { id: "com.morph.plus.monthly", kind: "subscription", plan: "plus", billingPeriod: "monthly", enabled: true },
  { id: "com.morph.plus.yearly", kind: "subscription", plan: "plus", billingPeriod: "yearly", enabled: true },
  { id: "com.morph.creator.monthly", kind: "subscription", plan: "creator", billingPeriod: "monthly", enabled: true },
  { id: "com.morph.credits.25", kind: "credit_pack", credits: 25, enabled: true },
  { id: "com.morph.credits.75", kind: "credit_pack", credits: 75, enabled: true },
  { id: "com.morph.credits.200", kind: "credit_pack", credits: 200, enabled: true },
];

export interface Entitlements { plan: PlanId; monthlyCredits: number; maxCharacters: number; maxStories: number; advancedDirector: boolean; customWorlds: boolean; premiumStyles: boolean; priorityGeneration: boolean; analytics: boolean; watermarkFree: boolean; extendedGeneration: boolean; }
export const FREE_PLAN: Entitlements = { plan: "free", monthlyCredits: 10, maxCharacters: 3, maxStories: 5, advancedDirector: false, customWorlds: false, premiumStyles: false, priorityGeneration: false, analytics: false, watermarkFree: false, extendedGeneration: false };
export const PLUS_PLAN: Entitlements = { plan: "plus", monthlyCredits: 100, maxCharacters: 25, maxStories: 50, advancedDirector: true, customWorlds: true, premiumStyles: true, priorityGeneration: true, analytics: false, watermarkFree: true, extendedGeneration: true };
export const CREATOR_PLAN: Entitlements = { plan: "creator", monthlyCredits: 500, maxCharacters: 100, maxStories: 250, advancedDirector: true, customWorlds: true, premiumStyles: true, priorityGeneration: true, analytics: true, watermarkFree: true, extendedGeneration: true };
export function getPlanEntitlements(plan: PlanId): Entitlements { return plan === "creator" ? CREATOR_PLAN : plan === "plus" ? PLUS_PLAN : FREE_PLAN; }

export const GENERATION_PRICING = { character: 2, image: 1, videoShort: 5, videoLong: 10, voice: 1, music: 1 } as const;
export function calculateVideoCost(duration: number, highQuality: boolean) { const base = duration <= 8 ? GENERATION_PRICING.videoShort : GENERATION_PRICING.videoLong; return Math.ceil(base * (highQuality ? 1.5 : 1)); }
export interface CreditBalance { available: number; reserved: number; lifetimePurchased: number; lifetimeConsumed: number; }
export function hasSufficientCredits(balance: CreditBalance, cost: number) { return balance.available >= Math.max(0, cost); }

export type UpgradeRecommendation = "none" | "plus" | "creator" | "credits";
export function clampMonetizationScore(score: number): number { return Math.min(100, Math.max(0, Number.isFinite(score) ? score : 0)); }
export function recommendUpgrade(plan: PlanId, credits: number, generations: number): UpgradeRecommendation { const safeCredits = Number.isFinite(credits) ? credits : 0; const safeGenerations = Number.isFinite(generations) ? generations : 0; if (plan === "creator") return "none"; if (safeCredits <= 0) return "credits"; if (plan === "free" && safeGenerations >= 5) return "plus"; if (plan === "plus" && safeGenerations >= 20) return "creator"; return "none"; }
