import type { LanguageCode } from "../localization/i18n";

export interface MonetizationCopy {
  title: string;
  subtitle: string;
  currentPlan: string;
  includedCredits: string;
  monthly: string;
  yearly: string;
  save: string;
  upgrade: string;
  restore: string;
  refreshing: string;
  restoreSuccess: string;
  refreshSuccess: string;
  unavailable: string;
  verificationFailed: string;
  creditBalance: string;
  benefits: string;
  benefitLineOne: string;
  benefitLineTwo: string;
}

const copy: Record<"en" | "fr" | "es" | "ar", MonetizationCopy> = {
  en: { title: "Make more of the story.", subtitle: "Choose a plan for more credits, deeper continuity, and faster creation.", currentPlan: "Current plan", includedCredits: "credits included each month", monthly: "Monthly", yearly: "Yearly", save: "Save with yearly billing", upgrade: "Upgrade", restore: "Restore purchase", refreshing: "Refreshing access…", restoreSuccess: "Your purchase was restored.", refreshSuccess: "Your access is up to date.", unavailable: "Billing is temporarily unavailable. Your work is safe.", verificationFailed: "We couldn’t verify that purchase yet. Try again when you’re online.", creditBalance: "Credit balance", benefits: "What’s included", benefitLineOne: "10 generations · 3 story projects", benefitLineTwo: "10 characters · 3 worlds" },
  fr: { title: "Allez plus loin dans votre histoire.", subtitle: "Choisissez une formule avec plus de crédits, de continuité et de vitesse.", currentPlan: "Formule actuelle", includedCredits: "crédits inclus chaque mois", monthly: "Mensuel", yearly: "Annuel", save: "Économisez avec la facturation annuelle", upgrade: "Passer à une formule supérieure", restore: "Restaurer l’achat", refreshing: "Actualisation de vos accès…", restoreSuccess: "Votre achat a été restauré.", refreshSuccess: "Vos accès sont à jour.", unavailable: "La facturation est momentanément indisponible. Votre travail est en sécurité.", verificationFailed: "Nous n’avons pas encore pu vérifier cet achat. Réessayez en ligne.", creditBalance: "Solde de crédits", benefits: "Inclus dans la formule", benefitLineOne: "10 générations · 3 projets d’histoire", benefitLineTwo: "10 personnages · 3 mondes" },
  es: { title: "Haz más con tu historia.", subtitle: "Elige un plan con más créditos, continuidad y velocidad de creación.", currentPlan: "Plan actual", includedCredits: "créditos incluidos cada mes", monthly: "Mensual", yearly: "Anual", save: "Ahorra con la facturación anual", upgrade: "Mejorar plan", restore: "Restaurar compra", refreshing: "Actualizando tus accesos…", restoreSuccess: "Se restauró tu compra.", refreshSuccess: "Tus accesos están actualizados.", unavailable: "La facturación no está disponible temporalmente. Tu trabajo está a salvo.", verificationFailed: "Aún no pudimos verificar esa compra. Inténtalo de nuevo cuando estés conectado.", creditBalance: "Saldo de créditos", benefits: "Incluye", benefitLineOne: "10 generaciones · 3 proyectos de historia", benefitLineTwo: "10 personajes · 3 mundos" },
  ar: { title: "اجعل قصتك أكبر.", subtitle: "اختر خطة تمنحك أرصدة أكثر واستمرارية أعمق وإنشاء أسرع.", currentPlan: "الخطة الحالية", includedCredits: "رصيدًا مضمّنًا كل شهر", monthly: "شهري", yearly: "سنوي", save: "وفّر مع الفوترة السنوية", upgrade: "ترقية الخطة", restore: "استعادة الشراء", refreshing: "جارٍ تحديث صلاحياتك…", restoreSuccess: "تمت استعادة عملية الشراء.", refreshSuccess: "صلاحياتك محدثة.", unavailable: "الفوترة غير متاحة مؤقتًا. عملك آمن.", verificationFailed: "تعذر التحقق من عملية الشراء بعد. حاول مجددًا عند الاتصال بالإنترنت.", creditBalance: "رصيد الأرصدة", benefits: "المزايا المشمولة", benefitLineOne: "10 عمليات إنشاء · 3 مشاريع قصصية", benefitLineTwo: "10 شخصيات · 3 عوالم" },
};

export function getMonetizationCopy(language: LanguageCode): MonetizationCopy {
  return copy[language === "fr" || language === "es" || language === "ar" ? language : "en"];
}
