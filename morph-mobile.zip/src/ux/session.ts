export type UXPhase = "onboarding" | "exploring" | "creating" | "planning" | "generating" | "reviewing" | "sharing" | "returning";
export interface UXSession { phase: UXPhase; firstSession: boolean; completedActions: string[]; lastActiveAt: string; currentGoal?: string; }
export interface UserPreferences { defaultVisualStyle?: string; defaultWorldId?: string; preferredDuration: number; preferredTone: string; autoplayVideos: boolean; hapticsEnabled: boolean; }
export const DEFAULT_PREFERENCES: UserPreferences = { preferredDuration: 8, preferredTone: "cinematic", autoplayVideos: true, hapticsEnabled: true };

export function createInitialUXSession(now = new Date().toISOString()): UXSession { return { phase: "onboarding", firstSession: true, completedActions: [], lastActiveAt: now }; }
export function completeUXAction(session: UXSession, action: string, now = new Date().toISOString()): UXSession { return { ...session, completedActions: session.completedActions.includes(action) ? session.completedActions : [...session.completedActions, action], lastActiveAt: now }; }
export function getFirstSessionGoal(session: UXSession) { if (!session.completedActions.includes("character_created")) return "Create your first character"; if (!session.completedActions.includes("first_generation")) return "Create your first episode"; if (!session.completedActions.includes("first_share")) return "Share your first creation"; return "Start another story"; }
export function minimizeChoices<T extends { optional: boolean }>(steps: T[]) { return steps.map((step, index) => ({ ...step, optional: index > 1 ? true : step.optional })); }
export function buildCreationFlow(hasCharacter: boolean, hasWorld: boolean) { const steps: ("character" | "world" | "idea" | "tone" | "duration")[] = []; if (!hasCharacter) steps.push("character"); if (!hasWorld) steps.push("world"); steps.push("idea"); return { steps }; }


export function shouldShowRecovery(hasDraft: boolean, dismissed: boolean) { return hasDraft && !dismissed; }
