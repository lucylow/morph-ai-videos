import type { LocalEpisode } from "../storage/morph-repository";

export type StoryGenre = "adventure" | "comedy" | "mystery" | "fantasy" | "science_fiction" | "slice_of_life" | "friendship" | "coming_of_age" | "superhero" | "horror_light";
export type StoryTone = "funny" | "whimsical" | "cinematic" | "mysterious" | "hopeful" | "dramatic" | "playful" | "epic" | "heartwarming";

export interface StoryPremise { idea: string; genre: StoryGenre; tone: StoryTone; protagonistIds: string[]; worldId: string; }
export interface StoryStructure { hook: string; setup: string; incitingIncident: string; objective: string; obstacle: string; escalation: string[]; climax: string; ending: string; continuationQuestion: string; }
export type CharacterArcType = "confidence" | "curiosity" | "friendship" | "responsibility" | "creativity" | "courage" | "adaptation" | "discovery";
export interface CharacterArc { characterId: string; type: CharacterArcType; startingState: string; targetState: string; turningPoints: string[]; currentProgress: number; }
export interface StoryThread { id: string; title: string; question: string; status: "open" | "active" | "resolved" | "abandoned"; importance: number; introducedEpisode: number; targetResolutionEpisode?: number; }
export interface StoryMemory { establishedFacts: string[]; characterStates: Record<string, string>; locations: string[]; importantObjects: string[]; openThreads: StoryThread[]; pastEpisodes: string[]; }
export interface WorldLore { history: string[]; cultures: string[]; landmarks: string[]; rules: string[]; technology: string[]; recurringSymbols: string[]; unexploredAreas: string[]; }
export interface CreativeIdea { id: string; premise: string; hook: string; emotionalCore: string; visualHook: string; noveltyScore: number; replayPotential: number; }
export interface CreativeConstraint { id: string; description: string; severity: "soft" | "hard"; }

export const creativeConstraints: CreativeConstraint[] = [
  { id: "no_easy_solution", description: "The protagonist should not solve the central problem immediately.", severity: "soft" },
  { id: "visual_hook", description: "The episode should contain an unusual visual moment.", severity: "soft" },
  { id: "character_action", description: "The protagonist must make at least one meaningful choice.", severity: "hard" },
];

export interface HookScore { clarity: number; novelty: number; visualImpact: number; curiosity: number; }
export function scoreHook(hook: HookScore) { return hook.clarity * 0.25 + hook.novelty * 0.25 + hook.visualImpact * 0.3 + hook.curiosity * 0.2; }

export interface CreativitySeed { genre: StoryGenre; object: string; location: string; mood: StoryTone; constraint: string; }
export function randomizeSeed(random = Math.random): CreativitySeed {
  const pick = <T,>(items: T[]) => items[Math.floor(random() * items.length)];
  return { genre: pick(["adventure", "mystery", "comedy", "fantasy"]), object: pick(["ancient map", "broken robot", "mysterious key", "strange coin"]), location: pick(["floating city", "underground station", "desert carnival", "hidden library"]), mood: pick(["playful", "cinematic", "mysterious"]), constraint: "The protagonist cannot solve the problem immediately." };
}

export function diversifyIdeas(ideas: CreativeIdea[], similarity: (a: string, b: string) => number = lexicalSimilarity) {
  return [...ideas].sort((a, b) => b.noveltyScore - a.noveltyScore).filter((idea, index, list) => !list.slice(0, index).some((previous) => similarity(previous.premise, idea.premise) > 0.8));
}

function lexicalSimilarity(a: string, b: string) {
  const left = new Set(a.toLowerCase().split(/\W+/).filter(Boolean)); const right = new Set(b.toLowerCase().split(/\W+/).filter(Boolean));
  const union = new Set([...left, ...right]).size; return union ? [...left].filter((token) => right.has(token)).length / union : 0;
}


export function buildPremiseSummary(input: { idea: string; genre: StoryGenre; tone: StoryTone; world: string; character: string }) {
  const idea = input.idea.trim() || "A new chapter is waiting to be discovered.";
  return `${input.character} enters ${input.world} for a ${input.tone} ${input.genre} story: ${idea}`;
}

export interface BranchChoice { id: string; label: string; consequence: string; }
export function normalizeBranchChoice(choice: BranchChoice) { return { ...choice, label: choice.label.trim(), consequence: choice.consequence.trim() }; }


export function formatBranchContinuation(choice: BranchChoice, episodeTitle: string) {
  const normalized = normalizeBranchChoice(choice);
  return `Continue “${episodeTitle}” after the choice: ${normalized.label}. Remember: ${normalized.consequence}`;
}


export interface StoryBranchNode { id: string; episodeId: string; choiceId?: string; title: string; parentId?: string; completed?: boolean; }
export interface StoryGraph { rootEpisodeId: string; nodes: StoryBranchNode[]; }
export function getStoryPath(graph: StoryGraph, nodeId: string) {
  const path: StoryBranchNode[] = []; let current = graph.nodes.find((node) => node.id === nodeId);
  while (current) { path.unshift(current); current = current.parentId ? graph.nodes.find((node) => node.id === current?.parentId) : undefined; }
  return path;
}
export function getStoryLeaves(graph: StoryGraph) { return graph.nodes.filter((node) => !graph.nodes.some((candidate) => candidate.parentId === node.id)); }

export function mergeCompletedStoryNodes(graph: StoryGraph, episodes: LocalEpisode[]): StoryGraph {
  const completed = episodes.filter((episode) => episode.status === "completed");
  return { ...graph, nodes: graph.nodes.map((node) => ({ ...node, completed: completed.some((episode) => episode.id === node.episodeId || episode.episode === node.episodeId || (node.choiceId && episode.branchChoiceId === node.choiceId)) })) };
}
