import type { LocalEpisode } from "@/src/storage/morph-repository";

export function formatEpisodeLabel(episode: LocalEpisode, index: number): string {
  return episode.episode?.trim() || `Episode ${index + 1} · New chapter`;
}

export function buildEpisodeAccessibilityLabel(episode: LocalEpisode, index: number): string {
  const synopsis = episode.synopsis.trim();
  return synopsis ? `${episode.title}, ${formatEpisodeLabel(episode, index)}. ${synopsis}` : `${episode.title}, ${formatEpisodeLabel(episode, index)}`;
}

export function episodeColor(episode: LocalEpisode, index: number): string {
  return (episode as LocalEpisode & { color?: string }).color ?? ["#8B7CFF", "#5CA8FF", "#FF7B68"][index % 3];
}
