import type { LocalEpisode } from "@/src/storage/morph-repository";

export function buildEpisodeContinuationPrompt(episode: LocalEpisode, remix = false): string {
  const prefix = remix ? "Remix this episode" : "Continue this episode";
  const branch = episode.branchChoiceId ? ` along branch ${episode.branchChoiceId}` : "";
  return `${prefix}${branch}: ${episode.title}. ${episode.synopsis}`;
}
