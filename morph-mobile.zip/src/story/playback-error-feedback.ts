import type { StoriesCopy } from "@/src/localization/screen-copy";

export function getPlaybackPersistenceFeedback(error: unknown, copy: StoriesCopy): string | null {
  const raw = error instanceof Error ? error.message : String(error);
  if (raw === "API request timed out") return copy.persistenceTimedOut;
  if (raw === "API request cancelled") return copy.persistenceCancelled;
  return null;
}
