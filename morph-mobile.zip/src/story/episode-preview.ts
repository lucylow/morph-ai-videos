export type EpisodePreviewState = "ready" | "unavailable";
export type EpisodePlaybackUiState = "unavailable" | "loading" | "error" | "ready";

function getMediaUri(episode: unknown): string | null {
  if (!episode || typeof episode !== "object" || !("mediaUri" in episode)) return null;
  const mediaUri = (episode as { mediaUri?: unknown }).mediaUri;
  return typeof mediaUri === "string" && mediaUri.trim() ? mediaUri.trim() : null;
}

export function getEpisodePreviewState(episode: unknown): EpisodePreviewState {
  return getMediaUri(episode) ? "ready" : "unavailable";
}

export function getEpisodePreviewUri(episode: unknown): string | null {
  return getMediaUri(episode);
}

export function getEpisodePlaybackUiState(
  episode: unknown,
  status: unknown,
  error: unknown,
): EpisodePlaybackUiState {
  if (getEpisodePreviewState(episode) === "unavailable") return "unavailable";
  if (error || status === "error") return "error";
  if (status === "loading") return "loading";
  return "ready";
}

export function formatPlaybackPosition(value: unknown): string | null {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return null;
  const totalSeconds = Math.floor(value);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

export function getPersistenceRetryDelay(attempt: unknown): number {
  if (typeof attempt !== "number" || !Number.isFinite(attempt) || attempt < 0) return 250;
  return Math.min(2000, 250 * 2 ** Math.floor(attempt));
}

export interface CancellableDelay {
  promise: Promise<void>;
  cancel: () => void;
}

export function createCancellableDelay(delayMs: unknown): CancellableDelay {
  const duration = typeof delayMs === "number" && Number.isFinite(delayMs) && delayMs >= 0 ? delayMs : 0;
  let resolveDelay: () => void = () => undefined;
  let settled = false;
  const handle = setTimeout(() => {
    if (settled) return;
    settled = true;
    resolveDelay();
  }, duration);
  const promise = new Promise<void>((resolve) => {
    resolveDelay = resolve;
  });
  return {
    promise,
    cancel: () => {
      if (settled) return;
      settled = true;
      clearTimeout(handle);
      resolveDelay();
    },
  };
}

export function getPlaybackRemainingTime(position: unknown, duration: unknown): string | null {
  if (typeof position !== "number" || typeof duration !== "number" || !Number.isFinite(position) || !Number.isFinite(duration) || position < 0 || duration <= 0 || position >= duration) return null;
  return formatPlaybackPosition(duration - position);
}

export function getPlaybackSeekTime(locationX: unknown, width: unknown, duration: unknown): number | null {
  if (typeof locationX !== "number" || typeof width !== "number" || typeof duration !== "number" || !Number.isFinite(locationX) || !Number.isFinite(width) || !Number.isFinite(duration) || width <= 0 || duration <= 0) return null;
  const ratio = Math.min(1, Math.max(0, locationX / width));
  return Math.round(ratio * duration * 10) / 10;
}

export function getPlaybackProgressPercent(position: unknown, duration: unknown): number | null {
  if (typeof position !== "number" || typeof duration !== "number" || !Number.isFinite(position) || !Number.isFinite(duration) || position <= 0 || duration <= 0) return null;
  return Math.min(100, Math.max(0, Math.round((position / duration) * 100)));
}

export function isRetrySnapshotFresh(createdAt: unknown, now: unknown, maxAgeMs = 30_000): boolean {
  if (typeof createdAt !== "number" || typeof now !== "number" || !Number.isFinite(createdAt) || !Number.isFinite(now) || !Number.isFinite(maxAgeMs) || maxAgeMs <= 0) return false;
  return now >= createdAt && now - createdAt <= maxAgeMs;
}

export function shouldApplyRecoveryCleanupState(mounted: unknown): boolean {
  return mounted === true;
}

export function shouldApplyPlaybackMutationState(mounted: unknown, currentGeneration: unknown, expectedGeneration: unknown): boolean {
  return mounted === true && currentGeneration === expectedGeneration;
}

export function shouldApplyPlaybackRetryState(mounted: unknown, currentGeneration: unknown, expectedGeneration: unknown): boolean {
  return shouldApplyPlaybackMutationState(mounted, currentGeneration, expectedGeneration);
}

export function canStartEpisodeHistoryLoad(isLoading: unknown): boolean {
  return isLoading !== true;
}

export function shouldClearStoriesFeedback(mounted: unknown, message: unknown): boolean {
  return mounted === true && typeof message === "string" && message.trim().length > 0;
}

export function shouldClearStoriesRefreshSuccess(mounted: unknown, message: unknown): boolean {
  return shouldClearStoriesFeedback(mounted, message);
}

export function getStoriesRefreshCompletionMessage(isInitialLoad: unknown, message: unknown): string | null {
  if (isInitialLoad === true || typeof message !== "string" || message.trim().length === 0) return null;
  return message;
}

export function getStoriesRefreshAccessibilityState(isLoading: unknown): { busy: boolean; disabled: boolean } {
  const busy = isLoading === true;
  return { busy, disabled: busy };
}

export function getPlaybackMutationAccessibilityState(isActive: unknown): { busy: boolean; disabled: boolean } {
  const busy = isActive === true;
  return { busy, disabled: busy };
}

export function getStoriesLoadErrorMessage(isInitialLoad: unknown, offlineError: unknown, refreshError: unknown): string | null {
  const candidate = isInitialLoad === true ? offlineError : refreshError;
  return typeof candidate === "string" && candidate.trim().length > 0 ? candidate : null;
}

export function getStoriesFeedbackAccessibilityLabel(message: unknown): string | undefined {
  return typeof message === "string" && message.trim().length > 0 ? message.trim() : undefined;
}

export type PendingPlaybackRecoveryNoticeState = "restored" | "expired" | "invalid";

export function getPendingPlaybackRecoveryNoticeState(snapshot: unknown, now: unknown): PendingPlaybackRecoveryNoticeState {
  if (!snapshot || typeof snapshot !== "object") return "invalid";
  const candidate = snapshot as { id?: unknown; target?: unknown; createdAt?: unknown };
  if (typeof candidate.id !== "string" || !candidate.id.trim() || typeof candidate.target !== "number" || !Number.isFinite(candidate.target) || candidate.target < 0) return "invalid";
  return isRetrySnapshotFresh(candidate.createdAt, now) ? "restored" : "expired";
}
