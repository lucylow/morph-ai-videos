export type VideoPlaybackStatus = "idle" | "loading" | "ready" | "error";
export type VideoPlaybackErrorKind = "network" | "format" | "unknown";

export function classifyPlaybackError(error: unknown): VideoPlaybackErrorKind {
  const message = error instanceof Error ? error.message.toLowerCase() : String(error ?? "").toLowerCase();
  if (/network|offline|timeout|connection|buffer/.test(message)) return "network";
  if (/codec|format|decoder|unsupported|decode/.test(message)) return "format";
  return "unknown";
}

export interface VideoRecoveryState {
  hasSource: boolean;
  status: VideoPlaybackStatus;
  hasError: boolean;
}

export function canStartVideoImport(isImporting: boolean): boolean {
  return !isImporting;
}

export function canRetryPlayback(state: VideoRecoveryState): boolean {
  return state.hasSource && state.status !== "loading";
}

export function beginPlaybackRetry(state: VideoRecoveryState): VideoRecoveryState {
  if (!canRetryPlayback(state)) return state;
  return { hasSource: true, status: "loading", hasError: false };
}

export function resolvePlaybackStatus(
  state: VideoRecoveryState,
  status: VideoPlaybackStatus,
  hasError = status === "error",
): VideoRecoveryState {
  return {
    hasSource: state.hasSource,
    status,
    hasError: status === "error" || hasError,
  };
}

export function clearPlaybackError(state: VideoRecoveryState): VideoRecoveryState {
  return { ...state, hasError: false, status: state.hasSource ? "ready" : "idle" };
}
