import * as ImagePicker from "expo-image-picker";

import { normalizeMorphError, type MorphErrorInfo } from "../core/errors";

export interface SelectedVideo { uri: string; fileName?: string; durationMs?: number; width?: number; height?: number; }
export type VideoPickResult = { ok: true; video: SelectedVideo } | { ok: false; canceled: boolean; error?: MorphErrorInfo };

function normalizeOptionalNumber(value: number | null | undefined): number | undefined {
  return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
}

export async function pickVideoFromLibrary(): Promise<VideoPickResult> {
  try {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["videos"], allowsEditing: false, quality: 1 });
    if (result.canceled || !result.assets[0]) return { ok: false, canceled: true };
    const asset = result.assets[0];
    if (typeof asset.uri !== "string" || asset.uri.trim().length === 0) {
      return { ok: false, canceled: false, error: normalizeMorphError(new Error("Selected media has no readable URI"), "media") };
    }
    return { ok: true, video: { uri: asset.uri.trim(), fileName: typeof asset.fileName === "string" && asset.fileName.trim().length > 0 ? asset.fileName : undefined, durationMs: normalizeOptionalNumber(asset.duration), width: normalizeOptionalNumber(asset.width), height: normalizeOptionalNumber(asset.height) } };
  } catch (error) {
    return { ok: false, canceled: false, error: normalizeMorphError(error, "media") };
  }
}
