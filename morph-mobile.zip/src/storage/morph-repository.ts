import AsyncStorage from "@react-native-async-storage/async-storage";

export type CharacterStatus = "processing" | "ready" | "failed";

export interface LocalCharacter {
  id: string;
  name: string;
  style: string;
  personality: string[];
  color: string;
  status: CharacterStatus;
  updatedAt: string;
  dna?: LocalCharacterDNA;
}

export interface CreationDraft {
  selectedCharacterId: string;
  selectedStyle: string;
  selectedNext: string;
  selectedWorld: string;
  genre?: string;
  tone?: string;
  prompt: string;
  updatedAt: string;
}

const CHARACTERS_KEY = "morph.local.characters.v1";
const DRAFT_KEY = "morph.local.creation-draft.v1";

export async function withStorageRetry<T>(operation: () => Promise<T>, attempts = 3): Promise<T> {
  const safeAttempts = Math.max(1, Math.floor(attempts));
  let lastError: unknown;
  for (let attempt = 0; attempt < safeAttempts; attempt += 1) {
    try { return await operation(); } catch (error) { lastError = error; if (attempt < safeAttempts - 1) await new Promise((resolve) => setTimeout(resolve, 100 * (attempt + 1))); }
  }
  throw lastError instanceof Error ? lastError : new Error("MORPH storage write failed");
}

function isRecord(value: unknown): value is Record<string, unknown> { return typeof value === "object" && value !== null; }
export function normalizeCharacters(value: unknown): LocalCharacter[] { if (!Array.isArray(value)) return defaultCharacters; return value.filter((item): item is LocalCharacter => isRecord(item) && typeof item.id === "string" && typeof item.name === "string" && typeof item.style === "string" && Array.isArray(item.personality) && typeof item.color === "string" && (item.status === "processing" || item.status === "ready" || item.status === "failed") && typeof item.updatedAt === "string"); }
export function normalizePlaybackPosition(value: unknown, duration?: unknown): number {
  const position = typeof value === "number" && Number.isFinite(value) ? Math.max(0, value) : 0;
  const maxDuration = typeof duration === "number" && Number.isFinite(duration) && duration > 0 ? duration : undefined;
  return maxDuration === undefined ? position : Math.min(position, maxDuration);
}

export function normalizeEpisodes(value: unknown): LocalEpisode[] { if (!Array.isArray(value)) return []; const valid = value.filter((item): item is LocalEpisode => isRecord(item) && typeof item.id === "string" && typeof item.title === "string" && typeof item.world === "string" && typeof item.characterName === "string" && typeof item.synopsis === "string" && (item.status === "completed" || item.status === "failed") && typeof item.createdAt === "string"); const byId = new Map<string, LocalEpisode>(); for (const episode of valid) { const normalized = { ...episode, playbackPositionSec: normalizePlaybackPosition(episode.playbackPositionSec, episode.durationSec), durationSec: typeof episode.durationSec === "number" && Number.isFinite(episode.durationSec) && episode.durationSec > 0 ? episode.durationSec : undefined }; const existing = byId.get(episode.id); if (!existing || episode.createdAt >= existing.createdAt) byId.set(episode.id, normalized); } return Array.from(byId.values()); }
export function normalizeCreationDraft(value: unknown): CreationDraft | null { if (!isRecord(value) || typeof value.selectedCharacterId !== "string" || typeof value.selectedStyle !== "string" || typeof value.selectedNext !== "string" || typeof value.selectedWorld !== "string" || typeof value.prompt !== "string" || typeof value.updatedAt !== "string") return null; return { selectedCharacterId: value.selectedCharacterId, selectedStyle: value.selectedStyle, selectedNext: value.selectedNext, selectedWorld: value.selectedWorld, genre: typeof value.genre === "string" ? value.genre : undefined, tone: typeof value.tone === "string" ? value.tone : undefined, prompt: value.prompt, updatedAt: value.updatedAt }; }

export const defaultCharacters: LocalCharacter[] = [
  { id: "nova", name: "Nova", style: "Neon hero", personality: ["Curious"], color: "#8B7CFF", status: "ready", updatedAt: "2026-08-21T00:00:00.000Z" },
  { id: "milo", name: "Milo", style: "Clay world", personality: ["Chaotic"], color: "#FF7B68", status: "ready", updatedAt: "2026-08-20T00:00:00.000Z" },
  { id: "sage", name: "Sage", style: "Forest myth", personality: ["Brave"], color: "#D7F36B", status: "ready", updatedAt: "2026-08-19T00:00:00.000Z" },
];

export async function loadCharacters(): Promise<LocalCharacter[]> {
  try {
    const serialized = await AsyncStorage.getItem(CHARACTERS_KEY);
    if (!serialized) return defaultCharacters;
    const parsed: unknown = JSON.parse(serialized);
    const normalized = normalizeCharacters(parsed);
    return normalized.length ? normalized : defaultCharacters;
  } catch {
    return defaultCharacters;
  }
}

export async function saveCharacters(characters: LocalCharacter[]): Promise<void> {
  await withStorageRetry(() => AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(characters)));
}

export async function loadCreationDraft(): Promise<CreationDraft | null> {
  try {
    const serialized = await AsyncStorage.getItem(DRAFT_KEY);
    if (!serialized) return null;
    return normalizeCreationDraft(JSON.parse(serialized) as unknown);
  } catch {
    return null;
  }
}

export async function saveCreationDraft(draft: CreationDraft): Promise<void> {
  await withStorageRetry(() => AsyncStorage.setItem(DRAFT_KEY, JSON.stringify(draft)));
}

export async function clearCreationDraft(): Promise<void> {
  await withStorageRetry(() => AsyncStorage.removeItem(DRAFT_KEY));
}


export interface LocalEpisode {
  id: string;
  title: string;
  world: string;
  characterName: string;
  synopsis: string;
  episode?: string;
  color?: string;
  branchChoiceId?: string;
  status: "completed" | "failed";
  createdAt: string;
  playbackPositionSec?: number;
  durationSec?: number;
}

const EPISODES_KEY = "morph.local.episodes.v1";

export async function loadEpisodes(): Promise<LocalEpisode[]> {
  try {
    const serialized = await AsyncStorage.getItem(EPISODES_KEY);
    if (!serialized) return [];
    const parsed: unknown = JSON.parse(serialized);
    return normalizeEpisodes(parsed);
  } catch {
    return [];
  }
}

export async function saveEpisode(episode: LocalEpisode): Promise<void> {
  const episodes = await loadEpisodes();
  const next = [episode, ...episodes.filter((item) => item.id !== episode.id)].slice(0, 50);
  await withStorageRetry(() => AsyncStorage.setItem(EPISODES_KEY, JSON.stringify(next)));
}

export async function updateEpisodePlaybackPosition(id: string, position: unknown, duration?: unknown): Promise<LocalEpisode | null> {
  const episodes = await loadEpisodes();
  const episode = episodes.find((item) => item.id === id);
  if (!episode) return null;
  const updated: LocalEpisode = { ...episode, playbackPositionSec: normalizePlaybackPosition(position, duration), durationSec: typeof duration === "number" && Number.isFinite(duration) && duration > 0 ? duration : episode.durationSec };
  await saveEpisode(updated);
  return updated;
}


export interface LocalCharacterDNA {
  identityDescription: string;
  visualStyle: string;
  personality: string[];
  referenceImageUri?: string;
  version: number;
}

export interface CharacterEdits {
  name?: string;
  style?: string;
  personality?: string[];
}

export function normalizeCharacterEdits(value: CharacterEdits | null | undefined, fallback: Pick<LocalCharacter, "name" | "style" | "personality">): CharacterEdits {
  const name = typeof value?.name === "string" && value.name.trim() ? value.name.trim().slice(0, 60) : fallback.name;
  const style = typeof value?.style === "string" && value.style.trim() ? value.style.trim().slice(0, 60) : fallback.style;
  const personality = Array.isArray(value?.personality) ? value.personality.filter((trait): trait is string => typeof trait === "string" && Boolean(trait.trim())).map((trait) => trait.trim().slice(0, 40)).slice(0, 4) : fallback.personality;
  return { name, style, personality: personality.length ? personality : fallback.personality };
}

export async function updateCharacter(id: string, edits: CharacterEdits): Promise<LocalCharacter | null> {
  const characters = await loadCharacters();
  const existing = characters.find((character) => character.id === id);
  if (!existing) return null;
  const normalized = normalizeCharacterEdits(edits, existing);
  const updated: LocalCharacter = { ...existing, ...normalized, dna: existing.dna ? { ...existing.dna, visualStyle: normalized.style ?? existing.style, personality: normalized.personality ?? existing.personality } : existing.dna, updatedAt: new Date().toISOString() };
  await saveCharacters([updated, ...characters.filter((character) => character.id !== id)]);
  return updated;
}

export async function upsertCharacter(character: LocalCharacter & { dna?: LocalCharacterDNA }): Promise<void> {
  const characters = await loadCharacters();
  const next = [character, ...characters.filter((item) => item.id !== character.id)].slice(0, 50);
  await saveCharacters(next);
}


const RECOVERY_DISMISSED_KEY = "morph.local.recovery.dismissed.v1";
export async function loadRecoveryDismissed(): Promise<boolean> {
  try { return (await AsyncStorage.getItem(RECOVERY_DISMISSED_KEY)) === "true"; } catch { return false; }
}
export async function saveRecoveryDismissed(value: boolean): Promise<void> {
  await withStorageRetry(() => AsyncStorage.setItem(RECOVERY_DISMISSED_KEY, String(Boolean(value))));
}

export interface PendingPlaybackRecovery {
  id: string;
  target: number;
  duration?: number;
  createdAt: number;
}

const PENDING_PLAYBACK_RECOVERY_KEY = "morph.local.pending-playback-recovery.v1";

export function normalizePendingPlaybackRecovery(value: unknown): PendingPlaybackRecovery | null {
  if (!isRecord(value) || typeof value.id !== "string" || !value.id.trim() || typeof value.target !== "number" || !Number.isFinite(value.target) || value.target < 0 || typeof value.createdAt !== "number" || !Number.isFinite(value.createdAt)) return null;
  const duration = typeof value.duration === "number" && Number.isFinite(value.duration) && value.duration > 0 ? value.duration : undefined;
  return { id: value.id, target: duration === undefined ? value.target : Math.min(value.target, duration), duration, createdAt: value.createdAt };
}

export async function loadPendingPlaybackRecovery(): Promise<PendingPlaybackRecovery | null> {
  try {
    const serialized = await AsyncStorage.getItem(PENDING_PLAYBACK_RECOVERY_KEY);
    return serialized ? normalizePendingPlaybackRecovery(JSON.parse(serialized) as unknown) : null;
  } catch {
    return null;
  }
}

export async function savePendingPlaybackRecovery(recovery: PendingPlaybackRecovery): Promise<void> {
  await withStorageRetry(() => AsyncStorage.setItem(PENDING_PLAYBACK_RECOVERY_KEY, JSON.stringify(recovery)));
}

export async function clearPendingPlaybackRecovery(): Promise<void> {
  await withStorageRetry(() => AsyncStorage.removeItem(PENDING_PLAYBACK_RECOVERY_KEY));
}
